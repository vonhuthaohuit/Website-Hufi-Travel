-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: ql_tourdulich
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_schedules`
--

DROP TABLE IF EXISTS `backup_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `frequency` enum('daily','weekly','monthly') NOT NULL,
  `backup_time` varchar(255) NOT NULL,
  `backup_day` varchar(255) DEFAULT NULL,
  `backup_day_of_month` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_schedules`
--

LOCK TABLES `backup_schedules` WRITE;
/*!40000 ALTER TABLE `backup_schedules` DISABLE KEYS */;
INSERT INTO `backup_schedules` VALUES (1,'daily','21:38','Sunday',NULL,'2024-12-14 14:36:49','2024-12-14 14:36:49');
/*!40000 ALTER TABLE `backup_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogtour`
--

DROP TABLE IF EXISTS `blogtour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogtour` (
  `mablogtour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tieude` text NOT NULL,
  `slug` text NOT NULL,
  `hinhanh` text NOT NULL,
  `noidung` longtext NOT NULL,
  `trangthaiblog` tinyint(1) NOT NULL,
  `maloaiblog` int(10) unsigned NOT NULL,
  `manhanvien` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mablogtour`),
  KEY `blogtour_maloaiblog_foreign` (`maloaiblog`),
  KEY `blogtour_manhanvien_foreign` (`manhanvien`),
  CONSTRAINT `blogtour_maloaiblog_foreign` FOREIGN KEY (`maloaiblog`) REFERENCES `loaiblog` (`maloaiblog`),
  CONSTRAINT `blogtour_manhanvien_foreign` FOREIGN KEY (`manhanvien`) REFERENCES `nhanvien` (`manhanvien`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogtour`
--

LOCK TABLES `blogtour` WRITE;
/*!40000 ALTER TABLE `blogtour` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogtour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chitietkhachsantour`
--

DROP TABLE IF EXISTS `chitietkhachsantour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chitietkhachsantour` (
  `makhachsan` int(10) unsigned NOT NULL,
  `matour` int(10) unsigned NOT NULL,
  `vitriphong` varchar(255) NOT NULL,
  `succhua` int(10) unsigned NOT NULL,
  PRIMARY KEY (`matour`,`makhachsan`),
  KEY `khachsan_tour_makhachsan_foreign` (`makhachsan`),
  CONSTRAINT `khachsan_tour_makhachsan_foreign` FOREIGN KEY (`makhachsan`) REFERENCES `khachsan` (`makhachsan`) ON DELETE CASCADE,
  CONSTRAINT `khachsan_tour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chitietkhachsantour`
--

LOCK TABLES `chitietkhachsantour` WRITE;
/*!40000 ALTER TABLE `chitietkhachsantour` DISABLE KEYS */;
INSERT INTO `chitietkhachsantour` VALUES (2,40,'Khu B Toà 6',15);
/*!40000 ALTER TABLE `chitietkhachsantour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chitietphieudattour`
--

DROP TABLE IF EXISTS `chitietphieudattour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chitietphieudattour` (
  `makhachhang` int(10) unsigned NOT NULL,
  `maphieudattour` int(10) unsigned NOT NULL,
  `chitietsotiendat` double(8,2) NOT NULL,
  `nguoidat` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`makhachhang`,`maphieudattour`),
  KEY `chitietphieudattour_maphieudattour_foreign` (`maphieudattour`),
  CONSTRAINT `chitietphieudattour_makhachhang_foreign` FOREIGN KEY (`makhachhang`) REFERENCES `khachhang` (`makhachhang`) ON DELETE CASCADE,
  CONSTRAINT `chitietphieudattour_maphieudattour_foreign` FOREIGN KEY (`maphieudattour`) REFERENCES `phieudattour` (`maphieudattour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chitietphieudattour`
--

LOCK TABLES `chitietphieudattour` WRITE;
/*!40000 ALTER TABLE `chitietphieudattour` DISABLE KEYS */;
INSERT INTO `chitietphieudattour` VALUES (82,42,800000.00,'81');
/*!40000 ALTER TABLE `chitietphieudattour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chitietphuongtientour`
--

DROP TABLE IF EXISTS `chitietphuongtientour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chitietphuongtientour` (
  `matour` int(10) unsigned NOT NULL,
  `maphuongtien` int(10) unsigned NOT NULL,
  `soluonghanhkhach` int(10) unsigned NOT NULL,
  `ghichu` varchar(255) NOT NULL,
  PRIMARY KEY (`matour`,`maphuongtien`),
  KEY `phuongtien_tour_maphuongtien_foreign` (`maphuongtien`),
  CONSTRAINT `phuongtien_tour_maphuongtien_foreign` FOREIGN KEY (`maphuongtien`) REFERENCES `phuongtien` (`maphuongtien`) ON DELETE CASCADE,
  CONSTRAINT `phuongtien_tour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chitietphuongtientour`
--

LOCK TABLES `chitietphuongtientour` WRITE;
/*!40000 ALTER TABLE `chitietphuongtientour` DISABLE KEYS */;
INSERT INTO `chitietphuongtientour` VALUES (40,5,10,'Không có'),(41,3,32,'Không có'),(41,5,10,'Không có'),(44,2,7,'Không có');
/*!40000 ALTER TABLE `chitietphuongtientour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chitiettour`
--

DROP TABLE IF EXISTS `chitiettour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chitiettour` (
  `ngaybatdau` date NOT NULL,
  `ngayketthuc` date NOT NULL,
  `giachitiettour` bigint(20) NOT NULL,
  `matour` int(10) unsigned NOT NULL,
  `madiemdulich` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`matour`,`madiemdulich`,`ngaybatdau`) USING BTREE,
  KEY `chitiettour_madiemdulich_foreign` (`madiemdulich`) USING BTREE,
  CONSTRAINT `chitiettour_madiemdulich_foreign` FOREIGN KEY (`madiemdulich`) REFERENCES `diemdulich` (`madiemdulich`) ON DELETE CASCADE,
  CONSTRAINT `chitiettour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chitiettour`
--

LOCK TABLES `chitiettour` WRITE;
/*!40000 ALTER TABLE `chitiettour` DISABLE KEYS */;
INSERT INTO `chitiettour` VALUES ('2024-12-17','2024-12-21',7000000,40,9,'2024-11-27 17:17:03','2024-11-27 17:17:03'),('2025-01-18','2025-01-21',7500000,41,9,'2024-11-27 17:19:13','2024-11-27 17:19:13'),('2025-01-18','2025-01-21',7500000,41,10,'2024-11-27 17:19:41','2024-11-27 17:19:41'),('2025-01-22','2025-01-23',800000,42,14,'2024-11-27 17:23:28','2024-11-27 17:23:28'),('2024-12-06','2024-12-07',850000,43,14,'2024-11-27 17:32:27','2024-11-27 17:32:27'),('2024-12-07','2024-12-08',850000,43,14,'2024-11-27 17:26:40','2024-11-27 17:26:40'),('2024-12-04','2024-12-06',1500000,44,14,'2024-11-28 00:22:56','2024-11-28 00:22:56');
/*!40000 ALTER TABLE `chitiettour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chucvu`
--

DROP TABLE IF EXISTS `chucvu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chucvu` (
  `machucvu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenchucvu` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`machucvu`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chucvu`
--

LOCK TABLES `chucvu` WRITE;
/*!40000 ALTER TABLE `chucvu` DISABLE KEYS */;
INSERT INTO `chucvu` VALUES (2,'Nhân sự','2024-11-07 17:00:00','2024-11-07 17:00:00'),(3,'Nhân viên phụ trách','2024-11-08 17:00:00','2024-11-08 17:00:00'),(4,'Thu ngân','2024-11-08 17:00:00','2024-11-08 17:00:00'),(5,'Tài xế','2024-11-08 17:00:00','2024-11-08 17:00:00'),(6,'Hướng dẫn viên','2024-11-08 17:00:00','2024-11-08 17:00:00');
/*!40000 ALTER TABLE `chucvu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chuongtrinhtour`
--

DROP TABLE IF EXISTS `chuongtrinhtour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chuongtrinhtour` (
  `machuongtrinhtour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tieude` varchar(255) NOT NULL,
  `ngay` varchar(255) NOT NULL,
  `mota` text NOT NULL,
  `matour` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`machuongtrinhtour`),
  KEY `chuongtrinhtour_matour_foreign` (`matour`),
  CONSTRAINT `chuongtrinhtour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chuongtrinhtour`
--

LOCK TABLES `chuongtrinhtour` WRITE;
/*!40000 ALTER TABLE `chuongtrinhtour` DISABLE KEYS */;
INSERT INTO `chuongtrinhtour` VALUES (36,'TP.HCM – HÀ NỘI – CHÙA TAM CHÚC (Ăn trưa, chiều)','1','<p>&nbsp;Sáng: Quý khách có mặt tại ga quốc nội, sân bay Tân Sơn Nhất trước giờ bay hai tiếng.</p><ul><li><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đại diện công ty HUFI Travel đón và hỗ trợ Quý Khách làm thủ tục đáp chuyến bay đi Hà Nội.&nbsp;</span></li><li><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đến sân bay Nội Bài, Hướng dẫn viên đón đoàn khởi hành đến HÀ NAM, Thăm quan Chùa Tam Chúc.&nbsp;</span></li></ul><p>Trưa: Dùng cơm trưa.</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thăm Chùa Tam Chúc, ngôi chùa lớn nhất thế giới. Với diện tích quần thể lên tới 5.000 ha, được tạc 1.200 bức tượng bằng dung nham núi lửa và sở hữu nhiều báu vật trên thế giới.</p><p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA0sAAAF6CAYAAADI/cNXAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAP+lSURBVHhe1P3pk6VJdt6JeWTse+SeWWtXVS9odDcaaDR2kQSImTGZZJJJHNlQAmgkNcBozPQXyPip/gCZ6Ys+SGb6IDPJ9IEzlMghiSHFIUYACDS2bjTQG7qrKiursnJfIiNj3/X8nsf9vTciI+6NQiW6Medev74fP358O+d1f/2OvP2vvnF45/adMjZ6royUg3Jw0DOHh4el6GsY4cuPjAPlsxf7XBlV/nPnRsvouRGZwzI1XspU2S93/vJ75S+/9oflyY0bZWZvr0we7JVx5SHd/uFB2dzZKxNTU2VickpYR8rOzk7Z29sp5Zxwj6oY4YKOMQXI6TLGx8fLxIQKEOzs7Jbt7e2yu7urdAcOI30z0DY2Nqb0E2VyckL2ZDk3PirKDoQ/NFORg4PDsq867+3tl719xSovZnd337Vtfn0rS6i88lN/hezv7pTtrQ3TPzE1Wa5fv17eeOPNsri4UHZV72erq2VHaRYWF8vy06fl8ZPHpn1CNI2Nj4m2qXLt2rXyuc99rrzy+mvlwaOHonPMtG1sbZa19XVRLD6o3iOjo3IdlnOyL164qLYbdTtMjAqP6jkxNl4OVYetTeVbXSubym+Kz1FftbPSkv+5dlaVDsWHPdFLOOlIvy9c0E4cvJyanC7T0zNqQ7VK44HMgfhvnPt75uWhzL7cxNE/XK7DxN8D8VVlKqicGxspk9OiWTXcU//Y2ycNPmhW3TCqIx1iTzRsb++KJ9uq15booizqUtxu+PfkPjc2qfhdt+eUeDu/sFAmxyeUd6esr2+UXdm07YP798uWcO2qLUhLHekT7jPqZ+fg5eRkGT9/vhyItyMKJwzei/HlUDQdigf7MgcyI6QXz3Afij+H9C+lPae2cR3kJ2xEuFRF07zvPreXdnAz6KPx0fifHgakTzdIHycU3pOGsZl8QLOBuOnPtZxe1MlQx9KLABcldNRjGPTXD5qdx9moF2HUwr1XYb20p0E/D04FoaE/duhcZApz7ooCXGNq3zOhrLjcRowJ8ZO+1bNJINPKHALU2GlNVsZc3I1H8Idxpr5FhvoTWnv1cGrK1xgaEQ1t7HpuoP+q39kmo76MZ/rgnvoN8yz0M56I29OcSzxje29P86/bJOD8lIUF4IAXzRBmHjCns35o7WCc4B47LOMT0JQ2bnkyt2huUFthM9+Hj8JRafdHZVFCy2dQmNcn805G6TCeOIRLE478h2VuelJr16jmirEyPcl8qvWDhedQc+L+rsbqntKOlKmJGYVpfEOX8sGXPejRh3Xt8FD9STCluYO1FdyUc8gco7FOKzEfzWj+n50YK3PjI1oXxWuTSt1NnYEatLqYr7gJrVWjboS7LVl/lWR0RGld9yRqfDCeODr/MCBF0rW8+SHoCB2CmoJW4KdHl4zp5ANtiY5d448bwP1ZbtPdaPZPzw8YV5wDIXiHpVR70lbVNwganYOhlqk5ehicpT3UsCoXx1koHAyMFPocMpn7nkOfh9YGjMFh4GqSPt7BMJwlZwcV2PrfQCCdx6jcp5WvOHgc+TD+tE0tQe40lX+UFoHVzoHQn4T8/e3d8Nsto1Fgvrd5LeH6aP4mrQ0pk/h0UDwy11mA8TYQF0CR4l8AGrEahfjlwuN0lUbAVtxUtaNdP/vMwWeCDtupQPnI+5Dg9cG8MomVzkqjALl2dna2LEg+nEGm1VyNjLi8vCyZ/ZllM/QNV+kf/5//P5q/JVBOT1l5cOPIUEkGBoIzigg2YbNzc578DKTV5xwLbF3wiJsYPSwLU6NlWgvM7e9+t3zva18rj959T8rSbhmXGTWjo5wgfI5r8R2VEILQi7JxIIHZipIMS9GB6GOBZy0eVTkwAqUHMlA4vFCLNuiOIB6BnAagUaMwRQAeU8VHtRiOaZEa1YJIudANM0m/W/PTIDB6a0tKQq2rw8DtzpqBRF4UPxbA3Z2tsrEpQVyCxfT0dLl46ZKE9Hk3xtz8nHg3b6F4V/RS1p4WfQSQlZWVsr6xoTxSmKRkXX/pJec/f/FimZ6ZtrK1tomyJFBZ8I0wegPpUJZGRQs2CtOY3Ahoe+LNDoqkFnkUr3NjWrRrG1E3+GqlxrwDXcIRgugT8BN+k4Z2saCgsHEpIpNSmEbPSWmo5UZZpv/AKwiljx6oflt2EwcQBh5PukpH37GCbd0XvvNpE63yCD+CgzuE2hHFZFcdeIu6NUUJmhW2KaVnY3NL9l7Z3MZPPQ7c7rMzs2Vqajp1pC+lUc3HPSlN9PFtcKqeOxosKFAomyhlO6J1fH5eK4oGoPg7qj40JiFoQryfFN4JDbJxcKsviUNlV7h3VQY2ChHKEQoW+TCHch+iLKkuJkU8gSZPLHLLEqSPtUF9HBxMXlvgQRzrLXfhYhKRpib3uEgBx/H2p4KnGaMxp8FxHCeD5wh9sE/P0ZtzOlBi56k8aPahhIV9zS2u2QASiKK/D0gSEBrGi9DWMltZlN1zA/TXs0B/G0ZBSht7bqnt7YKFexjGoPKvaemZ3nzdzDnmcJKTOOhbVlfBZVG2xgv1Va5eXtWt4UxapzbOTlkS/ZNTkw5nzOBn7O9rjqmlGhpOY7GlH7cvPFH9IaoSFgVJ8xZjS3OUmkw2WdIHkzS8Q6llPoowe+j5twnjod0ouzwZT5lzqB9ljGuyYY5kbkMPYm0ZEU5G0MzEuOZQrTGiY2Icm/mJvqFxYyWNByqUhaKkceey1B+VV7Fu62ZQCnh4NU7dVDZlHYhn+5pjVBHTMMXcpPVoUUrZtMtTWhnq0s+njp8Y14vaw92A46mPbCtKmolGoMGplIU0fXYD98fqPg2cHjps8/VPR0MXJzC9ApPKR46sC3E7XD+jaHR2O/Vztn9ljdIRDNQ5ZR73k9p9oOYbBENTKAF4I1y2sk4D6D1rqVn/BlEANxGEhwLtKzStbT8p0O/hcls9qBPgX+pX/YD7f3WfBk1Zstu/JwDRinQPejHVOBu0cjU2uq50CpjHGoe9PPS5liluvF26FwF99OHJmOm1QaOh3zjDEHCyFwiNf6k7tIW+jla8rodotMPRHb1YcQPIG700p4LRppxBQPmTks8go/EI/P0PK1vZpLVbaaclw50/f97y+vrGenny+EnZkFzu+Yu18df/T//0cFYCPQIhqxQTNQsQSJgwEB4ReBEemVjRwCL4UlhtSCFCWPeiJ/ekFpelSU3+B7tRlv7ga+Xxe+96Z2lCyoKWGRGYhWBiRtrcuBZf4UEIpjyeyrFAS6tSmRKIRccYi4ckT8qIsiSBUyRYiFc8Cx90s9uA34sqC2pdDGCcnygiTCjd5MxkGWMhk8nTYpSQaLjOQQbVL7sWUezMcMcxgBKP91BlHYpOniCyKG/VnS6n0XdGAvXV69fKyy+/XCZoRPHIYByamJV/U4L5yrNn5akUJ+r00kvXy5tvvhnFSTxiAkK5EwPKjpQtBBfyoSR4gVS4n66Cls5AvWVDIHnPTSKwp/7wkA6CAkx9YWRrR+qzw4KudiJdFm61jcIiHElAkZI0KoVpRAoMYjDVIC35m+LchMo9CVHGTSJB2kX8UvuTLkoWk/COcGlxB4/5Gx6zFFINV0Vh41KSIdk7MrKt/Knv7asO9FGUpbWNHfFxQwoVSlCUX9KMS9mxcCW30QnflBQdaLMgKxzY1JP2WF1dK6traxo4crMbJV67j5BbOCY0uKakAM9oTEzNzpdxKU+jou9QZbRdpQPVxztPrl3qsauwPfEVpQkh0cZ0pV2aMBhBRp8Qqx8s7MpPB8EjlCXqJJ45kDxkomlr/gZHPEDw9sAlKhm1hOKzwHGcR2GEDijB0nal7zTIxKX6VX9/33Gg3NDFDiQj9Tnyj0EP0+nAE3jvstS0LhM331p+h2c4uiNAfSLk90ybtAGPm1a/00AsoU2Ajh4Zz2ctfx+thr48Xhyq20B9a42cmnz6WFnik0DbHsvqmzxAYV5jXmEhApgnEJ5QcBjTFt5qXuYk47UVvNCQuVk8EA2en1wG647Gp8cDD15AQtv2aE56HlSJhxobzH0AikjmDMqq5ZCWD/VmnWGe3N1y/SbHx2UmvaszLkGcdYVRc055eD43pTlW+pEUjihPsVE6eMggWyR5DEth8m6uyoTKA0UwWrHjomwZ1XdCOKdYa8RHMcDK0oGUT3DxRH9GBZ6fHCvzk+NlVoqoHwSKVp5qup7C43YQn9K+FXdlD0Gpf+ZSlKXD/W3TTGp+Yoc/+RKSuUbWQCAltBoH5bp8nMmb7DUMfKYFCzv9tNdGCR+TgogbXA2Mv/4SDo2sD/EHUu/qozyno87CX/MOhl55pwHo6ad2nIYSNK6bEmBOxas4R7W5+XQgmfk3EFIO7Rx0p5V7RlB293PVlTHQ2qwZ6hY3iemTPA48HTpq6vrvKf80UGLmghcJpnkoMCefjW8NXbpc+niz6Xt8gcg7Zyu7B5XHceKzH7zMqy2+GaD1/2a8jvSjPAHI2h4anpaUsikXmRC8+E8D0kW2FFS6j9jQi0PQ0apPv18/fLvwVr9hgJ5RUZ8MQgcqP2QhnYsKn7xuMP9WQ5mzkq2ZA7ekNwBLS0vl6tWrnm+fSRZ/+vRp2dZ8jXw98r/7v/7W4fjMNCcLLHBGYKwLuxuiVoofQassBKURmaBZaCXsaWIbU9jEyH6ZLjtl9lDK0ne+U773+39Qlt+/WRaUb1rUTyg9iwELzdjUlJ/Is/DsqKHYCUFBYpIcOafG4+iDKjalBcSM0Idjawjx0MjxKey2c4SyhJ9JJwJw6mAwvSkbAXVcChfKEkI0nYlUTqk0DPbsaJwzsxAU9oQToRaFh/QIz9sS0Hd3thn1fioIfsoMb0YkvG+aJnhz4eLF8vnPf967WyyC0DAzOyMFdNFPa1dXV8uHH35YPrz1oTXa1157rbz++utl6cJ5KVxKd37JO4A0Ljsi6QSZ4DxpC7xbpIUYHrB8mI8SZg6keHLczcqFadRCKRzYgOnlIzRt54sOg2JKnWkDBhLhKEnsLiFetg5IneE5nR8cqT/sCx+E2tATFJVbvI2ypDQ8uRUtrQ3cz5QJ8vCbTqWfk1LCOKWvYDMoaENotKJDm+welI2tfbXZnpQeKVDiJVur4GhCB7igg90o8MMXlGb6RKc8q27sBJL34cNHVppQxmwrH/3Bu0b0HxQx9dFZtSU7TdMoUfMLcs+K72NKe+h+tIkRv7bhCX1PeehP9AkrcQqHTmg61JhgTNotes1QGGl+xk162xb1WPYE+mnjtOcmghaOHTjub6C+4WNE/QuZEfRspCcBuJ27+nvQ/IqlHrukJSXmeNoKiur6i/24CfZPZ8ORfc0RFtbkPw2oM338lNIMZId7kT1cgstvxjTUMID+83EA/ngu7TceK6GKfnsiULRLFigpdcYPHe7D0NVsaMNO0pahubpx2QsWLuVNnRrelCf29/z68UMYGeYbHpoxxianJoyFhwqMfc/FssHWfpoQCQ479aFszznQQ58kRF/mRsYxeJjHKS/H2BrBSimbcdF46PkdHJWPLqeWQeL0+Tb/7wsnR4ijLHGMcFpjjzVlgnGvvAiKKEkzmodxHx7slkPmQRmO33FygIdiLtPjEhVKdCov3RqDoiQS5A5NSmk6JzWnTGuMc7SPHaw9zQF7zEc86JJ/WumXJkbLovg6r3meOR6+8yCMh1YAPCEskLo1aPyFB16LpeAd7G0phAdpSdD4Q1oTiS0UKJINk6MMPRfQxgcJeajQ0qdfya60NJ53ba45KzTF7hn1e61JrZhkb1gryEuI69yfjjL4tDz6gi8PCmvCgZA8zn4CgAvc9OtTEzVQWj/YGwpQBm09+hoXj9NM3x4MNV9rkL8iuFR+hMLtq3JB6fHvNuprM+bkSif9MbwfACSFkclyKoAn47MGvACg2MFAgshNQ8t1FeBOS5t+1/V3h+POuAvuYdD6rlKDv/HYhCc/eJ9XlhzVld9vhoLyMrd2SKoF+f0ALub0QTihzd/+NMInCuPsK6OF9efpjCNik8rrEWEDANzMJU7YV/xJwDgyXvVjy5f69OjI+us6KNGk1gHcu5qX4dOFCxfK0uKiZfdHjx75wTnpRv6L/8tvSc7Sgq0Fy5N+yhKArDorgJCM2I1wFvsjRoRNjOyV2XO75erMZPngz/6sfOPf/3ZZv/VRmVMHmGRQylhgUJkTEipHtZAgdO7v5dgWCpOPEGjSZ4GyYmFNMZVuAhUfAxXBL9OeyDOo2X3wwtpPL8Kt8jPRw0hoRlDmiaaP6CEsI7iyi6M8G1J0eGdoS4zEP6mFbFIKHoVuS0mCHxx3mxyTsFwbJgTBr0wupkMe2OkGUppLly+XN954wztHKH+ciyTNyrOVcv/+/W4yZLfpmQzK1Fuf/rTTz87NercJm3eZwI9wQj2oJxM9xpRQVy3GBzwhZWeJ+Mof+Ee55KMDkQf+mH8sopBqnmVBIIzjOAhM4+OTzh/hQQlpz+qmns4sAsZVN5xtEWh9xm2gCBQSbJ4qk9A7RgpraTHgQ3CgLM6V0g4pSxFyU07rC1EeOHLIDlR2K9uuGEc2d2kPCWzZmUJZkgBoREzclB+FEPzpF8Klvoeyw5E66o6SZKVM+NhxWl5hR3C1rKN40QfUF8YnpyX0qJ1m58rUTNprcmraip2YUnaRzOCN0qP4oYRZAVMZk6ojShd5eSfqwEoU41NueC5aUaK8y8Wgl58n7HChVoWuQ5OET6SxW/S7bhkr6jHVwLPKQf2AAmVJvYYQhRFyzJBYSBG2kpEwxlkWXFZeBxvhqHgvSwJmzegYwC4npB4qkX6CH/pa29pUdxLn6FRX2dOh9bvBIFymBDtlubwK/X76Ls7TSiYVZGVHAHdSxlYNZTeyoY2+SNhJ5SUo4ezKRXFhns24gJYOKEsfdiPIkqf5NW/F7bLrR5NVXBAjXkIUPYH5e0y4MeTynKDyGBc7mu8gfYpjeIq0sqQ6cLQtu4cUEjrsBhTc6gM0AbsfHB+HbeYG+rPpU3rKQHiAVIxxJkfal7KBijg8TkLbI1LoJjiCh9AwKiVpvMxozZmVcoICw1BkTRphnQG38rg/QKvC2ikFbD+A87xCGVVZ0odaKVh+U+0PMV5XxD+OKrOzZMUMIqEbvqteExpr88o3Pz5a5qany8zMtB9SWeEUUIc41b7iuSyIJMDhnvtrWn6tLB1kp54u0C+IkKvxBwP/HNfyyz7ir0YNEDfx1SRCIKTms8AnN4yjl67fNDiwMtyD5D4KKQ98jWZC4SxW6O+HHvbTQHwSQ8hGv8ralfnBQhU0mlcjXh+OoT8RSHsWyFhlvaRPHaNbNDFeAcab6zUQbe2fJ3KtgnmGaengv38r7p7f/VQhrLRpp8T71/6YtMHzfD8J2po6DNwnUtQnhyP1HQSpj8sdSmavvljy2WG37cQxH4NyMPCQXmu5+h7tzFxC2zeZFH/Cm6Kk3zqP8wEoP4J+5tGhOy0V3MvBZzqDjfweB9XgZ54CXCvVze1IPe2NO1Gxj8AxBuBDlsbOWOuZRkPL43m8AiGOb/NWH174YxqOldVBxc0R5yNAueaba+JvC2vrqBXUivrLX/qS3/d/7+b7VqB2drfL6Ff+J7/2NpN8dnLUcEwadfCyONt4IgnhCFuKzsRCCUKOO2m1ICiSnaMJTdjzE2Pl6d275f57N8rB2roUJQnFpJftSUMYvNgon48qKYzF/pAyFDcKXkqhYi4tblcY3jqc0MSlIeSsTHC8DPGm3/WQTxXmqZ6kXpdlBUvGHVUGwdwCtnet9iUcTJX5eQm9WsjgEWEqwXUgHU8KJ6wsQS3lUCL09MoPLfxIyUIoRtBASN7YKE+Xly3Is0Dm3ZoII5ydRNlgi/DJkydWom7dulUePXxoYWwWQVy08RIxvEfwYvcCutrxLhct4+N3Mq2TMTAN+OWMApUFLB0KnsmoI1lArB031WBQozTVp/vyg4bjM/QjCwg2ooF8isMYn/uJOILhQ5jaxRdviH9K5XDvVGIUh6I8Mc7RywmXTdsiKxgvFLmtY/xum2wrBaoTO1Y8A+adgXEpi5OiCwFpanKszPAkd3aqLMxKOZFiP6X+ygNPhI1z58RDnkbLjy3EQss7Ujxh5ogi7yOMlbnZ6XJ+aaFcvXyxXJGxDkTd1D7bG+tl9elyWV1+LPOkbKw8tdnaWC2zk+NlSshnJCDxzsKk8qlDlD0p31trq873bPmp33Ggf/FiOEng59g50cmTePGHdoefIqoa9U0mHngkJhFF+6GMRqFyy5rLuOgcjAvYCAuZtFDAaG8z2BzGPhkibMAfUtWU+um3CUXATECM5dvOqE2r28Jmn9t296lh+rpJoH3Ih7T9/pM/RiY75RpkE1O/nc3cGL4MAtFKP03h9mPr13kdxA9h9FfZZotwtwcEPZMw2tq2xlfeEYzfc40NSBnHGcNG38UlsiYxHbmMoJYtv8emHGp1m9aX/C6Pwunz7LIQPqZ+S99C4MWmXzFXtzUi/UDGuAlvRv7OfcxQT9n6Og19OnQIDwa87quNRjBDDvHEUVZsd+T+MBl2lcQu4/UapTrwbtI4YeKE3/FRHV3nemiWuhlR/Y2iJAPGw8xVvRJklD6pBbX9XSenV0w/XWRROPVgzmD8T6pNuVSGB1h+f0tt3vjV2pH1irytZPMUuxrzXW0E/edUUMvXPseBkBYfWuM3f7GrYW63wifacgw+R+F9dNL9kTTY6bduv9o/4bvLsMHd44ULrNYRU3lEHgJCWcDxcQbHGQFUAEUbqr+jra8MT2sOGfwZBqmiPjQUnhPo7fCQBOIqLSd/nOxjQK+yYSU/wZA6B5/7UQ13+TUiYXbYMu9q0MlGP9jAkfDnjZPq54V9hK9r24FAWogYDq2bNjYmV8rqfPJ4XRgGSseYNk4T2hufwRWZ0nNaxdnF2yQVQG7FeIz1zw/HjX5sWFObcX7cooEPS1BTbjsZkXiHYDOrCBzW4mIfMceANJaX5XJZFaFlSeYJ5gutHdidct3qbH7KQAtQLac7oawOHAefM/cEqGWAEGGP7XjmaKUFrROJH5pjX3npuuX/ZcndyOCsq6M/+T/9tbdRWDh61BZgGtSNUE1jfAqiPgrD1UdBhNo8PZPsV6ZGD8uMJtAntz8q9268Xw6kFEwq/RiCnIkXE5VvV5XPLk7OvfNEB67SPHQC0hLeijK0Fhek0zlL3DItDMJAYXppBAgFFJ0nlWlABD4agXJ83GQ3x+64KYP3hK5eu1ZeeeXVcv7CefOBtG3BAAG7LZPwD75VXoVTICdJaKKT8BKZ62nFZtu35D15sqzytpQPfgu/BZQRXw4xNzfncrz7o8+GlM5lCdLc1vFUwvS9e3ednvcIUE6sILjNegoQ9LB71QHsMWnuzgkToJz4CYPiCKc9wcnCTT9InfQrfNDn/tHsPtOehhCXvtTrT/3lGY/ivGuoNuUyBsr20TqOtikuvEIAFK3CS0d2IvLzETqMwXzmKYkrR4DDiFbREujALWFTCtO4DO8SzExL2eQJMwu//ChUhOOfmpywIord+Edb84TdCox4BZ4ZKdGL8/NSmpbKlUuXyqWLF+3n6TXHfFh5DyRo7rJDqXGwsb5qs4bytPpMytFa2dnYLPvqc2KCn/LxBJoSDzRg9ze3yy5GaXY3tsoeO1gKH9lVWtWV9K6beN5vmvAEnSi37gtwQ19YaGFZ6XyxiydJhREnc071grHelTRfERJhqn4VT1ogY422SVt0ER0IB0/gaybSOJ3wqjl77hpOO6XvVD/RmcXApF/NC7KiKMU+DVr/HvxJOcZSUbkucTznp0+38FOhL7rla+7m7w/32FA/ibBZHzJ0fo0/+mu1EVidlrEEHtrPWLAzh9kHbr7VhnXww3MR6XjgIzcjMg+6ZJQ2vFUbC48fWhEm43EoxZ3FHBqMt5YTwV51YNwnOGXzwdZPs1PX4JQzfurQZzJvkKe/X4CfMOJrGaJfIa6D8dmd9M7jcPIqnbuz6qsEfnCi/j4uOngYQn1VQeHT+IAnGHDoY0QpyvzSULKbGzrbupJCFe6k4W/rlmTHzxxARuYn92N9TbPMuNJMCU8e5HAUWPONeGoBrA+PSXF+8uI3hRVMYIzG6BHeNUe+pDSQO20jI4Rpv9B0xC+35021u5WlptBpzfOcDlJj029fO3WmxjVI+bRd6DnN8JP8PWAqOOL/GMbQKi8wXX00NnCSmi7hn8z4V2X0Q+bNhDcDdPOpc70oAH+zgxfLZfCVhy7scIz8NRkep+vRZ2soBMdw86LhrPTB47MY8GX8yguvZAHP12O4IRljqR9nL7+8lJGfOo4y/jBtTDWIS2HCx+c0IIa5KCdumHnyiZwnV6MFUBI/OBU4LN8O7AZXtZV4iNFM5DJinE3hPnaN3Md6ZmWpynVK381VFaDDH3DoY+jwn2CEBAveteQuupZPfKzY8K5bS/0JvHTtuuQ83n1f8brLg8HRn7KylONSbeGKHZPGIrsKk93zV5DbaetkygI/ITqnJelNatJ++OGtcu/9m+Vwc0t+paWR9EEoa8oSt4qNiCCEZTMNcOUQfA98dKq/o1Cmqw4DKxP6G8RQ6WyCew2qkHSuC3Gy4QGUIUSgMPmWNJWLsvTyK6+U1z/1erkoIRihknouLi3KLPldIph9wOUTMLt28AC4q0s2DYgmjeABBaTbUzkcpaNh2KXiFo5VCdC8y8RNd7xDw7Xi7GxxlpKdJAT2NQnY7DbduHHD79SAkwsO2KFiZ4pz+SgblO/z4QIf0RHQRmnHdFoqTyflKSH8J+45hbmvItSDhbIT6pSWwU1hrQl4OoKbAdGUpRbfBirltzhupPNlHWjwwsk174RzsyBKazualy3q8M6mth8MBWdT9jwIlT/9GepJn3zU1dmIq9UCgetN+yov5U9NT/pIDG3MLh9KKwKlFTLx21eki6fejRSdKCWL8wtlVu02Nz1TFqQwcSHKohTeObWnFTO155iEtNVnK2X92bOyKqV3Re2Ivak2PRSecfFlWsLIlASmsqP6qo+UHRnec5A5RFmSwS8tWwoVZ9zEH/GG6RBFCzp5Yu3qKS6XkEj4Vf1gEIMfRQgeuI3G1cZoXBIsOS03UjN7rHpkxBhACk9lEwLf7IHHRMrNco+fURGbX6Lgs3yU0dw1O8ZKnhy4nZM0FYNNksvow6AdBkk8wPBT3eCnbPsTbj/uamcuSdzpoHg6IentPQFn9ad/Zt7EtDHVjS0WFJQRtZsVEpk8DBEGI6GF+MTVryzF4HFQB6RlnBAMrxvPoygRKUyMNxRxytKHfs78xBhrYwvwXKA50vMFhXXl6cdt3LPhXepFX8vYJOy4AbUs0+7sCnBaedw3QK9aEMdOm3c1FI9Nup5b+WwLDwrTyEHGhQLIx4M9HjRw/AjlUJOPcNPPKr3VwDCaMztLuIVf9fBfGhAv4x3REz7O7LkQfpJZZSiI+rXjjpzEmBY9k5qn/dcPGvvM2S7ftPATmpzfbgfVnxCY9S9lUWfKaHUILieuoLQtXgktmMmOX3yr/ozF5EtfxWTOJrw9nMKmeAQL90+lUwK+KVdfqOvBUd9xINZ5wZGgE8Hp4hwKpDWPTI6Rh1YKquA0qk9NYfuTAf1Jn1oGfSLt1AcmpcbXuFb6JwXQBnVowOkwXPbXsH5DOA6gpakBx0k/GUgfvg4zLxrORl/4TNKBRj9JFb6kXo0/mPTzVo9e+MlGP+alsZvQ5Gt4XZrLZB2Ef42HPXcvD5DxeTTsBKjRrol+snvFeE15DYLfVNjG6tyCVkpqcbbPkf7M1/MHczYmihLlsm45h+vbSlL5/QQKnGbQh/z6hC+uwHOQNMFFOh4+9tYVhSvP9evXsrP09KnXLJS+0Z/+n//620rpyZ/ULoqMmmyd2wyNccmkMeKky8KUJ55Z8COkccPP2P5uuX/zg3JfytKIBLoJ5ed4Eg3Ay7C4YNG0FAGu8EZBYRFnnvXiwgIkG4VCHKZgk9QP4UVfkypNB6TvzyM36fCH1j7hw40WfE0GAyt+3i+6evWK3xEiEf+NdPHipXLp0iXvJvCi8LPlFSsaXmRARLk2LFqy68KKMuBz/loQ2Q1iULCbxvXn3HD37NlqWVmpDaR0rruAp43sMiG48/7L/By7TvNWkGibRw8flZsffOBtQ/4DaV6COnnSMcck6Oz49irKAze0uKPIz8ABcr6UNqXzVOGnMqO/06c+1LOvrhI5krL+EiZj/spvvgoHg8LvBFGm4imLvgcv4IuVDn383pjirPwgtKm9eJoZRRPBJ7jNb33ATVomAgrz02/oIC0BEut7bmzgwEeLfKQQvD6CE6GA/OwwxYxbceWpr/0SCBC0KBsFhZe1uWZ8c2OjrK+ueveIY57sOs1JQUJpOr+4UC4sLpYLUrLPy+ZFcgyKzaHaZXd7K7tHW1tle32jbKofYPzircyk0k2NjmtcjZUp2lBhKEu7Uq63Uba3Nsu2zJ7yg29E9WFnakJpoZ/dMSugCmNjHGCcIUwimCmZIuCs+K3PqJWl8M1h8JUkBCuj2xcENbD1g7gZqyBMae5DJO0zSUo79vzQYGEMt/GknTAVkwGyFIsrAQMg5YS+k01LE1qMEYetpGkQP5ScDRp+sDY8Db/j5OzfUbIRE9rc1MLczwzkoXXqpy16TViVzaROKi9KlEFb6ZOvGRdaZMCb8SMvw5EmJn/lLzFpBxazvYxNxfNQBbpNEX1RYyJzAQEuKBZ+ypcji6T6mtJ63NpPnoQ7jfPEVmXkYYenxadP0EeIbv7wjHkEg5ChcNw1n7q3aCU9Sob6tfzsKrHjy84Sfh/z0zjOwwblI0z5MbU02GLeYijc/5uWhE7i9mi23Uon24Y8MvDOO1cKi8KWeWRS9EzLP6X5gh3tpny6+IoFt3sBuBwiSNE93K0s2fDDbU8a/fAxVAtwqOJaG8dd+0QXBsOFn35GH3MRmWs5Ro4SzZqGn3LpG/SJYwVVILO/ZwIVHxqq/zQYFt8PvXlMeEVnq7uh8hFD4Sn542A/CY7RXyuvUmynlONlPB/yV4FQXz+Nj/qxq89vHsQZg9+R9igMfwJgzXDI2CPLMHM2fGeHs+JLujMkbkmgt/IhtMtWHTNWapJap1NNkPShDL4W0k975Ks2NlOGk4JAQNKGLyEnA+mMVonsViGWkzyea4GyUi/muRrW4JjfZfEzxJhW265lh9/8ct+odSKRIPNHL5/BBMdRrZo36Y4b8sWuWFsmgf3YLV37CF//XFtzlutXr1pe5m99mI/9asvP/6f/+G1WmF5iKMLVJkcmD9mEw7jKPHcU5cuTTy1YEuLwK7iMa3KdZXtJAuDdGzfK/Q8/KKOaWCfIy8QqfLAGsZjnoHMSHlGWcg04Z+IjqIMXYQ4awlwhf84IQUjyYnV0oo8x9KUD/HRTaVNX/TgdNs7KRNHBTWUIu+zuoNRwoQMCOzs+vEeDAA/e+3fv+xa64Al0NKjju0Fkc9McT+KaoM9DLAR1wMKDykUouXPnTnn46KG3ARHCYR00QA9KEO/4cNEEOx5XrlwtM7J58ru8/LQ8ePCg3HjvRrn14a2yxrti7JLwHlRlAAscx/82JJSj4NFRoZPdqHSc9Ac3l9qKizfcmeUPP0ey28OuigU1QohDCELA48hQFny/nK0E/YM073wlvctVPT77mc/6iCJKIwqi+51wI6QBPiInXhNH5ghcyQ+knyrChsGnMsAjG8HLApH6JcnpowgT9LE8ecZtLKpHFn2PA2hV27h9hAMRAOEGJYcrJ+dnZsscu05SpGalFGFboVLdEcjOMW5QxODVzrZtjuMhZi5JeVqanyuLUsCXFufLhYXFssh7ccqLsrOp9ll7+rTsqO1RhnbVVvvqewcaU4caJ4ynsYO9Mq56cYxHxVngGxF+4g8ojxfyVeaIaODdE/7fDCHSPKCOykO9U3fRytjknSwpjfAFIYlwgLQxlW+y24RuhEQiXvcSqgTCajxBssDZZTlmTAt48bsNsBMHNL/LF37KHmbODNAF9pqnPz+/nfuMOKkHOY2HgGP5HS5jZch1Tn/2U67qb2kw7UmgBfZuHGGOLn4uVfl7i1LP6MdlY/sIFWVBI0E0tQy7dfCXsdt2lcgLfsYifua+I8qSxjvA/Mv4A1WQBRdpYlMu8yA4iebHiW23fLQ9fZGxmHRJaxxtDLuOpG8PQeoYNxbC8Gcs4887Nawp7CjJMLfLZtOdnsr4ViUzLyhHeJb+a74z/ZEMdIpjvaJeTSnyTXh2ye6jOZCM0AZG+Er5VpZkT8rP+4uTGvv+n6XaB5IVfNQZfw/PETBRLTzp8yCQOsjwqTTp19+44k5d43c5DusLd1Ars/Y3zYmZ2+l3LX3kgRcFHQ3VfxoMi+8HjxFwVuNCGijOteTH5RL3cbCfDMZAOeCv5kToo+WTl9oHFS+W6+S6JaC/lp0h3AnscQrzSnAa6Uehl34YnA3f2eGs+M6ajmrY1DrFn8CEOdXpbXoMnEx5mMtqZof152/j1mV0pkYaaj/Fdt7TDQmrReo6XhPovqiPsJsmMrQ8nanl9hePe5hJ1qwjrk+rk4FSk8b0WIbEdwxOCDIel/A8HAnVfG1/DWxxnd3HW69zsiHB8bKvoSxJjuLqcJQlca6M/q3/9W++zaRPiro22G1GNs4pzPWUoZq4YYCf5mlSZoJsuzSyyvg5KUvjEpTX18rt997zUTwUpTEx5sCCsBZe4dlTGP9Ds3j+vK9Xzn858b8UHPHSYqZFGQG58cwCBBWDXjPfgfrGbYGDRVxxQPJBMR+gpUs8cQgfXCzhBUA2YHyqSCuLRYHjcX5PSMoLfyBrgV7hpD3Y3S+3P/zIf2YKx/s7ZMPXDQCFu8GpgyAdlgVUi6caJWfVWYRz29TK0xUpPw/LQxneVVqX8sM7PKTjD2uvXLniu+Hb9efs0KD0wMsH9x+UDz74oNy8ebPcvXdXytcjK0coXeT3xRVz86KLfy3etvKDotP4Q/1IT/05ltN1aEVbOLOz8jKeXr1lzFstqh4MzTg+vLCyIwPt3PKHMLYupaD9+SVpUVCt0MHTmt9CJXmhsxbvMiuwsOdSkghU+ElG3hxH6ylA9DULYTUNbWOBKV3MAlQztBjCFgKNryBWe/FOE4rS/OxMjttZiZqRQsWROwk/CETkaUb9mveifB0x52CFlGuMF6Q0sft0fgElar4sLshIAUbhYmdpX0oPFz/wntO6BvDm2rOyuykFakfKkxQkYbSydE48HLWt+qn/HPDunforeTc1HlEgrbRxl7fS+QV+yhBv+H8WaOUFft7fYIJAOIUPHuvmS4SwTDBpA9owwjkGYUnclF8chKFhZDvjZSbrW+3OLyvhdgWvXXFHUE6bptxa9inGi1EFnEONEzq5/MFhdwJqul74MAidzuS8YOpwNVsm/bivLsTVX3WQdGvav44/j0lMNyaw67gS0C5ZnGr/b/6Ku5XpnVv1zS68Ng3tyFzOzoePbBImt+dslaVoKUv56wTmKOdxOmhlToCO0ELf0U/KgAY/mKCujnba/k8XQr3Uj4On4Qo+90F5KBLTKVVK1xSk5hbj7M+14Sh1GC530DzJ+iKDn/+YSb7KP7kqiTRBNVBGqAlJ/YmX10fwnEEhLYl5Xr36kdcPKuAr4x8liYsxrLgpkmN47AIThwINzyjY7UpB+XF9TVBK9wegzi5XbpdVy8dN/wox1IsULVeCncvfnt0fDj/gXWs7F08scQqzDCCasU2u46E9dleY8YFbdi/wVCBZ65+DYFj8UUj5x7G28ZNC+dKnHVDtvxp0ufvQmPut+pQFPbXcGvTiALzVcp0pywE4e+Uy/9fgGm4vHoXVdILGpsFgLHH+kOFs9FVw3U834UPf3KxgfmL5FywVVDBhp5iWnrYHg/HV/J28KHA4gxZ0DgGSF/A8RFrbWHVdGPSp8V4nqgzFp0Fz98JrnIpsNMbdHMNN+KW5VfOc558KlNHWq2ZYzzpw0frBFipDHz7WJ4fLfZrhA15nrUjyG38+JNWvkllukb/RA/QrS9QBvoz8k3/+h4e7Wni5Gq9fIO0Ko3AZJkUwc1ROkcS4UT1Zoj0yYSLwK2xKi8f5sZGy+eBu+cZ//9vlnT/50zKvvNM8jdpiN2PPVx9LXCzjEghfe+NNoRzxf9lwUxwvxosQCbLCq1qws+Lz8tAGUZU201n9uE2nJm38Tdg+qS5mnIKa4NE9ISON6kNdUJZ4ejgvARa/l15w6YOfnZ0p3meZnlbESPngxs2yi7Ik7MajQugkCCoWSmgQBTbFjDQxdB780KYAAfRs7Wx7AXLZ8lN/8vLeDO9K8f7UEv82PD/n92L4bw5wcNyO2/MeP3niO+LXpOTxfsrG5rqvH+ePcS9duui6sDuCH6UJWrhvnp0d6uABKzB/UFhkE0J7m8eVWOj3t4/XLcxQ69Tvb/3JRjxiF+rChYtlc3PL16TTSUlD/cFH2SBog65rRxsHKV2jAQFJdRFOolp+1wO78h+bzBxpJKGvBiZvpYuOR39zHhle5KHe9HHyUZ7zuE9CB+2LYg01xEtcUyLScM0472TRhnarNx2oXXc0Drg2nDSIJOzK8eyZd/e2d3hXa0959pVmXwrkXtlU/+J/o7iynHe5QjOkSchSPfivpzEMu48yowjE6sPE81BiX3QfcGOjeHOOI5o8HZdbFVN/H/MRKfJIMirrKFpUhbGtvOY9PFG9aErzW/XM1eWEhSe9uNiGESleI4wN+lAX6ES1+Qx2O4xPDRGSzt0gkmmX6jSgpLZrOxhIWekSSvpVdeJ5zn8WCM9Mfv2hBPpn/LU0C5gVs39beD+wY+KMMvRF+qX7b0usjG08ZKcqc02zTT/Z+YBHfvoI2f0QBAFcNuMGamzAKZu5mjmMvruNYq4PY4b50ZdEqE3Z9e1wy4AXIH9T2tr815RYl01a6oPdZxRYDvZ2RAcPRlIPlBivLyoXv3EqKQ94zB8wyiYM23gA3Coyc7D4I7d3c7iBUiY3V4oGlDP1FXZ1ks9f/7jXus9FBXOPVD6/dyv8otY2c09bI/hQD78LpTDXRXk5duujdxp7PKjhBjwud1gUTdNSlJi3UKKoN+1MXioV3qm8bv0lTJbLyRhpYwubapC+tb/7gOAIr2t6QCn46dxOX4PgNXwHb1POnU7hxLk9ZBQgFvIwNPlOA3JHyDs9HWlMAvNq9adv4MJf6zAAx18V4GYbXubLCwLTzHxZ69DA7aPGOltZ5O03JwMx4R84K2bKsd0Xjlv0eBcW28kSbnAe/AQw/wwu90cNL5a+Wu9UfTgMSlfjvDuvPs34JpB5nDmM8YCfcOKZ5100/K8G6MaucDVZZiBtyka0L26S7T5I5prHuJpHoJKcp7NruZ3NB3e8Q6HJcF6zPHeknwmJcQFGp/kDH5ScjvpsZbMG+LZr3BiXFfC64U+A+Yx1BX/TB0Rk+cmf+FJZXVsrN96/WSamJrzWjf7H/+h//3YE49o4QSFbRp42UWb3SBUHWU3jSjttFn3vBslwpIA/2tteWSm3332vPLp92+9cjCk9T8j93o7cByp3UULyS6+8aiFtgxvB1Jm8+Koc5l/wowC4grWTeQJttomWG2bL9qTtXKqRcLRJmbXOTFM89Wh/PEq448lR81so1oI1NjFeZmdnXMN2PAzFAZvb8vyOytp6WV9dK6srz8qeBFzOcRPvsuEVhPRB6Ie7AeoAPQgDQDv/zaBnl2iG/+iZziUSXN7AMUAEZhQi/sSW68RRMP3ej5SdHH8b85E2K1XiL8pUhBpuWhr3/fFcDHHv3j0L3fy31WblvTuLwHySgT6DmNQGqQcbdejCYjx44TcDo/Ldiz6V1Q/1pq6mQ4bdLcrhKTm7dlyjTv3Jk8U3RVvIgUcyafcYxzdGChKep+I8sfWRM1qP0UP59HETIzA96d/sZtKuDnNZqTskUHuGMbiCT8mU1u2MQiE3glCvTAlEcvvptfpxZzQmvKvEk221wcLSvC+Q8JNkynF14CO7XvSzXfuXlhbUfnNlkXeezi+W8+cX5KZPcARUNNZrjkdpN8bWFjfmrZXd9bWyJzdH+tjR5ajehOjnWB6irVQi2eKH+jVH+3K8b1t+juyx+yYhWXxzPhHoa5ZleBgSWmM8+VRjhnamq5Rs8dwvxWC3tBWBfuLP+KV50kSE9eKyc8XDk9iEG31N87wBH7jafDUAlK5HT3A2O07ZCeD3TJB5qJe/5W148MYQIqNKU22PI+aOatO/qIOfqLl/xOA2MuWPwJoxQ9/1HFb9bb5pdcHAOG47zO65+rXzMb5aPhLWMkguv3dPRAfjlXmRfJ6rRAtu5jr6bq1FIy20qc83Gnt1IH2tJ7ZxtbCMAWz9CJfKhQ79sGOSHSJ2YaRgcMR4UkrHBPPfmC9QiV2N4njPkPLJi3JEP/bV4cqfy1CobsrInEexotELPLQqng/9kL4nHKwbap0en9y39ZVxXW0TxI6t8CrMt/Apv3eTxG/mCStPimfNhLbs3ro0lRv+VAJUBPSEJ5TJR8Eu04a8ChHa4FBg4oLPUK0G6Us9cDrSHEkXGkyPfB3Oir+jRn2APmGFoOZLnKCmbehbikFA+lbGiwDjgzkCl+46xRhcFm0H7xOkwGq/AOirciuz46MZ499PDK0YoZOhR8SDv3rkrn4B9W0VdpIuruWRnYx9fBkM5iv2AANQ1ouEs9FHvRjn2AOMx2LmSHlrPiMQ1B5cf9qYJf5Eow/AHJewo/NM6w9t3HavKjg0xaSopG35kJ06/2lGn/YQBwidMQ7TN3Mv80krEai+mtY+f3v26Z+ajhKEl3m0lYFJsaHHyATNZ7uWZz51cxkmqRv+kz4AvAGT/Q7K3Jj82ElJOvd/3M4S+q5fu+qTYk+WuT+Ah9iSsX71H/6Xb5OmHUtqhuwgzEKaxYmJnAlTCWqFWcSzwIAQQZ3jDRwpmFaa9UePyu333i1PJZTzxgzKEu9sdIusFozzly6WK9euS/CbsNDPDRQQHHp4sr/vp5rssKTj0sk04bnWfQZ6RQyLGcSbPH4qUBcLD8qLMpQLBCTmOm+ajfxWkhDkZfBz/A4ljnd0wIeAD608Fcz/TGghVoFrz1bzhIAFA2G6CjoGkwfvIIqOmeNpCEMUD82hLY2I4MIFDbhRiqLIcGHAuJUnyuUoHooaf1q7trru7UJux2NnhsrzH0xzMrQd5Vy+fNm7UZcuXvLu1IrSc5kER97u3b1XfvCDH5TbH31UZqZnjZv3phrpdCi6lgXVWg/X0U+l6QsuEiarL9S6WPhid8eVJ7LyPkcN/Y4b7Ui8Mpu3qh/vV2ED0GDlrfLIg4ZPQ5lWixMgnSLpk+19pSZwkCe8pS+nr7b/HUq71LYADSgVFmFVNKiulVKn8xioxkKQ8Fn4kSEfaZuApOIsELXriq0wcbe+hCuxSXRwAxYXSNQrypURIXFP/W1vnz4nGvj/FylFdG12W6ekKM3Pz0gZnld7cl35hXLlwvmyKMWeVwU5mrfF9eRcSy4bpelgl2vJdyWQiQZokUGJkobv+D2O9Mm24Q/YTH89mic+j8nG+Mie/NQRPmPDL/Osv22q7Xc6OkUp7ZAMjGWlhwkJtLFwCh78pKkGZmXcR1EyChvcxwwf0AnSfygb9Al/zjiq5u0zgN1x2A8k/bE8iTI4nnoZiK9OwOntyIc6CejJ9EP3RfkipPf8zLFGLGjv7bSymRt7ik7jD+7gb6SQx0jccOE/aZI38zs26dzvZHATj58xD7ljUkLAQUs1+jwebMcQm2KE3zRAC0lqun5DPaubfDH0M6hNXRnXee+IsRvFneOwHIG1gqT5GNtHX2W8c1QVJsY545jie9eGRzmx8t/KFAnwwNBHnnmm8tP/MKKOepCBBF17hM7YPcNdKZQzprzdgwfxmTmDmy+ho1OWFEcbGHfjrYxQOMy7gDhdrp1pR7nxhrzqtxE98rQ+4USg7APFOJwoMtlvd+LwZS5NPR1KXE2WOSo79ya5hnfpCACvw+MmneMGGKdujuNEG3p0nMXoV3zpPAZc4Qu4YnC7ro7nU9N9QnMStDK7ss8AJ3OiB6BpqIzXjuZu/pTX+d1wTuZwHA53fFwfByq6oXDWOp8VUi44BxmNy74xEaOYPkMy6u350Dnym2ox71U7VsZYTXMyJC5zKuXVedbrHfhAwnxBePqfwWnJm/wENxN/8h+BE7wamXabSqPTj77Ob0MsMknKJy5pe+n58AVC03BA1rWiVk2jreHqxwnEmbI6ntZ4uytUNKeAyuKkBE5n18f1qOM/wQ6HJscRCFLTGGWJ/yzl1ZcoS0r3T/7Z7/D8TlrUtoRkLh9gMWPRYHeFHY+qfNRGZUeAY1IoNTCWI1wI31l4swjMK99Fmb/4vd8r3/r93y9PPvygjO9sS2HiXQp2ZTbLribfiRkJdxLor3M192tvmPgffP8H5eH9e2XaFxIcqKztCKEC4vsbKcLsgYTK7PgACOKmtzWOoDVS9RFtWknIbgrKGO/GsBBTHxQlOpf/80mQhSBulIAoAn182VfabW6ay59r8b7QhoRPygUfO0QITwwUcKsS6QgKw0QRrMqA4qCTstsRMAQnU6840rZ8hHIskv9o8sUTSstteShG165dK+cvXCjTs9MqUwKDhIYtCcIXLl4oS0vnpVwtl8ePH3sX7N69+93/NWFoXy6OuH79ut+JQkG7fPmSlS2UDK4656p30sILaEbpwia+KYLsYtE+0J6m8I8g9WzCXNr00OXSx7LjlIsuaCdwkoTbScBrNPIr9zEcoFH7wmdsJXQoaRXvbKRrgQKeEBNOW9HmtjHwQnjwUw6Xecjb1Q2CMrEhSKqPVMWxKYntkgsr7+BXXFMwd4VoR4IPO6s8MKAvsVtCSRy1g7/PpABvcLOd8HMMb0v9a0v88X9RqWwr7JPpW9PjU+X8/JKEvlGNy72yqvyPl5fLg4ePyhMpxWvqG+Dgz5+n1JYcwRqb0LhV3xzn/TXh8pE88VoE+4jgtmg7hH7119FR9VmFaUJQ/VQ3djCV79w4I1rtpPr3G47maUiEj1RedT03CncrP+Ed7Uo7q37whMtRUNLhJTcxev6hPKWD/8YlpG0HA32Tna8Ip2lE+g587tqOcZNmFpDOv9Xb8yuVIL/ENj+0QG8D0rd3+lxmH5AuQiN2Fp3BAN7wAVRdWeDRx2PebqUCH7RinFdgd3ytT+NnV94JCa/x/QA++vyI0mF7J0UOdktR6tmFUeHqR9s+8gVulI3NzXUfS2D+mZZS7hvbNAcw925pruO9OzHcfdw76srHvJ2HIuFXx0v80BHfMSoTSttChxmjMNLwx7zduz7Ywu/dIdWBBxPwSJ3PilEeVKV/wMq1jU3b3pFSvvzHUox3mxnc8Fv5zTm3Sx4LQMaeMu/tsdYIv0JHJxkrZMEHjZTWc2UHm4cNoksuZgE/NBFOFLVJ9SP+O6s9vOAdXy5G4iEFfaIt6q3+PTtKJAwhBclsKDPB9meHLGGB5mo0ng0aTivStImhh/UonB7fheCgGvENBfjbQV+ms+Y/CswhrFlZU5h/cANNjmAOYj6i7U3sX62gHrT60rfsSPBzoHQnjdfnIXjariuNnfaveavfCLtfAWmIO5IuPs+AyDfC16U/CRTZ9cv/gQLsd53dvoBbxXX3EMNJSHWfDv0JmMfDydMzZv6LnEqafj7WshWU0Dw0MaaKLjTFg9Vo9EMbBx+n378G1k7Nyp3/OLQYegPzejdX+1tzNTdeEZl+0F+H54H0jCWgrQFdFuGHrrYmWAayq0GfD2ctN+nosTVvsh/zy804VzrPpXU+dfnEU67XFqFUkOstvISzm4SO8xNf/EJZWXlW3rtxwzxh0h39pf/0H7xNpn0Jov0DhsnRixAFmYhoakzupKEpWbB4Gs4TPhOjeJ6iceRuWrR8+P3v+z+WdrXIctUxR4V4YugGFh4Uh63dHTFg3BcNsHPybGVFi+9WmdLiy0TJETw6YlNiYFZPuZDNxMeiozgmQBMBLYrzZGBuYBIVd5gNNMEYRoObm+YQAgAzFFsf107fHtNheBqlMd5+GfD4ogXRjHBF/lZGqCCxQvHajuncwgFdpFUN3diuqxdvOnLKijLFOfvxTikjbPXZMwnKD8tDmSePn/i4HmWySwWfUITgtXeqpmcseJN3cX6xLC4umgZ2+daerZVHjx6Xu3fu2OYaxSePl717dU2KlBVH0QVObOqN4kw7EOb2VFreu6ENCaet8/RbvBfb2hE4DMpSdpPqrps+blcEO9WZNEwibaKzcAq/zBBxS2XQX+m7Plaj8DS3f8x5fnr9gm6IECB85KlhMfH3m4BwupwoOTYuk/ZR23gMQbtbKjTQ37W45agP7VrpAo8cskwzdqbICMc+bjRG+1M2QijXnPPuHhOu8I0wIcDEPV8dzhFXwjieNz1F27IDNevje5cvsau4VIXDff9B7qoU5qfcuPj4UVlbWS47G2tlf3vT8wC7VXPTk96p4gEHu0/b62tlS2m2uK58Y0MTy6afhiOUNXp7L6/DI9iqONkcRXS7iPJ04MbqzDMWXtRfqA7tQR9pBkWSo6VW1GQysaGmwSug2vSF/jDxNk/qe5MmPPd16Q6vcfLTvrQfebBCmb1x20GdMhaTNHgD9EOslNvrL6dB4tO2gZPyuBxs4bfbJrSSNzTIdl3SD5N+ABBJ25APfx0r2D7+pva30C6Dn/8Ho3677DgqgqPJAR6ecTukFGfaWSHZTY1CQju5beG1w1G8qnJDeDUZR0lHHvJ6PNV0yUu6xDeclMV6BK1+1MA4E+0cIYVfxDec5M0V+tmB4gREo4UxYfxKT/ulvPQ1aMt8RZtjw2uVp/4Nf8hiW3XH3fzhBXQJF24Z7zApwbiNypWtFStrpmih/OCvtsJtlCZAH0jbd3EnGaVM2+JqpkHCz/pJDtEv/qS+CT3Z9HIdN/2QEZrfs4CHVHU3eB73GfDRxYXMPFR/aPOBoxSOXOKHXpTneuqD/UlMH4XAiWkw+pyFIx22EGknFvl7fvt6aR1OOf6tfqxeOgx99ghNx41TnQ2UnF+7f5gAW4aCyKI+XitqevJZjoivw5N6DIPwZ3B9KVSYJbedBEf5y5yeebwD01fdfXSnbewIDfkS0PPLdvKa5lSjscB8J1dDYqs6a7EaP473byPjOejlIT3JaxlkdUSXQi59PF/14CS8pAhfjqZ0Wn6aw+7Q2avbMX5WMDbFM78Rz/hnvbh65XLZ3tn2/yxRJpGj/6O/9+tvO5cWGQZLbsViAmcRyYTuQSQKPPlXP4sQRx8wnkjJqzSkn1Lq8e3dcvO73yv3bt4s+xKseF9iRMKeF2XwaHHgqfqWNDkWIi5MgNDVZ6tlb2fXTzhZtHd50dfxE07nCc1KQu+JHotZE1yNnrLaYoFbBqe9+XE6H8GTo2GCKQhtKAGAy5GATh7iIrzVxlI+K0dGROJiYZ88XOnN/y/xP0hKKQUAIVd4mJhJT3nkp2zXpdpVacAYLY9+Ka2rQ/KT1kcZ+SNc0eo4U0U8dEuR2tu3woOixFYiu0rPnq34unCO9dmW8kTOqelpK0n80S47U02RQjn1ERaViaL11LsVD8rDx499I+DND26W+/cf+D+GUHJ4ioDA2wRfBBR4As+8SyA6qT27eaQND+C7hAa1t3kvd1OACEOJgwaFuM4WXtQPqCu4+CHOtRf+xIkbCIAOh236NY/wOKDzE2c8QI0jrCnbaXfcMq4H/axfiEqa9k6fL8igUiYMQz1RlhJmmpwHWlWcwjvFToYxZMEK4U5CnW/V470LjheJH3kXA4Fvwm6OGkk/8dP9A40vlCh3xnPCowjebVpcnC8XL50vl6QAnV9aKIsLc77+3Ef+JFjuSQje2dqwIrSxqj6y9szHZTnCt8MFITvqJ2oz3o+KwIcRvWqPLSlQ20qzK8XpYG/bN/OhjKHEjYkGdoCku5kPnjdU9xyDQlCtgrN4G3d4yMMPJqzw3S0rRqUN3B7yHnKbX21j+BqAt27C8Je0nWn+/nDamfYGN/lwN38vLsJpNcrXS0eZ/gmo/RoljsceZIxDLd4y1dzEVeTNEg21bg6DDkyrRzXGl/SnAfFQST+l/jyh5sgqxy3ZXeL/vrIWaJ7h+LPsWSnN/IfX0+Un6mN7vqkRxYeHGuxkLUohBwdty07PhMa+jymjjLg9075ud43ltivUM/QHpXHaGLdTbQfqhbFCg1F4W4vArVSqlMYZ86Zo0uRiuj2GRB+08NCF465Zs7iiW+WqDOoBHsYc/VPZFNZbT85JafK7cs2utPEnt61N5O3aFBwe4zKspRnP1chv5Uhl2JahXOoCTaqacaXuaUtsELejl8avn9b/egZ/NdCHrbRDgUSDjH7A39HR9dVPBm3uF1sGG4HJGAJnwYflysAbWQ7Wj9dLr8MyRkKJ8C/2JwZQCO2wFmmlDTL8YreZhno4LI5UjxRxxDi+2Xb0pfM3fdgmaU40+rjcFH06VDw/CqAfhMABBquRh1s/ZGt166/j2epBmiHpiAat6RsGSqyvU9af0+hD6XfLkMVtBMTf8OBxPbCZG04zNR2ffqhFBZetlq6iP8E0cH0V0OGW0U+N7YHLr24Ad78ByMs6dzRlL74/2Pn6y6z+Bo7nA06Z48rSlctXvMtkZQkBi/T/h//nb2lGl0cTBcZ1Uy6IymKRhGljJmwWsMRHKGbKTzwV5nafGQn5I8sr5ff+1b8qP/jGN8rh5nqZl8S0v7WuyV7leIWQSzjWNrd8FOjSxSsS4GbKGjsRErCnp6e0oO9ImdqQ0KdytMgBbVKjEVxh0dM9JdLHL8aJlkyepMXWws9iipuP/CgkXgDAKXc7htcTznN1N8aLZxWGiUBoJ4+PysATlBpVi3ebAC5W4PgaOzYcd3siIYMLIchvBc3FxgaDGeqw6saj+viPYWmDWj/iSB8FS/VRMpRIzlb6nSrFwav21Bxe+SIKCcJjE8HDH+ry57b+01rxFDd/rru4sEDpBo4Rgg/+gJ+y6DS8E7W+vm46xiVsP3z8SM4R5+cSCXh34cJ54Y6bvLRjUy7SWcP78I5JWp1VdDWa+R8qFLM9CV9cWIHyRl6EuyheaoOg8Q94uq1o2CZ8FnwUhiEp9FK2s9it5PwIEtazDU7rEDw29KnseDAe8CsFbSBDv2OwEY7SQj8jjCKgJ27yYiuvI1D86Uu1T5KOOIVTMnEH8nOl/p7K4Aji1o54IBs/9FhwF99w0/fIpxxud46TcPMeeM6NomxJORqfdP/QfOCHFBsbW2VNSvPq2pqU6jW7UaC5oW9XODiCx9jsjuupTUcxwnVOhmN9q+oriKYjSssNe2OUU9MwZsHBe0bbopsb9/ifMI79WUkQvftS+M0DeeAaQin2gTq3yHQ4bmoGQ8VCBWr87SHUcwkAqXoADz0XVH42CG8SD57OLXDZJOiDzB+JOBYV3HHY39IhaDFWcNM2w6DR0I/fuOICTXXSx1A2hVeZXL7wt3q6j4mfTgo28oW0o1DDGS/cbMdRZ/6UmSPYKDgoO3SOabURSgx9mRsz+YuC27c/Ku/ffN/zx+c+91nfBLqLAi0aSLMrHFDgRcf0hICOjwLTOoAv4XTGGn08c3cdYwqEU1aQ1AmgFRslI7ul4ntVlORwOitK9EnVjbEEbv8aF+lpKxk/uKGc8Nyp1Ld9NFZ9131RxsdLlWef/rfPzYCUlfr5Ay7ZRkIZ1URRyoMCXw8unPB3gocC+LUYz8zwB+Lp352yFEpqGdAaHrQe4yrJTZ6W1sb+mGHQ2mkQoKjBTytsKfoTASh4MHgWVO5L1X0afBx88BbOmEeuU7C3fqpvELo3A8P5MwzoG2ci7szAXFMfirkulUfUyT+p31E4JZ29tGvG2DDw/Da0Mozz5wj4awZqIb6coR+4zsyXONw0/rEnYznh/PhhdEt4Kij+LNUVirPyr7OU9HT6NKdojnOy6ic+6exzMoxmN9+IdxaoxQZXX3m4CIMfx5Wbk8Dlur4aTeJ3xpu9pg9clt0EXsvsOhnARX7Lkfo0WoyIeJykqn6/Jo1Nmcyn5Kr93chqOst0sq3HKIjLznjl4os//nlv3Ny4edMPnfc03kb+yf/jX2s9EAFaCDIRV6Qy1lpdgIroKoluxVPACOVK4EKwuGp7RovTlBaf1Zu3yu/+y39Vbn7n22V8f7fMSVjfXlvRgJRSwuNmCFCePVUKUWB6alYLyHjZ3pTCoTJmpic9Iewqr49hUXY1/oGkRmdtiH4aweHGUL06RQlb8TSglSMaSPkiXO7Zj4Lj2/iUEAHdyhILm4Q+Kzs1nPQI/SBk4KEwbUr4pMyFxYVyWcoSCzXH0FA0eK/IA7ROItABvbYF5MMtNAItzrSHFuv+XTO3BzSDo9YXP0oE14p7p0N+K4JKSwcAq99pktLJy/bUh1KnpqbNB9ryyuXLvoYcXrz66qtWolisEZKWFpe888SFEBzr21D7TEjI4r2Fd957rzySwoQ2jnKFIsX7Tf4TX9KojDffetMKGcf9ZpSnHU2E/LST2kPtvCnBrA183n/aljAP/fyZLvVqCmr6HXxJ29Gm7FJRlzYRWaCSHaEIVsEopbWn+uWANwhlhiS0STQ/sfmoObq2ALwLiDIim5RWqEWTJ2vhdHvKNhbyCk+jmTZCOaL64M1OmpIxaimXfkI8btIqOO8BqY54Kg6Md0Hl5xrypiShbK5LecJsbe0ojH5PHvUPCWqM03EpTlZaFAbfuKacnUiUKBTsx1LyN2Tj3yRcitqeylej+H0lG7XvrBRjIbPihDI0Ity8D8M7UCh6HJ2To3AwCmVtUv0ARZpw6pJ60RJUnvGBaIkoS/0Thj8tGWA3ZH9/Ww6UQcZ2a8PwmHbwWFAWeGLm1niwuA2I7AC/yqINakj6JnT1+ftsshubHG5rGfjY3NDxiQA8skIldeDhjlsx9LMA0AfkbrZTNl4MAvqR5tUZKT5rq6vl6ZMnHjPzs7NlSe15+eJFC/Mry8u5DVQ433n3HY33d9R2E+ULX/piuXTlsstl3FMmOzZtTUjdaTN9Op6kaM9d1ROruWsaRaOY8HcW9A+H8wBMeOgJYGYE+vSDPFy17WN08runqG6UjL8pS4xZ4wp6F2zlirQUiruxzXyU0TgRsQrm4YPWCCUTSe5PB4fM/TycyKUR0Aj2Zhu/7KYsscPEblLeT0JJGvU7S1aW5PZ/P01p3GQouy38YMUfY9YP9AavbUgkknL0G+Uq0Hpe8w+CCD2DUjb84Iv7kwJc4nSBqnEqPtKkjurbCToVPg4+zwv21/7WB+EnPzJZiOP+GwWm3GPCtWrtrh+7jvsbDEwnEP88HnCfAmbXMZ6dBj8SZUkNaplsKJEZXy1PS4+zG8sO0FjU+MzcmjR/dQiOPCQ+O6700aQ/Qp8syEJehT5T7GSJSzr7HIyilJDB0F9/u2WcDycf+ek5mTcGg3FQXyX0muU+l1wNV8pQ/BB84CK/20Oflh/6HG80Pf+5On75Tbl9Nr9KhrvNs2yQkBcZCFn/C0eUpVHJidID/u7/6h+8TQY/4dJE0h2F4AiFJiqOKbQjMu3Ig+PlV5QLgHT8vtULZUMMenjjg/LB9/6ybGghnlRCDH+iqVU6C6aARdYvj0O2iOdudI7gKcIV47w872gAnXAoA/FtV6tfcDYalR2mQVrczW6ACyELPO3JgRkviEISfzsORhkW8CmHvCrDgrLoDFp2FlCkWHHFjyp4MXDb5RHGr8y9J69k46dZ+vE3YbiM2jQgcEQobHjAgZJIff3fV4I2sNmdIS30Ajm+ll0la9IyKEQoJetra96Z2lhbL3fv3itPnjyWWS5ra7ndj52AWSlApkdls9vDxRHnJVDBO5Ssl/jvpouX/f8r01Ks4AtKIu9NfXTro8If43700Uc+svd0ecXCPOCdIwloKFBcUEF7kp+r0vNEmPqojiqXOlAn6O5vc+Ioz20hvrQjXEhH5iT5YTBpzTjxxAaBXIqv2sY7AnKn9ZxVeN2SILB/G+WYdNX4CbNoUosYF33GCmqlz4Pf5Tq6ml4YZRHYwl2UoLV16oTis+mdVt4p5JgRQh6taoXQprolOXJUj1v15qTkzs5M+ahdjunRV1Qb8lKO8O7tbpVtjUde3OeIFcKzhU+N4YW5mfLaKy+Xq5cvSnieFZ4JCXbgEJnKy215HNvjHSeO6fGHt9j+D7WdTW6LKSNKg1FCX0u+pX7Ge1Lt5r1dtTdXlZ9TPacl1M6pD/COFK2Up+0c58qcY+ERTsPvfYRzHmyIFgxMUzw8ZB5jHNIO9Hf6Tp400qoAbSXLmXo2FkJU61NOgl39TlPD6W8OwV+NgQ7T7P7wvyIYt8sXbTLtGFa6b/BnRwnjIl29/nnuRFA0isScxtes2pr30JYfPCyrUozGRfvlpaVy7dJFxU2UnfV1t+uO+sja06e2+SPmBSlQc9NTZV59DMGf43rejWrtJbqjwDSjOqhoTPcAQ4REUZFh7MpYgdFgg8eaejS+FF39hHtXg7Q1j288Uh7/sbLwdeW5H7SyxR9KBLfyuUz1pdAhRQbaxNQo2FAIQKGLdHEo9HvsgMowLqO8sU7xoES4qIsNdYyiZqMQzl3wjhI7SihKkzJT4tnUGO9NcXtsjiWiKIHgSLsmSADNMZQDIxznSNykb2mDw7Z/BwNlDUvpFPoZnvLskLXydHwOp0wVfJYyh+EDXAcGkHhGN3C/qnwNhO/B0jANwvgjBGg3rbHMpcar5m9wajpsuYSLeRI7fDnZuOt57qm4Bhr9/FAh5aVNhwF1IP1wGjvZ8gXBmcg7I0BWk5Gav0dr2omfPCSWn8kOe4CBf8NIVMqkr/5BkKKdw3YCgsNQgxTZQk4F8rs9hqcEnU0vaRw9WhLf/Mz/ADIv8hsbCN0xPMUh743+J3//H72dxU0CihJxWQN2hJS28PXOlzO5tjSuvJgL+VkoFa48Bxub5eZ3vlfu3Xjf7ytNCRe3k7HYelFRoyFkYniyzcu07CpRXhbFmNxUt2Ph30KqCMamNWlSGhaFBLMnYZbbbLKYIdBG4HTjVwN0tkx3tA6qSKMPCydctB8GKR4e9BQl8MdAiydpIbOAbnEgaUxP3X2yAOwYoQYPDcSkwwd3NXk6qA8812KK4GdQEa479bKJG2EdYZ9jNNTBR9+krEI7yp13luQm3nUVPupAHWmr0Mef/yLgj/mGQ3jH/x09fvS43Llzt9yVefDgQXn88JHfc/If9S4s+CIMymaHamFh0btPU5NTVp4W5efqci6SQBmibuvKC07+2+ne/fvl/r0H5b7w3rt71ztWPMHO9fNcjy5cEp7NM9EP0dSDOrNjRV3gE3z1cTMUCddZ/VcKIfWh0xuBeVvbFESymyE6iqyStninid9pZFCSNsVDjrXhjqKUNiUZgynCdvoT9TVgGQ000K4R6NUANKltD34Zl6mP2xaCBPRh3nfzU0SFyyFTxwd+aIB+nqr6yeC+jx6i9DA+EcR4v4n/ouGK5Vm1EUIc74cw1lxj4wkOv9xve1f8k1Ki/sE8MC/l6dLFC+X61cvlpWtXpURdKlfkP78wV7alMHEtOe817aJ4SfjeXV8tu7zrhPIkRYl4WszHIhnLUpL2Fb4npRkFCrNNXvU7hM1mVLQMAq9ZVY9VimYJi9nBaDyVmzqpzrbNU3pIxg2A26a2hX66MH6zE5UQh7V0FfrdLa6FYafFaMPAcUXmeaM4EtLWBFQ4Em8Tt3nibtzCax5bzEP+ddAggFL27qbF1EkQasxvra6WjZUVtsx9MuCc+vnq48fl7ke3yp0PPyjrHI1mZ1z9BOWI/Ci5U5prUJrYVeLJnGkyIRlJKCrmA2TRV2WsrGA0lt2n+4znSdlEefiSFJr5AcArt/uA3fIovWrRlZU5lDz0IfhWWaQfRdltXsphZUr9pT0gxO0bGSsNkIWi1NnCmbFJPXiHLw8fjBNc4qffwas2CtKUeMM4RPGfku0x2RQlzbnmp9pCmEMjpFY7PwKVmbaVkdu9rcXJzXho/haMHU4Mhjb3nGbcpvrCR4DgFwLw0bgHGJXmvp4cg2EIvoyXftu5BD1/i+sZoNl/UyD8aGPddBMihym1M/7ODEhng5+1peJ0wHGDJbutpcOMfn/IQLmyqAL2CTQ1Ews5rC8f4XgBu0kn43WkizkVPC28MICmGJdN8SfQRwRyWy8idDRabJkfR3GcbPgl7/CKuPR+egaCUvFVeuTOXp9jFmtl1TTVdxoYh+arYSUTz3xsjEeqk5wdDRjFEwZe0qJDIEf0K0uk2+fSoP/jP/ttswcSmOT9ZJaMgsY4CyMYMkk4a9fBWmi0sHlowdxplGXn0XL5o3/9b8qtb323FAlB08j8EqbWnz0RIcI3NlL2RKXfyRifzHsRY5Nagw7LlhStPb+bwpJ04GN4nBc81EJG5kaLK2rqQmejlSf7xA0DtG3SskgiUMEYlAcEMPC3J5pTHBkSPqPXTxQVGdWbPyb11YiKm5pkR4UXp6uCpOQR3hDCnKRnKnm4GziMeuChU6kduOCBsuCzjxsRqXSuHwwSoDBRxvkL58v58xec7v6D+36Hhd0Zru+mA4yNq576QF/jF8fm8Leb9FCWUDYok90fjvdRB5QecJGGd50WVdYE75SpLOI4dghhCDscvaP+XCzBjtXS0pJoWbei5OOIwktVWxu2Xa9XX31Z5e75cgw66nkpXUDKXPBxPHbQUB480amdaKMclVSd9KEPTvGujOwt1c1PnuEVBWID9ieMPBw/w066hLe0LQwFiWu8EZQIY5zQJ7KTUd3KiO2HCGonvzgv+izY6AtG4k23bMmCbkPamXi3M8pY7TukpWy3l/AY3AEA+r4+NQ3rVxv1ntw9KSmwmqge2SFbW88Vyhxxo7+iAPrPjrd4t23Lu41+10k5oJM/L2WccE35uHjL5ExfRXiEd08lSHPdOfl99G9Tio/8vsBDZPEO1sG58XKocX44xk2TuThkTP2J95tGFX5OQrciNMY5tscxPinviuvek1I+jvR5TKge8I7r1/uWd6r+HNDH6ftOVBPAMz7mW4IEzClMUgpRHtNdeW27hgG0E+C8FUfSMy8oneLxu5wWeRKkKONzO1YIfXZ04ajW5+r7MacjdKkeS0Z+CqBEjIvWeQno85obmK+XpRjdvHFDU/VGubC46EtFUJR3an+YndWY1jhll5N35MYnpRwp78VLF8vVa9fKrPLQfjvqu4xR6sT4bmsCfsYtfbnVKWxlThPP+gx9k3fgtg9RRdQmSm7FSPXLhQnCja28NvJ712aMh32sX7SmFELl82kI9V8UaA0oSnXB4MLHGMsuFA+SyJV3/zKlM16EXQZ6UrJHs+jhoQKKPack5Beetm6AL/OBypeNQsnu0jlVDJuDxhjfhlfTH6oRNGI0TlSqSc2cAo2U6I/oVucy3lBBufyKMtlO22x9LJjYdxoIhzL4gdygZALKM3fMu08OUE/b2/EC4GPhcwVaLchwkls2k1xzfwJoWPvH+CcHxknmA2OtfcV2HJ3dYFA6xlcetoFvEBNbvuFAd03tf7jAHDy83IzXHomML/8e8QOkOwv4IUrNMxjOkuiM9Ik0Hx8jxOHYxFVPy0cVwKfGA8fJNUqcb4PUBziCCzx85KcXtYeRg6BR4fTuc5iEma6Knw8wCB8pyO+H0fo0WoyIeJykkoN4y09Egb+m8YwIDs27mV+Fh/VXcaxVpEUP4GH7F3/8x3066r3339fSNmo9ZPR/9uu/8bYTM3mzECoTCkSb8Hn61nadEp4GYhFionde2aRDedjVArsmwfgv//Qb/lPaCSWY1Mq1v7PtW7c4LuSX0iGWRUqLCbsTUxKaWCm5NnxbOJj8LIyy6ulLE2a3iN2Uumsjoc67SWrgKBPmmBmQtI1RYVYDNxp1YvdG9QB8pIpVElAe49MHRcIdVzhJ05QoF1XLwmZHJ1kpi84O96hS6Ghhjc7Qmo7bzcvyQRsB7T0ckhHddTT9gC11DJ00NApLU1qWl5fL5saG62jlUaHko31oMS+QQgL/2GGCdmjrdSTaeqw78kad6UTsOPHnt/x/z+07d8vjJ09cDn+Ky382ccse+S2ESwBHAEXxCX6OaUbZOr903lfFs4sEDaSlHu+rY968ebM8ePDQRwHv3L3rP90NHw7LpvpGE8Sgjd0tcIDb9FNT+KPyvbPkFkyYjd04m5+g9AUbBAy7icdf2wObvi+TXIQRrB/xEZp83LLucFmRVpgjaSyl83hivIBbZRyCi74nN7hIDQ+clnGo+nEbHnXzkVel6wlQ1YBKto2UJXaJePrv/4oRDxCE201zjF/+1yV/5Dld5nm3jIs+5mbLHMcnpYz6KThGfKXssfGU2Y7w+ZiUTNvNwr80P1cWZdhlOr+otpV7YWbaR+v8xhzv92ns00983Xg9gsd8oMHbR7PGs/jHkUDmEHYy9nYw274Sndv5uAEvizoPbDR31DnIQqd4Zv5W3tDy/NJGhCM8RiimHUlbDe1KG5C8gyOeCgljPALwnpLcBypk7AeME0qIf84kDc6WBzcRSRK8MYkDnd1Oy29oIb/7nNobP+X209QPlEQM7TKnduYo3mUesmhM0i6ba6veMeLmw2m1/2svv1Q+88ar5frVK5os9suG4mkrdkU219bkX5P/0JewTGoOhw7GMvMMxEToV1+Xmx0b5uxOKe0gdMfEzfJltcD5aTv1Y/14J8h21iUMcRhX2Zkzb+KGD35gpQTsIPMgIke7q82cX9NjeLePBwd+OAUK0YHxXOC+krXRF0occPtfjozmT3Kza8RC610jzUsoSguzsz6azrhiF8lH3emL1EEkezaXW9SVA8YZxTkcUJx/4Uvq5Ho5NOB6G5K25RyuLClOX/eXgZ9gbJia/UnB9dTPMHMWcKqPhQ935VEdL3yCSNBY2QV8MjB2+gxFvABjslo/ICw/tlOXXjjufn+zw4/E4WaceTzRzweY5BtswMpYDsTfM3/dcDJNR4zawm1vchLWIGns6nMPh1S36zifENIOoet0+iwPqB6BzJ2NBuaMfO2qk6S/pwPpW78KGru7PAqLu/KmF3MidHlNZ38emb6sXbohQH7z5Ujq53MTn/mvD6iPAoyj4ZE/JwVgjzxyIzciw17h6vDt7fJEsjRLEbLZ6N/7B7/5tvkoyQqBgz/rswCiMCZ0XxMsv692lc3kzu09vJSqIMUzyFg0FCchZkcL6KNbH5Z3v/nNcrC+poUCAYVFdFMLlrQzCVEInipQi48EsrEJCWozwjfu95UQqvgjWpZMhDV2RPgfFCoPPaa1Nii04KeieUrHwoxgLaNF3L1HBosLGOAHPzCMRRQlA6UAPwuoF/naIyR+2M07NPhZ6H1kS6HQDgW5IYn1GZ6Muxx+aAhrwOCtC7HLFbFemJ0ORM2CsFjkocO2F6fp6goSThq4pQwCwhGqrXCwwyL+cZsHCid1Y1cGelBy9hXHuy/walKLdxTfc96J8TE8KUi0bghKZ7Jg6U5X+WVhYcyCBBc9uLxNdajHT8qdj26XlSdPFSaFeRsBWbxUOv5sdG11rWyyo7Ev5XNiqiwtLJULSxdsL0hpunDhYvnMZz9jBZEdCvCura2X27fvlIdSzB4L/4cffFjee++GFWsLXkrrPiF6AHhPm/CJQks14HkmnWY7rM+2EOQ42dSVuIrHH/kJ59IP+hhupqdwJQWjHDWjoZD2NkHpp87TyidLLVc/FYeM89S+rDrRJtjeHXPNarqKE1TkJr39iguttBPHoshf2xVS6EvwTKldb+fhiTHj+5yP6vGu05IU7gtcez87o7aRQiVhD+WK95YY93R4FBn+a2lT43tt9ZmVGnDMzahtUZiW5svC/IyvnOa/nqYnOaolgVF9clRtc6C+va/+s+ejeOpHcu/wRF9tz1ElXoYfod5q5wP1hQNNWrznxDs0m6urvq58QnODRGDRr8mNuYL5SxVFsfMegOYAi9weNzJVQTLPqT/tQf9GeIeZtFcYLCdG7VH9MMt5SCc/VhRr/AKH19TG4yz15xRwHKO7liO6gxeTMonFhn6HOxPzQzPp53GDT3O2+kwW0KSll9i43vRd3p8ZLUtq6zkpyFwlz67t+uqKzDPxb99t/dor18rPfvXL5ed/9id89BJF6tHD++br1UuXxeuRsqFxvbG67j43J4UL5YPdauZwxiDzD8ooc6AfaolG/MrgB0T05NQeu49eKkud5XR7yqZtWW+aH9aTjEnGtsJZ0LgExW2gQF9c5PJyyyZzRmjJ/BEFClvhzVY8dEIThja2ks365zlQcwF97XBPfMy6iBLEMTsrS4xd/DLcDDs7NaU0UpJET6fcuaY0GC0curl8x9Xo4mMAxmlsW4YWZzQG+oBCq9+Lf00Uq8shcM9SCPTQLxIaOOIRdL2u8nmIOQMk2fGMp5lUqK/qxyA1wQz79PDJp8rEyEew4/rhuP+vDmA6sYgTIHQOBvcd9Zn0UPn1060D+sHu/NU0f7P5cZz9jKnMkz2+nGzSDs55qnG6NiEJeq6k8K/S2NSQFwUN7UBTaUyGWCYJy37im/tskOoawyc0AG3BLGBnZzuF/aGvReJO+X2c7mc6QFLCBhlAdrAKcDd/a89qmX9dwtPBSZS29Z+z5jsJlDv5BZ7B/K0EVT9AOubarhiFZ6ww3xlLbCVALgLwk45Xf5B1e8oS7ywh62u8/Vf//Z8dcpPWxu6GK8GCwNMv/9mfl9Ze3dDC9niyyDENuRkQPIXmnZhpCd28s/LBO++W3/qn/1X54M/+vFxQHAvy9tZ6efb0qTAcZpeBBd1CypgI2i1LSxfdObhsYEdKlVQMLW5bSrPPRVqSI/eVNVT0saZCj0JvM4omcMNU2tdPXPXxLpbqhqF8jhSx68JxErBtbK6XVQkM9A6OnME7GMcRMBbP9bUNH/eamp4VjyZMN08iozBs+gX1NBCUKbO+0MLiGwpCs+mS7XjbScsPzgC8JR8NmYTmtz/VHWQRPsgr/tmtsNQZqIUIF4qki9JPM0RbsJJtUFgEyprNhVR3xUgk5fv4moLogtl1q52OCZcwRXJc8/KlS96dm5XgzUUR8J+je+3Pb1G6OJZ5+aUr5e6De2Xl2YoVUy584BggV5KjyH5065aUp9vl5VdesfIH/S+99FJ54403/GQbQ1kcR4Swra0N1RklD+ExdYEv7Wky9YBWwl0z4qml0niHx3UzSwz0BdJ7V05AnwweCXKMF9WVeAYYymt7Egw/23EkoO0IcluckctQhH/91Ycwh/fRCH3KG0UQ4mRqGvwcf/J0UHEGghmgTNzsxqWNk9f28Txyk5za0a7wjFsDe4KmhEzKFE948sJV4wiphFGKZh63vY/b8RChjJVnz9iZ3CmrUoKfrjxTO6+WNbXjpsYRN5/ta3yPSLk7f/FyGZdCPK4+Mz0zV6Y4Aio/4xeBdltC78bedlnbVx+YGisz7IxpjM7MzpdJ3slyeT4gJXqLaJMypTlnZGxCfm6G1LhVPegXPKyhurRJ+58hHphQv/CL/oyQrLoIL2MlfIZF4R9umpq2gU8+Rik3MWJDB06vAPOaXDWu5QEQyOEb/S/v4R1Y6Z3gCOO+WlfZTBZ8tht+444BJe1ryuRpDwKaQIwfpXZSLTstYf/CjObAkYOy9uxpefLoQVldeVIe3rtT9jUHs6v0Sz//c+UrP/llP/z44z/6Y5k/UTnnyn/yH/+PNc4ulj//5rfKH/zhH5UNjdPPfPELZWJuptx7+EDtu1KuXL1avvATX/JxyzUUY/GE9xq5Qp52hN7shlEh6sRPpZuKiC5GZPp8DMEsasyzns+Ul51IIclYVz27CyaY66m7DQ//lFv89K5vbSOANM3AJ/p4+Be/dx6lDKJUcyKC8tVCZVL0oaR719U0k8s1UFjqwIg37upmNaVfWPmpxnUTjvwxMhRVflRwUAW3tXiGqz+8BwlvfQ+a4Iv7Qe0DKRa+1/qrv5nymt5uoPMDoTm9fTBk3queU8A1qOUPhYorefwbv6yeX/VUO1XKTwWnbvSdlpg4wzBsfw1Ae6mPDSrbMe7H9dicAjKnEIcn/n53P3TtCzSn2/Zs0NbG4UAfAzV2MpgumZwCQFbJQ2gn/CGD5/eBxf710NTJWxTveqcck9Pn7zXOSdDSACel64+Pr61nw6C1VWs3PnybrFNDPKc4pYo/3qee91fHiRB8w4DcpPN8aX9F3DLbmzJ8ogZfq4P8xDAU0gfpf9ia0TyfSu/RPEhCZE7k/3YMj9vweFDOsdfRX/vH/+XbXpQ0+Y+MZYeIXSOUpXEh727cUjjjmGNxXOaQRYI/nVTBKmRWShFP2h5KoP3O179eNh8/KnOTPCEf0cK/nd0ixfvdAy0+7MrwJExYvbNEW5AGIZT+xPWsLJgjMkwOVDwLTiZtTylUHltxseEdCwV4FYJfcY0hTfCJQEIIdWIR4d0QKT3QqGzj3CBGHVU3npiOSaHyf89IQRiR9obwpUjhE4Opi5CZHsrqDHVQGLTAIyZzlUVTp2iIh2rRGEvh1Cwf5XYIdQcffib6uGP4tUaMIaniOkWp0kAY6KHNBBEPszt3/OTrz4MdRKK/dqy26GJ8ZNHtpzbVh6NeuTQAIYbyFCMkW/yXDztLa5sSytbK8uMnvigChWIHQZndLvFnYWnRlygwF6OMcwX51avXymc/+7ny6iuvSbla8sUSr7z8qtthVbg4Bnjrw4/KD77/Trl166Py4P5DX0px+85tCUQ5qgnNKGsIah4QohBhDQWfd3SYtH31uXfe6p8Hi3Zocl9RfgxPh+nn3NjIUTBqytEbH081X8ILFKc2CDth0PyMCZv1Y77LwEe7+9pEYYyD2GpzwvVVM4T/Ks/tQfMoQlEy9AP1Qsp2h0qsgSjSy2aSgB4zmpz0KZVlv2mQm/6AsI4Qr7SefJQ5N9RxnftE4aa9qcncWDjJOyzj9G+yapzs7YifW1JY16UgrZWdze2yIGVmbnJa8wRHALNrtTg7550r/HNqn2kpV7xrxs157CBtrD4rm1Kq2FHa52iu2ocjYmMj+2V6WkK/5qtzB+w8bfpiCW7lY9eJI2XsWnF0j7Zh95SHOTyo6fVTKf20O+9qbaz7gold5h/xAV5Z2Gbcwk99rCTykmflMWA2hot+UEO4hXPldXsqgVMmyrbdNYycQZW2IC9lEmahTjZ++ln+JCN0k8DZKqQvpE8kc8IztmWggzTUG6LFQ24i5E+HN2SePHlU7t29XRYWZspL1y774dbdOx9KSdpUG4+Xp8uPy3e//a3y/e//pXF//sc+Xz791mt+r/DwcMzvJzJ218VH/mKAcbR0fqlcuHjR9PBuI+RjUFhRDenS1BrVBC41/unH/Wh8FAWoKiQ2TqX2iI2BGMaH2Fb5nrHhuRYkch/WuSvHrSlHFjldHjyTMQKEN9kChykem/ZnzGTs0QKiS2ZSSSdkoggJv2xKwIAlRmkpxv1ABrfxh3Z/HEA6yqvryKmGj2ynPckod3UD4Dsa7+A+SH9VDE7bLa/95LGTcNGcZCcbfgzU7azwHJYTTIOGV2F2Hi3HdPcnHwCDKDwjio8NZ+EKVch6XgNOhNr3NaYyFpLc64+zxgYcp5/aws8ZoOceTqFT9H4GQuZG0snUQqDC/c3ji1R5Yv+jAOg7Sz1eLGQucWuE6YLO8dcGrQTsgaY2F8zBb6D5zCxR3djlxPrpEvWgzRnJ4RD/vihIn3oe2rzFr/uZ6Y5p1LQ426azRxv9kjqxzrP28/oI714vr6xY/mOeHv37//A337aAoPWYp1sszu1MNYoTgoUFRoXz9IZjX+aTfvzUSgVxxABhhx2Wm+++W37w7W8XSSBlWoIVCwxPYzkGgaAHDoQ5y2eyp6QoTXI5goj0U3kt5EzMhxKIzlFjKsrEQNXqStfPmPzGhZ1BoLRKw6cntMIQbkubVB0mvDNiJcerGU84+NPTba+XvK/hdza0wPIfQShX7Qpw8nIUDHzsLKGxw4cs5mlMC8aQAUAHE4QnCegjLmUCtUq99AZwIGxJkMVHYbaTLnZwZIcOJF6Oe+mc0F7b1sirIRL80B4jt/mEHWPFrGUWXvNTdbAwUgc8QolfopaNoNKOq8SWUVrwcLySI5goKKvS1td432FjoywvP/FNe8tPl31e//7DB9LmV90XaCtu2eN/n65du14uXLjgyyLgvQj2fzYtzC+4HOrPxRI8FeD2vg8+uFkeP3rk3SiuQ0epWl7On+ryh7u0K7ug3vVQ9eAaNOO3QC3beBXnHTMZrkY23+QmrRUwGRSwXn9k/CAuwe/wE9s3aUkwRxHb01iwQkYet0NwYsJ7dqxklIZ07HQQDjFug9oO+J2XdqIOKrcdC3O7eabAVjthGNstn4TP9K+0va/k9oUUtXyV25TnIEdIpWz4RPtSTwzXlY+LD5NScCd87ThKE/2DMqDd157Lnhid0AQWWrjOnONJc/Nz3bG/S2rfixfOqx2lKE9PCQ8KAjikxKrfcPSPdxm57hxh/mBvq+xLIVMBVqDOib+8RD8i2jXZ+Pgex/q21qSYa9I72JGCgALIAw+lHRMtvGTP3DUuetmRaA9IrFCaleakeQjfM6HS/dSm9GsZ71TK75TK550I2bSdA2Ea5hhkEhc/mXAEpPD8yNihLIXAKyt3MmJnUDk86ZOHEBdtGuE85YMroPlJdeKiGtrH6cQvbsMbkVLLO2GrGn+rz56Wz3/u0+WnvvwlXw3/zve/Vx4+uO932ti15Z3Ee/fu+2jdm299uly+fMU7f+wKPnz0uDxVfv7PDWCsvvb6a2WOXWHxhzmOPsuuUjffVZ6lD3ecdh1RjibH8pDOD+/MF/U3RYY3AtpaGVGG2zt59M3wq6XvKTt5wOciAiqQstp46sZWjXa+Gp+2kFvh5q9MFKXQQFxrBxunzWzc4bCddI7oAEJaunhPBadjLam0nmhUZ5KS1nbCXSY2UC3jo+44/K1pa5zz2pkGqjEDYBDxPTDOStcgo5+aQX7b9nXhsfipEZA5xLTUp5m/LjiprH4DdPURoRkXz5uwOJVJXniVfNjNj83X/e0UOD3mJDBGij0TmFYTS99Pn03f75Xa1elHAD+aYmkb6i/Tlf/DIeT42HreaLaArI4xsdNaxFdftSOD9OePSWzMkSom6hPD8fKaaZCymbN7RVoUqmmwPVcfy+e1XcC6jTx72crStk9JEIeMNPqf/cPfeFsiUhnp3g1KQV6YKFSd3IJvNRxbQ9ACAcIFiwVPbrlB6enjJ+V73/p2ef/73y9TWhX5TwlJXlY0/D6QCRR2xfGfFUznHHNDOCUN79tYWZKSlKdipNGAktDEEgATvAS4kv0GiBvBxT4GqAze9m/wKD28iMyCzx9vIihGOEIo3vN7QqDulKVR/rdmxgIzuyHsPrBFN6Uw3pvhQoM95WHBzpPB8K+jyU4tNdWrmqQDkaYZJcq0V6GlRYgV8U4vBKSxqW4n9CSEsiDxwuGWqWz3jNLBBNXBdsXZJiobhHmVh1BOZ7Fb4RYCZXpAufglwIiXfvo+FuGSZnV0X8n4EapRlMCDIL65tVk2EHgR0lZXpCg9kaC1Up6tr5e79+5ZmWLHCd5yqQSCInShCPHEmnef0PjZaWLniWvKr165Wt566y0f7WsXUayvr0mIe1gePXwk+5GUprvl5s0P/P4TgwB862vrEWqpz7iEfilQ/i8qlUm1fUTKR+pyK6KVGrnT96Mk+aphhXGsi37l/kfVxRDGC7gQVltfbIY4FhC3hgL8qXxPObhjQOjBbT6byQ5zG5FWvkaP8XUGOpgINIZFhwd97SHQ3NK2vubdLMqT20K70jM2XDbjkdRtTFa6+CNhDMoNR3JRnDC8p2Rbis/M5LQVJbJCfuYUKSqMx5qHdHOzs+XSpYsSts+XpYV5zQ1cPz8j3vO+FMor7bFdj/U+9k4S148XKUIjml9QlHjPycoSx+02t8v6ivqT+swu/UljeFd9AyWK67G5ksX/ewPtvJPFjjJ92vWmzsx/cqvtsBt/G9999NA2YbRD70M8vOeHT7PbRwGe0azUiC/ezaQcjD5qrcy//iiHygg6+oLRmZfN7jf8GauVgzpV8keyszPTntOsDGuenRC9/Pfd9ga8XC6Tmv9/6ss/UT7/2c+ovMNyX+Plwf177tNvfOpTGufj5dmzNfFpprzx5qfLufGp8vDxcvng1oflttIyd+6pDabUjq++8kr5zGc+6wdTjHcWVvrnjub48NA9yH0OdwORatCUUaZEf5TYPIzxez+1T3JwLLypf2OhcE44+PIE4jHiY1M6wcdpCeNXmTa1ZEKZutq6Rxp4CJ29OT3xuPU1f/y/Y31pAX5xxk7afrulJT4/gtquwZ+gIDhmANmtHw42NRvp7cbXB31MNz7iazryG/CDKz73vyMZT4MzJDFuEXaU5pNNTQ4x1e75m4VxszpkCDQ8f8Ogn6ZB9WDEkDbtmrrjOmJTR9ezhb8ICCJ3g4FQxzcP2wSeP2nr1m8dX8e+15AfDQyvx18H0B5uoHh/aEC5Z5s3/JC0QqhMHB65em61J53Q+bqPo9z+HdDO1TkIyDccVIbpbOW1Ty8/MgbuOqsZKN90V7vfNKCfAk1Zys5ST1li3Rz9+//oP3+bp/rnuKWOyiuDC/PiDT9YdNLhfTRJCzEILexIwGSS52gNi9OtDz4of/GNPyt3JZQuTU/7qS1KEIJphNJGdAwC5uLCkgcOipKP4UkgonpCpyQZUAw8lqYedTLG0y1vsUWzhVXSGgHLWp7y0glQyriwgWNevkBBaVMv5ZNww+4XZftdJhkEWv4niF0BbmKDedCBwuT3J0QzAjxPMXtCVkzrTCZL5VgI1seNQjz0Q7ptHLjTsEATgh2o+EyRMuR3nopH5eZdLeqesuxueW30qzjI6cBRmdgAbFiXJ+US0oWsU5pEC24LhvBSdYcE6tPiUq6opCCoVbzTKA4+YdO/6HQoxCjaGPiMILWyulpW19YUx81Ze94J4j+ZHj54VG5/dKd8+OGH5d7de1akOPbDewS8z4ECyw4Uwtk1KU9zs3Pegbp48ULh/5qmERLHJ7yjdPfe3XL/3n0JgfetOL3z7rtuRxSzrU0pYeqn9FUULvcPK/T0U9Hqft+rP0oS71vRL+ALN/3Rt8hLLurEuyYIjJMTUcJ4n4T6pm/RR9SbZDzu1JZNQHffqOEOU9rEwc/w2f2p8h4AZ8ZW4jEA+VBY3S9lp43SNoFem9nUeB9VczjBiVOpwa1yaU/vRrl88qgczSEI6j3lh+N28zb8j1pToCaVhjGDas/OEe8pbkmB3t3Z8q4SR7/4U10ui7h4QW0pw0UE/N8Tl0ZMSbDf39koRXn5z6ZtKb0bUrjXn66ULY7tSSHao100XqWpW4FiVwk/4Xu8QyP7QIoW+dld2ePPbpnXRBYCuG8FlO2dH9WZq7R54APd4Z9s80wgv+cpeML4EZ7Ew0Pi/SOfcMnmk6xOYbdTaNzC8qTATZwM8x/4FAmqZsjY74dU+tWEj0VKpTDpB1E26L+ijUscni0/LtsrT8uo/CuPH5Vncl/WeHnj9VetVE2hwMpw5T87v4wrlH7eNeN9z9c/9UZZXV8vf/bnf16+rvmevwS4xJE70YOSffXaVSlUb4qmkfKMsaq+x/+jcckDXan1z2YaUCU4xI4NFwPlAoUc/czFCe3Ya5QiHxUnTHZ2uKutinvNEkYrQTLwh/4GLyHCM6qcbhF4Z76rbMaJAqxodTbtiN3oUx9RWblQxIidF2dn3DZHyyeNuz1pYwlaG9LiFXqRR0HhjZaBxkmpY/LEiqPf7qVXmL/x1wQdLgPj3Hx7AWDctM7gjxOqHjULmap9zO9f+lINPwHAQtWO1Ol/YOA6VJf7IhVSiK1qd+1JSKwXBEHWN1xPgZYujWF66pjC7eyKQ75wEhP5Qgk9Ewyvx18HhAc//PpqDurWrdOMfgSsEfSvBi1ev05jAy7j02xIvOOSpgHtH59jh36Sd5ABkGWY/zDxHyk3ncvrZmaXHrT6dXWopoHlcgHy3YnKkua/0b//j//ztw95L4ibrgAqSSeWycIgpHR2RqfcHDMBoZ+k+x2Ac2VawuDW+mb5wXe/V779Z98sKw8flUsSYHnS66uAETwlYLU2YOFl12ZcwuScBCkEXv5/h6NwCBu8pxTaI5CRL0sfleszrmwzZNBgFKNSDMwgD1ohwiWCBE+Qp2wcpk8EUuVVhfckDIEKQRdBHiGZ3Qq25GAe79H4OJ4MiypPxrE7nlEqPDJOdurYPRANNqGH/63BzWzncPjrfG5m2wRoKqESckMb4UmP37bzCp/KIJ/lKiWnnlEYCQsypbSQ1yasDl9120968lsAxxVBBjft7Zf6JXT6aJXqjwLUdmjgG/8rBBMog6t04R0d21SpCBSYa9eulfMSfHMhA+8Q8e4aNRV9UjZGJVBzJJO+sbW57Xed2NFbfrLs95EePXrsm/ceP162Ao3ghkID7tdefV2C3pwVGniysDDncs4rjvbjz3LZOeJ69aWl875kAoXnxns3yg1fWf6BFLJb3t1C+OOCifbfMBHyRKfKpG/w/hOKEcoPvGt8gi/px1HOrfASR98XtDZkMHoXF4EL475GW6Z/NN5ZSaOPye0+o2/ooI2E2y0m7gkvt0wCFtq7cGWp7Z4+SZubZLpR7Q89f9z0BE0ajEWUDI3HKESY4GSotXz0B5TfwwOOC1Jv3Ix10qY/IODOTs9I2Znzu0pWeqzEZrdoT/1oa5Nb1KT0rK/a5rpwhNGpyTEpXVNlXunnZS/OTZfz87PlivrR5fNLZUHtwP/scOX1gfqirx1nF0nKFzfsqVEczm6Tj+spHba0WitK+9tcVb4hof6ZlYNdKdV+N4q5gIcC6veqkLq2FAHVBWXQyofaBNsXCijczQPvld79RH25X7BlDDa3UsrkF26L+qQlhIEcVgsfbvoWfVph59Synmia0RdDu9Y2IZxxxRThcUs7isf7B7t+p+jJk8dl+f69siYlaUNK0sqTJ6J5r1xcWhT6w7Kqvs9ccfnyRY+XP5dCxKUcjx498V8G8DBj6cLF8mxtrfzgnXfLhx995B3AL3/pSybpmZRW6nFJ+QGO3DK/8oCJccSDBSUz7diQDJDHfFIAVeXqedo1ChEKkxRA1gx4LmaMn0s7wDXv7GNGNG7ECCtKwkW7eP2CRzBV9aPUyjq6ccqU324ZduSMDzyyaZeGC9pMn9zseqE0kcfGbj5H3R53uJ0/oeAwOJ3owem4Cp3jGCgcXgbLaR9wBS+eoGq/CXBZdmL7N+HVXxPXuArmnYM/ORzHPRAolwy17JavZW70Ol0v+CQg6dnL/ZsHXZVl6EOpT0Ja3QLxv1gIwtoNBkIfFXXNiQHIzvzoNUpfz11djh8enKUeLx4aH37Y9e3x/3RIfJNVjkOTI+hYTf7ETbaGu/8XcLviHWIq2obuFJPyeRjXldfZ/o1b7coMGdOD/jz9psGZlKX/zf9WypJTK2O+PuLQFpq2YAizIxHo6GgIcCgLXsAU//DuvfKtb36zvPu975f9za1yUUrQHu8MSGjhBj0z2qODvDzp5L9c8v4PgimEWbjUoobgzftKcUtQgbwsOXINMkrjiskJ01BYZPB6N0Q0T0gon5QQwE7avspB+HRW0kCn8rOLQD6UEQS8r371q+U/+tX/qHzxi18Unj2f30cg5En5jIQ1eIHSAC4viPBMYRaGEX6bACx+gd8LMJOEeV4bzbaIMC2VIAV4cYSWavudCBm7W7jw1Sq7bQLBi3Enw+7CEt+VI4iA3W8H8rQcgR+BqypMCD0WfBCOq4GXtB/p5SaMnbpnqysOv3b9Wvns5z7rIz2XL18qFy9dKosLC74lb2Z2rkxISeKoj//8VH0DHrEzg8KDGwWEstfW18vqyqqvKPZ/Md25U54+XfGOE0rOQylVCL38YSbHj+hfKLkco2PHcGF+sVxS2RcvqHwpwihaKFm0DzS3cjjKx/89vf/+zXLjxg0fG1xbW1X4ptJx7I6LDSb9rhQ00wYoTGl7xD12+lCgON7J7smu+AHfIgnTx7zjoz4SYbf2mWq7v2As+PbGX11muuZze5JHJnHEpvWchazgd3aFO4+tnlvx7orYMvQV4t1nWl5mIdXHypr7RN+7VJSqsPwRL20ft34sgDMNtTnFfzkg42NT7ESpfpNSiNhRmpuNAsW14IpWfpXBezW7+Y+2/d0tBe0I516ZmRwvc9OTZUnj8xKK08UL/s+gpfl57z55V0godlB6pdjzv05cWe5ry+Xfk4J0wDtP6qMa1FYquOb+YFvxKLwyvOuEktX+UDQCsgz1EU8syMvk2FfCMPAMhd9jVw3A+PO8wAde2lZYXJlDmRsk7DN5MVdZYTJEGadQLuFpxyBthKsijBGgkDS/FWr4T79SX8K9v6/6qq6j6o9ry8veVWMnj3Z7cO9OuX37lsbQfSuszM/0QfosF9y4jws1Nxk+4n/VxKOlCxd8c9Av/+2fLTNTM+Xxw8dWmHinkAciPEBw/xMNuOkTje5Ksuz+flbMyyn6hzwobtDQvYtEmOhw36RzCx18PBpe/eZ//PRPElNmL77aKsu4ZVDGfAS1P1429LV2hD7+YiPnFkKzjd3UhrqkPtCmrPbHbmloQyB2wnDYezIoLn0KJPE/b4I7STIb+Ic4W/VDOtLwQ6S/Ca8JkyY+9Y+M8+HQy3MqGHd1D4XQ1EeWM8fmJ7jcrXCcYlo9++v0NxL6aD7ZpP9iuo+j9BMEdne8kP/FQPDA57MAc0WjgQ/ZnFUIwOE5TeC54YXReHY4az1eLNR2+aHX92xlMltwKgLWJLV++9qwa0+M5kx7ncaJawP3wHlo35ZnkNGHufLEuD7T5nR/atHH25I45I1GFkCeZvebBpaxBKcpS6wfo7/2G78hZUmlOXMWDD8xrXbedVBFaqXJ2LlFDouLJI1y4wfvlm9xBO/Dj7TQjZU5CZLcTMWTdiX3+wCNmyx+HBvyy/RKy3/qIIxmckcoZ2EmbYTvTAxmpfMHcB81oQ+hNwMSIRL8irAAR/38Ej9HoiQgIFjsSfiiVBZMwLQpDYuzsvmJ5he+8IXy1Z/7ufLya6+VNQnkH37wgQSr3Qh4EuYRdDiOB33eBSBjhcYz8Fowlt9GYSRz2hpGNRLvjKq30sBv8nY4JFTZH0M8Gb2Uqc42QZS8nrQsazkVCeBsAD7Fz28L76ehl1ZgT1JSrNM4EGWKI2rZhWEnkSOV2MRxBOjq1SvltVdf8S1Z8IhjWuzysOtz8dLlsrWD8gX/USIiaPrK8dlZ1xM6Xf86CdPGKNnPpDixA0WnvnvnXvnoo4/Kg4cP1B47DuPJNkfwUFYQQml/FCgUHRRn3knDz04RF0bw4vr16y/ZRpnyDpL6Kkf1VqUssct1794DHxFcXl7xS+veDYAZYgX/G+adSeWxctxopi1UD48n1R/+hZPwj/xY6Qf9hjBAKBLG2DMu4oM3C47wVYHQRuOnZcdkcTrB9KWxUSi4OfqU8V/LyvBwGd7ZQlFiAnFfpK9WI7cvhlE+C5vV5s9L2UXyTpUEdpQtnvajPPFO0vzctJTn+bK0MFfm5OZPUYk759swpQCwY7Wvscp45ciclCfCKWtCcwu3881K2ZqXkM5OB+88YaamxqXQchSS+ogO0bC7vVE21p6VzfVnZYvb+rakAKsdufyBd5nGVLcx+ht11NzGzXH8FxSGiyS4ZU+dG81E9dL8BB/EG2Y474bQf1ubwxPVVGSKv7STPuZz+MVuCH2RY5zwEgWH//uhdWhfJ5Z1cM6PjupH45KGIk7uZmcjinav+ShFfY0+P86cp/mWsmZlpkQQ7y7RJrQZO4ncXPhEStDdu/y/2QPvrPIwiEVjf+9Aeac8Ntll4gHAa6+/Xn7+536m/MxXv1g+99Z18XmuPHzwuNy7f89j/sIlbsMTGYD6IwtR6lMDq0XXgjfuR3LTpvyROUqJ4/wRMFfVfuf+jJGfOFCmDwZXW1TTJ8nMOqL5RT8+rmfDXJ/dqhiF1f5qIz4eUZo6E8XZyhLlCbttu/Wx7Vm4jg3iSN/S0LoNko74oaAkzIuDoGFJGSknc0wFyoeWECVvzYGXT6Ojpqs+8znQT/txSP4uzyBo5J1iaFrA+Iyw2SaNiJ4th43TDDHk+RsIVFfkyWTOOJH2zqSvY2P44WMO1HC7HfaiILhauwwG+lfGH9nc/zx2Zeys40Y/1ONHAWerx4uGtE/j5Q8XqPAgo18xxes6beOQ2p+abaP5B5t5qKsGs01wHAf6QZNBezieN1kjT47rN21eb/R15dZqEI7qYFyOCJCn2f2mQZtXT1OWQD7667/5G28bK5O6Ar2A9BkWj34hHzfHPLxoaVHnj/f2t3bK97/9nfLdP/9WWXn8pCzNzpVRMZ5/fOc6Xr/L4IshsuOAsOw/3RQecPIOCk8dPYFrUePpp3eWtCiyMJrZENmE0rBEBuhzM9FoMeeoB8K066NyiM3xDzFbi+PE1IRfRN7iyuGqpLUn+NCEcAwfeMoLDQiOoxMTZVPCxf1bH5U7t2/DrjIrRQmhn0WVtAg7dCIEnrYD0wRYyEaopRGpZ6pBYCwTaW/izGt4b6WIeiFk466mus0XQSYhyMiEBBJPvC5TXtHhl3Qd3zNJL4MwC50qy8b5ZUwrYX347HapFU+EZ9q27TrtScjEz4vz0L/o4295P4376+mU8O7CxQtlXkrJrdt3y/r6JoSD2Oks5EnAMx36TE1GcUG5QdFBEXb7Kp6doBV17GYQ9u4/uO8LHZaXl6VUccwql0aw2+OjchZKswswPTNbzp+/4P+H4fY93tPAvPTyy/4/p9x+N112le/Bw+w48R7Vw4ePXR67W7xnRb04sqgBZfqjlLFbRn+fqApULr0grZ/+u5/J6FO/NoDj9THv1eZRJqN0pa1oCwm7KCEaO11O96E4G0YrOtXY3+JIa7dADqH02O9fkO2m7WWrWE9aTemLYe5A0Gx20iJY6iu9BoVHNFaFCSGdcYcCk92k0cIf43JED8UH97SvKI+ZlrIzqXkkf5qtmqI4gc87XChfHN+NYj4zPSmFadbKF/aCDAoUO1fsoqCA8SfZXBe+LcWJm/a43pyLH6QFSCHSHCXDUbxDKd37UqbYodrd5M+d8we5u34nineedjS57Hm+4x0b/vCV+YJaM2+ZX/I103gZt+oiPrM7Sf+CnyhK3X85mceah1Rn/9mq6kd/fU5RkmlXYTMenKcvzOMXWpj7NI/x33fz4u8FKaa0Aw81Ll48X1595WXPf+yyEcbtg9DinS6V1W4CZUeJ/vfmG2+WL3z+x8rF87NWbKbH58qDB4/Kh7c+JLmP3dJnmHuhh/rRz1ufaxb9zTyphj4DL33A2OnSdz3HMGZkPHbAW3G0OYL07qcYwmTon57jZfsInxxe59RX2NlEYfK87z4fWppi1NwJr0blqSvWNoRGSqZlUl7cxAUXeZrb4TIBeEGcQuIcDMbjUmoAkIwVk10uH6eTVcRY5Ocjgjx3JEGgxTlj9Xdlif/mdep1Ehh9l2cwkDbzXXWfYAxyQCfEhKyK2+X0+bEdhj3YAB3+AZCUnwzOUk4/QJ6FQdrnGN1HDGn1gTOpe6jFihtH/B5uhhr+sU2DuHv4BoAKtixEFqXP2KW9Gcetb7b6OMcLBhcwwJyxHi8cWlvJhAxB5/hrhSYXUu2TjX75VsakXXptFLvSj51J1XkN1dHw2CieeXZYf2Ym8jzZlXeaQd6o85a+rUxDa1BZJytL/jUePA1nA/ACrCv0XZQlbm/m6nDHKenor0lZIpMFMS0kCDpRlLSAKFH/ouN08iNc8sKzlSUJhNw49e1vfrPc+ME7fokaZYmjL5trayrkwILKhYtLfvKL4pTJHDzZBeIsPQI2ShQCH8qSd5aq8W6NWSlQkL4ybhYD4XFrkGrRO64skQAmYFvAUxoUpgisEUwoIy/lT7juZqQiYCFX5t58793ywbvvlnt371gJnJWgz3sXTG4sJCy45LUiYdr0qUIpqMI/k8g39SNOvwmoYY6v/I6HCPv954iiM9p1Ok2wyOgHOlqfce7afggfCKoaMUqbNF6sZDKICCMOPjDJmZjnOjn8RNAnmv/S8fspLa8M4TEtj0kxjxEGURzQ1nlvgl0hgPZBefn2d/5SCsezKDGiFRucHhwijLbhsgaIBA83MKLwzquvsTvkeiIICR9tSZ9iV5N3nth9QplBKV9dXfdO5rqUq20p+aLSRKOEjKPMnBtzufQh+hz4eK/ujTffKK+99lo5v3TefHq6jEL2yMeR7t9/UG7fviMl+o4Uvg3XgxfbuXGRuqFgcZTJ3aHxRLwD4JGKc3/1giI3horSNgiEjffQ6HeYZNz+tX1IbsFR4P7nvkFoxplxGXcETtvC3ZS0WqChJu+EUscTXvnL+M04ycOOVq6VI2gUAlexlQUeK6ZSPhRGPO+02TDmaF+XiTLfnv5LWVM8StK8d4umy9zMVFWcuCgCRYpdQRRR8YNMyuujf+oseIVW/EpZ7CrNzEz6fSkUJ5Qxbn/juN+U4qbogyhLVoykONF31lfLNg97OK4nxcE37alfcnscihPXlvNeFXHqrOWc4s6pfB/6NW8zLpjRCGMMmi5V1fOfDXUVfaqPb2FUxfkvJ5RtFCOPX/GYjBwZhtP+uyUxzA9KqKTcTSkijCOhfpdPZPg/jWR2hY9+iJu5nKOD58XP11667mN4/CH3m+rfP/9zP1teeulqfVBwxe38dPmp2kJjivL0mdFYox+y0wTtG2ub5YMbt8raU94xGy0PH2gs3Lnttr94+aLrREU9v4rPjO0GrgqG+thWOtnwi52b1ocx8JJ+yzzejv/CY/dvkJDONlb6fQx4UZQw6g8Y9zvWunaCIn7iQSHL/RRacLc51EqTwnA/fwyvluXyE0ZeMDZ3/DH+6cYdtPdFnmZsyVHdJ0GXXIWFfxXIZhqPmg6Iz0/15uOv0HhsOfx0AJ3xVv9g6KPtZKcLo78asSPUB1qEoefr6hTfEeNPjYfloBtmzgJHaK3Qn/UkvIOMft3XsE8zqUt8gENrQMJSzx6EZ/0hx+F4PU5L63QnVfo4qHyPe2Fqaw35jFc/rgP903R+HHM2gMRBqbth90JhMK09mvriTEfr08ehH9cnNWetc51nTVHax13Ldl2nwdcma0PF32rRVw75WCt6O0vYDa9M7QNNUerXM04zwdXKFs5WMdMdaoi2jFxpC1QcuBRnuVJ+6mu88gOsW6x7R3aW1Je9pvw3v/8fJDMdlmkJnV6AVaIXBJAfVuRgsSOVZ5HiiMa0lIPZiany9T/4w/Jb//xflgcf3SnzvL+hBe3Zo4dlS4LFxQuL5Us/8YXyla98uSwszpX333+v/Mmf/KkEy7tSnuYluG6W3R2EyQiGeWLIuXsWQhQlFictZPqwQPOk07sWriTCexrDLJM9LkEaBiAcEM9lDuxacWwkL+Rrgd/eKOcvXygXL10QngPvDCBY8z8v/K8SR+w4s8/iyVXGLJIrz56W3W2urF4QnySw1/P88GJ/j3dQJMiLxibgIvBwFIxyKX9XCgM279zQrNAmwmVnSSPMAqzzq9EUmP+nklCgDwpq+48oWghhnjIsZCuPBSMJ5FYU3WuC2x2RCQuBT3brXPxSd5dJ2WRSWoS243FkwQ7O5Ob4olK5jCOAn3wyxOUYnQRf2byjhPLB+13YC/LPLyyK93vla3/8Z2Vjgz+oZeckioGf/IrP1JkOjHBuZUFxzQ0fmZA5Zgdenoj7z0PHOKq3L/5V/ss0RQygTixM2fmRUD4/r7a+7HeruNkLP+86cXU1u6LrG2tlbkFjRHVCSXr//Rv+Dyf6DjhR2HhHA7+PlXLESYOGY3zgOn+eiyaulKvXrrifTU6NyoybN/QTdsZobysctV/RvvAJGt0CaiMETuoN/gzyUe/e0p0YLyjsjFXe6fL/G6lujCmuW6dNGDu0ZesbTBxN+aZsK1t8NB5pWcJI01vcoCSA3XDpJ+Fu/vRJxgE2zPZxWNKrDi2ePJRr/NVNRSg5uIKXj/0C8lo5kFK743rlz4U3OWpJG2sM5Bp9TN6xoWs3wyYJY4X3KKGPC2H290bK48dSjrb2peDueIyuqT22xFf18DImHk6oHcekZLHDPEaf4Xim/OzWiEkuB1oP5T4cHS8j0+orvgUx/SsPbfJeGzRiGKvUBQWH8cH8BI304231Z9qNeBSnXfVpHlBQf++OKy1t5TTKw3hgXLAbRFmelxRHWhLQl3i4MKf5cHxfc/feZrkqxfHB7Vvl+9/7noX/X/nbf6t8/rNvSlEZLZviAZc//OHXvmYFiIdjufFxxnPSxiZ/Osw7qVtSuHbKlQsXy8svveSHVTyNW9vaLBeuaDy98kqZU98/1JjeFg4umHSbuF0y71Bnt2scbrUJjd9OQWn9Qx8DFaaFaz779SWWNPRrxhDKEH2bP+8c03qCLUzG5XnRhvgOs2lo7oYvfTNpmD/Fdu9QoizzIIhu6yeoiudEAfMRfi4D4SGBaYVA8je3vQlrMTFngJrsCE9kNRqN8VB0mU+Etx+S6UO66h8INQl4ODILn0/LRUmg9HhO0EAIZQDzAVZCmE/ijJ+2PxWUhFSUSzry0e/pV7QB4HmN+roPqc95zDtqIJCfdIPqAppWDild/5aDMu0chOF5SJ4BYJrqw5cW8DHLOAk8jgTHaT7qP9o2p0PGbIAWrdAcFR1W5vz4TwXlYy4bXi7tOzxN4KzpzgL0r7Q8/HGNKz97fnuHQEvUw/ciwDR0/fR0IB2nCtwX6L98sEWI54sapiXTf/bdq1JfGzdoAWSznbzx4O35mcfVcLGHQU1DiV4zOkNg3BTB5XPYlkE85pOxrSXNBrAbHtzIXJ/59Kf9wPuDDz7wA2JNLGX01/+L3/TOEgmw+dDNIbx1d6Mkjorpx7tAsqdEEMdRvvcX3yrvfPd7vo53Wos4u0u8B8ANV2Pj5yQoLkgQPV+mZybLpsIePLxflpcfawHnVrVtIReRYr6f4PHETgbBD+NJC8GGVVbpWPzGOJIjIYTraE23G64ygwVSC7aZQbgYwFE7nkYiRKAl+lpofUa5jUt1QjFgZwihFiHEE64UM56eX71yRWWMlfW1NStQHOHwAih8PgIkt/0hT/RzxHDM72FwzKw9Aef9JvwI3r4+WfE8PafO+jpzExOpY9ojLeBFXWHg9iREejc+tZZdG7oJpoTbZoDIkHxK5bajVU5BvNwIFTw5bldbGyNZG3a78aXtydNi3V9sEmfjdK1DSmBQuYlLGAodgrt3WoQG4f3Z6nq5d++hFBp4qnoojos0iLOiq/bblmDmPyVVf4mda74Z3AiCIEv/YXeJWw/TN8bUR1G2bFRP+gC7Rz6qJGrBy21f7Dw9XV72UbqnT5/6qKAFQdGC4s0f2kbAV/vXBZdb8RYWl8olKUGvSCh86eVXXE/KynHQffX3LV88ce/+g/LhrVvlvffeK++8+47/AwqcPtKktBwDnGWXTDZ0jigMblJP6GQRiEIoRV40b2xsMb8Y9kQffYNmgQe0ra8wlx2hmj6TMd6UQxQu2qc9qWmGsvi0o0nw0+NJ+JvSpOgK9FcB+fzlUwEGVTsCpvLK66T6Sb+nbPIFD2MdhV6Dy3ncf6mk+IjhfSPjU4q0IzsF4rfo83Xf6sP88WozExpf9CNITtq8a6LksWVic9HEeJkT75cWZsv5RSm3MgvzHAnkoQikcAvmtnea9nZREPjbABkprewyET+KkK+5i52KzCFSeNR397Y3faEEuziSpi3ocPyL67k5asj8QJ8VO0wvCj7vEDEJe9xrnsoOjca/bNqOuant9ni+8Ltyo1Zg3EYV6FsA9HhnENpUjwPRs6D5mGN4vglwfc0PCdg5RdH+4ObN8uEHH5anT5aVRIqGykERZ2dpW32aEq5culwunD9f1p6tlmeMGSlJxsUxRc3tO6oD/ZsHRcwtc3PcQLnndqXdVSPj9S6OzFgz5iFjWX3E/S7zH30GN3khIP0VG9a0NOER/db9W+Hwm7mVHasoTHVOJbzfDlr7yWO6FGiFTTEtHXGeRdlJlIfLY3i3i3GlaIUzb6YP48+MK5s+7b5ex0YL18clJ/FwY0sOvspj0+83beExhogunQMdYjynA7SRptEcGJQr5Q3HDJAm6WpqMp8Iwdc4dlKqVKnGwPu4BKlvZxRCLPYgEwiWnv806FHW0YGDkFrmxzHJO8DoSx9sIS8KGo9aGacj73H3dAiOhgJq/all5FNjXOYwYDydpVyldLKzpX1xwNxAPfoq3Q8fm6Y+fEOhpTvdgGo4+0hLOiVUhiYXEOz2cnT81WM3aB3UmfpRmrR1Bbvjc/bm19fzLsViDzP8VDe/Lazf7zWTdcNhxCv8FAPAa+pB3T2/a309r7WQY3irWs/gBTUd/bXf+M23LRDJhOCjkwnQkPpXPzyxZqGf1EL8WELgN//k6+XOzQ/8fyYTQuwbqLi56nCvXLy0VF57/WUrTPsHO+XJ8iMJxrf9TgkLNIX6KagUD5QwjuDxDkKO1GjCPxeBgWNXfnonupnweJrP02HyeWESXd0TcFY14UWoRSFD+KAOKAQIfuw8oCxJzXG9eGKanYQZVU8ckGCKAMKuyBUpS9R7TUzbkdDDsR/+4Z6nihaeJChZ4bNcJyHagrvogY/K6KNAarjsksRwjAhlCkUCoc7CPWaSP0ZNOEC5roptGjduOIBtUx0tDruljUDKgj/i/42JIF3p9OiBRqWxcIHwHEWAcEM3wlrHajQoj3HTiQAF8rgBWwlQGBBU0q/GhLPh4QnRgQV5FByeFiH8r61tlJVna2rL0AMzoY94hCs/aUdJkokClfcpMOwIsssCHuLIg1KT21pCh999Un/1TYj1aT8vq3M1Mu9goDihoCFo8ke1KEzsHnEb3v3798udu3el7NwvKyvPHPdISg4KFUoLLEI5YgeJPytmB4VjeyhRCwtL3qnkafy4yoYeaEQY5Y9yb9+5Uz766LZs4b/3wMf5eHl+fWNTdHNF+YzqIqVsakb0cqV6didcVymWamHRjRKVBw7U3e3pdjy0UJ1dqfRpTyII2IyT2k6xY9x+/ILDY01+TIvX183sdGnTJpooRYIBByUcBjlOwK/bRKYp/vRPJ9WY8TygOQDhHKNKaBhnLLVb9TyxypAe3L7gQTznSRIPBDy2ZGPo88Q7HMXEtpQo+jtCM31dcwG4OHrLWORCiJnpCY39KbXdtGwZKTPTCuMac/7WQNlFA7TyR8mb6ofrfv9pR/aOlJDdrU3ND5pj9nJ8TyNARrQySah+KFrtYgm/R6U5AYWvHT1rdbbAzs46vKLQWnd4Fr5l7sT2mFccylbbUYkSxc574piHLOhrTjwn2i8s8XBo3AvCg3v3nYZxd/vWR+U73/p2uXnjfSttSwuLoln9dnXV45lxx8mCt958q/zkl79cLl24UPv5lGrIzXk7HoPMuyurKz5yi6I+qzTQC+ksZVGSRCN0VntCtOedovSRZugrUZQw4YNrRTvKJp56N+O5R2Gep+g/mu2jMKVLRxFqNPRMiwuPw2vSdXlk9FWxGmvCxdyNsuTbNsVrFKK8S0e7SMlURtK5XY1PbkylA0fGFukIGA6p9wm2cTiBvr1xCfp+/G0sDzb6qXZ/UM9z1DhOjo6GYeB8NW3LECQdLkzD18xJ4PT+UZ3z7aUnv409Mpmx7B0IjX9ngR5+8xaXLFMexxlN8ITe00ziWz+qGT+RMT7GVx/+xFVumRWVH13cAKOv56czAXiHGf3GGgpJ1kfLQPOiIDw0zjPSORgavuHg4l5ImSrVVWC+y7yZ/tCrmy0AR4LijfUc9JPlNDUb+fnk6xCmcbviOx1avDF0BMlvnBWH3KwJDVodmmnAWmc5WGFNJkY2Yu24qDWNB/VWlhRmHeNf/O7vH/L+DkoEaLzwYAtBK9CF4NYXQYdjQ4v80aQkp29/45vlv/mn/6zcvnGzTI9IEdCCsbayIgF2TQv8YfnSl368/NzP/3S5eu1i2dpeL3duf1S+/4Pvlw8++NDvd+ztHsrw9H7fBiGP+rC75KNWLJYS8CbHppChtQDX3QYZP+mH3ioQI+D52IqCOXLlHQfFI3CiLVpwVPymhBWtzG7MaSlIF6VFXjx/weUgCJABwWlBi/uVK5f8R463Prwpe8V/lImChKDEosjuAcfwJsalaKn+8MpCYF2wfUW0aDN/YbrKZAKyTWPpk3esZPDL7EkAXl3fVF2l7FEPGQThfacHaIvUM3lzlIX8aXRw9zorrciuEomIj1JayyMVCSpOBBLjUedodsPjeD7qIFG8FI9y4jKTqlf/CDi0TQQkDcIquHVCvWjC3lH7P322rrokP7RgmT+UIbrprITz7hNp8KdM0qavIMjBc97zmJTyAt9xN+EJehoENzY7XdtWuuhXPt4omzDoJM84ArbGyNz8rHesEPjJB06ULpRqlG3ezcvlE/WIptKwKwU+8KLkUc7m5oYG4VMf7fS7WyKEnZLUvfh44sv1YglwgRthFGWe45/goG3MB+Hd2eXGSXY4OSqV3TPKhL8ocSiC7KZSl5QgqGU1HneGtqTF4beSWNikHWl05SGbkpHTdmsXaKkoDeBKu8UIS+YU94kszOQjv/u+TQRsgHjKpD/28iQfY3xbfFWg2paxlXaHAMZIdxxV+LyDCT2UJZuwHeVlx44dZ4677Wr8SsUo6J+eX8RH0w6NKoMaYvaEc32TnRIp+UqzxS4f72aqr+QIoIRkM01tMCnFeXza/RCld1KKBLuc4NwRTVtKj0p08fKVMql2HVM/GlU85TEOzGLqrHqNqH67qhfHDpkLzE9oE8A33O7fGnMcA/NcozA+5oug9WXPp/vbZXx/s3zq+hUrj+/94J3yJ1/7mq9bf+Xa9bLx7Fm5e+tDKxavv/Jq+fEf+zEpULfKe++862PJ9Hf+rPbNt94sP//zP18ucMxuf0tjeK18/533ZH7g/2HiuCI848jilevXy8uvvqKxpPErOoBQWPuC1hL3CDvhvdrtXOqZGEHtSzmup3jaqNWfNUB4zYeWx7YUJHaApBSjrLoPYkirPO7f6lfua7WMWppx4AY/sV04KzstrQDmHRROlCYajXHH+uidwfSGartFrUz1wgOOFbKjoYMh9Qtt9svuwlRP1iYr3US3uJouaeI/C4QyeiuQepwOZ8BM+ZXusEPtCN583cZxAWfFpz4FnmZqftec+rveqgnzVUN9CoQG8VCOQWUHTUNWy4kTn8uj2I8DjS+DgD7khx4Q+AKAIlmnga4dhLut642fUJb55Aw0Dk9iCO4h0CUYXt+zsoRyz4LvbMB8QoXpX+FVIwTr45fV8A2HM/EPcKJhKY/Wg/TJJrtmdYgal4emNgo7jVJjqBkZD+4T+nF62wmzoqRhyQPRswNY+uirdgNP0dgqgPk+hQuUxnJvTYvNWmA+yvjUhmSsz3zmM75J+ZbWPXjCpsvIf/3bv3vIuxajYyAVwSLCxpVJYf2GQcX59SUpS7sbW+X3/t1vl3/1X/+/y+bys7IoAUEiX3n29ImEmQ3hPCy/8Is/U371V/9OuXzlfNncWisPH94rt6Uw8WR9fW2j3Lv3qGxtIkRKQJXxERSEDiY1WFAXxQMpVVrSImBTOce2RoXWCHMi0AIQuxGE+9Y0CY+e7oULIQqRZlzCy6aEJW6iuq6F/OqVq1ro9srG2rqfxp5fXLThSfXT5cfl3p1bEjp3y0sSMPb32OHggoPQyn/8bG1KAZHQhWCKAmW6RA/MH6sCrJWFpkSoHsRhm/ECC4zKd3CAQIUSJZpV9z0EuKokYue9jChZHPNiRwYukNYdQaxrHaLxhye4btMqFJCDNFEqwck+W45tQbeVJeOTDXby8lFm+gGTJripP7t8pAUsfKiPWGiRO/QkrvWh0ARtoZP6bIqHvD/SNHt4ZFB8qwvAE+quXBl40AQm8sYovwRPjsKZ/zLkQ6BBqe7Hj7JCftqGumNoBxQabs+D56LA74ywHgOUDd8A+goKFEocigk3/s3NSmlS/6JM6MImHmUORZWBx7HM9fW1lA9/9X30+FHhjCzH86DxwoUL/k8ojj6hLHH9OrfzEYffOKmvZpr9PXbZ1s0vBVhgI513S+WnTtSNMPzuBK0n0M6Kb4bdWuoPXemrCJbpt87bB7U4h/tT48lrYZYE+jovMwvpnMHJHEeaJsQwdrCJdxLbPbxyuEwUFBqEtvXDiNqmZKW/0B9xw3PygAU/eVv7ZSxp/Crtpsbu+maOZHL5B8oPfYn3ldgV5E9/rbiob9Hy5OMdHC7xQGHiXSfmHN7n2ZHWtfJsU2mUEL6JBt6l5P3JCc03Y+wyimbeb9pT2SMofLSNy+GhDzuhvBdF+qlyTnF7pIV2tU8n8MEbxrXi2H2xEq947wgCStOUTXjIXONdG6mG44fb5cqSFHz1j7sf3S5/+Pt/UNaerpQF+bmYhz/2ffXll8oXP//58pUvf7l86y/+ovyH3/s9X/X/hS/8ePn6N76uufxh+exnP1t++Zf/ltK8oVEyWf7gj75Z/n+/8zvl8fJyef2NT5U5zaHnVFeURXZbGWfQYuJZbXEx7nFQJyytdPso/1KWgK7ta3+yQm8TN/VrFza4H9Q5LqA+rD41oVbjmKSFzMazanD3lKX8uM/5Q3qo7fNrHuDEAOn4OJ8gthCIRqeTm2PC8bd0FNDLAySWvqvQ/ogh0PjiMVXzEgI2joi7xzusl67z94UPhkZ7r16fGCgbJhqnv8bNp9//scC86Mtff7tatp8z4CXFWZSlI+A2wObLzzH/WcDZhqdFSaK3ZDkaXp/hoPWcByz6tLkYu63/Hme1HE5OhMZPWm5wRG54EXX4ePBiy2WOpT6Vf+Cl8wiwCPt4ZTV8w+FF16PrB7UO6Q+pQxem9reihHGuk4E4y341AXjddWofz7wlW0lGSdZLeiqAs0F/WmjsgWg0XyJ3eP2rZaZfR85xXWqa1LOnLH22KUsfoSyd07oueeo/+0e/8TbFctQAFjWCGYidTUF8ZfuYgxYmhMSVR4/Ln3/9G+Xd7/xlkV5UZscnkSK88zI5NSblaL3ML85I6FtUYZveWcLs7m6rpAO/EP85Lbavv/56eVkL87VrV8vFixfKwsKcBds9KSX8wegGL6tLeLGgaWWKJ/UIyr3b2LIDcmjBFdwoBrwbNDs3UyZ4GVfpd0QXaRFk+VPabQRK1WNhfkECrpQ/lcE5Req2wE7B7Kz1GI7gra2tFG7VeuXla77eeIEb/pYWy6WL58vSwoLf35qVsDw7w/EuCd3C7wX1kJ0nKTnbeYdrfX3VF19sb0kg2+Fyiy0f1+FJoEQh85wFHCGXXYq888S7T8Hrm7OkfLHDAJ17EtigkcFF3nYMBIUWPnlXQ3xDWbKiJL60DuRO1GyUOAuDpBEiAfx0l5O/v6PzQSghVMXZOAVxKgNlCYObizvSUStSp0vvimCeyRjhkye27Cj62IvsPAHGVv2gQYY2zy188AvcytPSybgoAQrzthSwpjizU4RSGz9Pf3NszzuSlWaO0zFQfMW3FgXe0eAIHceHeD8JpYf0MakfkxV4OMK3+my1PJai82T5aeG68ieP8w4UlzfABzMTAmVbCdNssygB8vXX3yif+9znyiuvvFYWF86XefXHxcXz5crlq+X1196wQnzj/ZvlB99/t7z37o3yF3/x7XKPyyWeqi+pXARl3geBbxw3pK+Mayyy68Xgp75W/NxX+JNRKQu7VfneYUz1diusTAlf2kP8pF+IN0iIkM8cgzJCu+U9QhiudNW2u9bRYBuhlEU2AiHzmBdiy/zJSxxP+mkD81f8tyJYPxGMlYeHEd56SQGUiMBMuG/ek8EmrBYkd8JxM8eBl+NeHCWeEa9432RqGmWGo3bjfk+Jd4mmJhDAhV/jiCO4OTqn+UvuA81NXJwypQQLmscuLs6Xy+eXyrXLF8uV8+cTZ8VENeQdId5tkjlQP9zbUltIGeXmvWn1Kf5+YUI8G1dlxqB5d6fsS4neVn9aVz/a0PyDcu13edTffUW53NOaI2dFL1eBz4pe/qgXM6lyOWqI4eKGqXEp1+yMqo7+I9/ZqXJ+frYcqv23NLfyvtGTBw/LtvoI/4c1prZ46dr18jNf/Wr50he/VF566ZL/rPbdd9/3rtLP/eLPF3bMP7pzu9x7cN9z7NL5q+oTI+W9G++Vd95710ral3/yJ8ubb72huPPKN+cdUwVn/VCdfROd6o1hiWbBTIvTtvRHxn0d/46rPUw0Ms/ZLZu83lUCD+nlj93iD8RfylW4DX2NNOrbNpSR9C6r+o1PAV18n1tfG8ZNxtNu+pja3XmV1vG1z8kpqPXq3IFWY1w1ciCQno+/0FLdjrMfbPUBUkLjdrKkbTFnAdL2UfjJgfL76DbORmuf/6wQyvgNDtdT7drqDBxPMxw+Rn1rIS6XHJTrgOo/Kyhp1k3oPtl0/S/JXwwIH3PvUdB8GxYIGi8YA+HrJ4fg6JXxw4K/jnLTNg33J4eGbzi86HrQD1K0fvKtUF0tAPtY0Ilg+vQjpElX7T5/m9exh0LDZ4BP1SW7Mw2zPE3ObXASX/vDSIsMxGkz5EbeXSeeDYGRf/G7f3K4t78j4QDhJIuFF5puEdHgoDCIkB9hkoXuYHuvvPfdvyz/33/5r8v3/vSbZXZUi7GETC552NpcK+cmD8vqxtPyE1/+8fILv/hVCSM81eeYC++XSHjQIhIBSorMHsIjSgUCFIqPFiApGFsSLngfZWt9szy497BsrHGEadNPfn0ts4S/CF3JQ8fhqAv/Ng/w0jO3VSFkbSgfeXhf5cLly2VaytAG/olJ34K2tLBUNtc3/OejCFBXfDRvyQrKnY8+LHduf1imJ8fKj33uLTEUAZ1dmFEfewL/zhbvWoQGGMvxKz91lmCUslUXMZ8jVFYQ+NDm8FwdNE/Ic5TsnOgeGZ1ShNyKsxHPEUBYalt9EWgRgtvNWu1pOQIwx678bovS+Mgd67g7UV9npbFtp32hB6XST+a16MeGTkUkE8llIkBbSQW3yiYd4D5DB1VnoiR2rfw0SmHGI6AzIlik/STUKs82CjTFQA9l8SM/eZpCTO7WsfttPol1gNKOlh0JbghvDq15G23t2JaFZvUHCzmCtgOEwkFa0lh5kpLMC+vQCC7vECovuze0Kcfr4DWDC1q9UAufFQoZlFqOe6LEeJdLfYYjdig5HA1lN6r9BxXvQnHFOW6Ey8985rPlzp075YaEUJ50kP/u3bumlfbeUv+amZkob73ximg69AMIdqTI22x4ZDqUh/6Hcsd7h43/xPMQhHqTZkQCNu/1qXXNFwB6vJtHnbBRWJQCHrW54jkBpbafGsV9AOXQ+WUSnvazQCp+ko048OI2Gv0EXf2VRU7eVwRHK6OiMz4SReknD/2BPKQhUY23SRpualPFvWPELi00MGYYQ1tqU25+y417W5o8Vz3ejEn52dXqv/EOP89819Y1z2lOy5iUrTzZQd0pq5pnMPwR8+zcgo+rjfFfXCi3mo+swGM0xpiU98TjnXHRKEWInS73IZXVdjPpQ4RRP+ZHzzFdW7FrmuOY5KGdp1GwZO7f+agsP3pUVleelScPH5VdKd4oLvxX1EtXr5Wv/vRXyhuvv645eKP8d//u35Xf/Z3fLRcvXSy//g9+XXWeKH/4R39YvvnNPyvnzy+Wv/srv+xz3t//wQ/Ku++9V65ev17+jsLYTXsq/PQ53uXzrYziMV0rtgzzZg2jsUR52W07S24nWo2GTxu2XSX75c7DDhSgmPjT9nkKv18mhQulybhqPD2O9nff1Sd2yrJdwwHn42MvDwu0eKpJAM+V4jOzjcunbNPGwy/RKYh9zB1vORQiqOzr9cMBehp9NUv8gBBr/GLjJzzJejZBtfiBoGQC4VF9Wl0GgtINAmIpm/YK9rQpEc4J3xyGJ/5hQArmXfBlHqKSodz4ZLI+qQ7idY05FRo+sgxL28pxkaSmfAfgxGXfmYCUrJuD8iRG9ah9C/9wDg0GKGYtwhXey2h8deuuC0gpzElUa2iZfXkGgfFX90A4Ez4RdjrrDOaX0LR15sUA6xeYxT/XR3jDNFuEfbyyGr5BkLZyPc6AunbTIRCZR5Zxhu5Aq0N+marlVjrcp6F2ukafEvXmJ8YoFn7VVfGo6p7uZZP8ODhcEWm3QMbX83aj2+VV0w9uo2qsBDH/Vj/rKGu5j+Gttp2legzvX//+Nw83tRhOT7HQaLIXYiYcP3WrCw9CddtxQJifnZouy1pc//T3v1Z+59/+d+XpnQdlflQL9t5B2ZZAt7+/XUYmtICc2y2/+Es/U372574iQUML5j7KzpoFPBaYqckZKSpXrSxtbvKyNDsGEqyqMKCizSFupttEUZIAsir8CI3rmxI2tLjz1J13nzAbEhJQUHgnAYVCWS2wRpiZtMKB0Hrl+kvl+quvSqmKIEMdWeyePX1WdoRvdnqmXK7K0uL8XPnw5o3y4QfvWVn6/I99RkSxEPF+SJQlcYkml6CBEB6lhwbIbpYELtGEUI3w1a6I5rjh9m4EbMItwIoGKycj6jrn2CGj46pdhBNBll0llEErKmoMGlcJLGNQX1+JjGAG/rZzIKFpT/zjinaENSta4ok7h/LRC92Z6uAkPfFRlJKOgQE4nQx1JSPFt04WWpKmM/ogtCHMoWC0yRf6eRJLvfHT3igilCeM4YFpBH+lVQac7heyG5DGNjQ6nSy1w+E5rmEezXtetT79NLZFlbJRKEmDuwmexFlZYjdvSv1naty3e7GYsevHbh/vh8BjFEL4za4k9cW4jYmTsXKssqHaZdMPJUTST9g95Ep1P30XXuI8/mRznfSn33rLTzfYqWIMko8/w2VscsvebQ1mHk7Mzox7bNGMs/4/oYVy9epVHzFFYWJ3jHIAeJXF0K7QJHx+h0P1s1LO7DWSeNLRJ1rd/L9J1Ek4LHSqj2au6LW9srmkfOkJ6rOEtHK7tqDrpT1ICQ+xHQZNogdeRAiNYZL2e0WVrvRn5TLOWj5zlvHSVzU+SCvTyg4dmfQZY2NTPKDoezChvKR3WzKWqo2y5PecGFviA7gsgIkuV0blIzaPjNL/GCNyK47je5TDu1ZcaPLMx/00p3F8T+OT9xN3NT5Jj8LFTubMzFyZnJ3hKsuyyTuWXDAxnqvAqTNl5fhdxhmG/tuvLEEn/RllCT5CIQ+AZjRvPbx3V3PeihcpbgPkynB2pFGapoXn1freHLeAfuc73y7v3Xi3XLp8qfwv/97/onzu82/5dsff+70/KB/cfL989tNvuX9xdT6t8ONf/EL5whe/5OtX6afQylX8XBThdvKkpVC1gxhlw7l1R8mhGVFjmGytHUU5kQLazm4Z3OZ6TdMUpfRHjLqCChqX8pW3z2gvqGkf3AB56TbM5TVeCRMX/AmjWPVTjmVwmylCpvxuD9m0B2S7PTRfoJymvNBr29BsXArVnJ9YSuzFnQaNHic/5ncZVpbcE2tYz4ae6jkTNEWpR/tpkLE1KBlRlG+hDL/TZizyE2+1HS5XPKdCstK26QOWV2rlwEQfYSzj+7jK0iCgHvCdco2TspsdR2efFZrScjqoDiKsXQLziUEoUoXQboz1xzzriogD/g2tDtkqv4fDWXjD+DoLPvgtfGegj/F5NvrOAsw3FKoWUb3de2vnMQvPzIsGDd8goPXFF9WjFnU6CFXW12FQ+TcIFE1xKrV+TgZ6E7Hhc/z+VvydXx96/JjWPff8UxGGt+DD9nzXcPW5geN+Q2PSsXD4x/rMeKePWeaTrP3pT39aytKq1zhOiHE6a+S//YM/P9za2SwT4zRQPUKgAZHjByw8Md0uhD5L8/Plwxvvl3//W/+2/PHv/IcyKX7MSTjdXV0vmxLswFMm9srU3Hj5lV/9W+Wnf/rL5eGjuxIaeZF+XQvoipSbdaEbLa++8roWlUML87yzhLDC8SE/MZWQ4EseJPzOTM76GBX/gYKChICKcoCywf/aIMTwvgHX1vL+ALs5vBOF0MqC/6k33rRAOjUj4ZR3Qa5dt6DC7WP37t73saZHDx5qMd8tC3Pz5crFS52y9P6Nd8qtD26Uudmp8sUv/JgYz9G2nTI+NiK+SbhSO4xLOBq1ssQuEQIXAjcyAEoMwnoaAyHPjS7/nmhDifJumerFH6lywxovnLOzhBC1I+GChRgBDoXPux5eaDJV+k8o1T4IYukICY/yhMDEDtShlDRuoMsESIejbAQpFAB45B0opSeOND1jcdLgDug+gHLJUEh/cLzSBlpnlF9OFqoZ/qtISg71sFAhHNyIx9E40qAE5gatCHgYK0tgqXjT+VFusshSr54i5SDj8o/aQeJRFUB6kLRJ3/DSXvQl81h9rylKpkFpPHg4wrQwq7bK/xnxhJx3hhqQhjaAp+TBbpMEgB8BNjuq4qnMSt3e5agfChnvznFBBIoNOwbggxaOqDbgogfiuZmPP01DeL9956Oy8vRx2d1eKw/u3/HOVLucAqWO/3fyf0CpDbgamu1lHy2UP5dGzHblQbv7hgStPfVxXrLveKq48A76a/u4DXgmztzRmy+cB/YqDg+Wj+zBvCCsv46Nw7ilkIlX+dsA8FW8wtmEYML5jwcFRPT1uIIW3MIRbB2Q3oY8slOy0ol2K7G0h/z0ddLQlig2JLWi47x5YJEHIBm3jEtf6iCFKeMpD0a806hxe25cyrTyg9f9yu08peLPqd32PfdsbWnuksK0oTG/vr5ZVlc3vIuFEgYNHEnkXabD6YlSFqVIa/5BoYMGxi71Bii/tfkVKcjQAY3wgx1PFE2UL7ed0jAWJzWONrQY7KhsjvQuSrnmxlH+M4kd9h31V/h/fmnRR+/W1ld9IQnHPb/yMz8tRejT5v+3v/W98o2vf93H4PKXCJO+nOSnvvIV/4caf+jNjhwPOej3ZHIrwFu6hML8RNFuV0fKkug+jLIE7y0Ai2+t9VQR14XGpv1wOD/p9KG/eJdJvMpOk8biAX9A3dvpiQWChpP8Gsu0vbw2CmiiNXHGLgf9hYddHEVEWaIPwm9oYH7igWP6BLwnF3ldYLWZOYGE4Tvws1ViEzMMoMcU9dv6sSUsR99Z6qWB/haY8OEQqoRLPB+UxzXznDwEt2igbQK0JVYbu0f94KsRpwLRjAW3FzxQm7uaxCmy/2EZfWNYvc9aLtCE5Hx7dvjcoqp7GCiZj8MNSO4o1cN/sYB9FiLPAMexUA6860ABIWsAcR1kjXse63Ho49NAYF1ichiOr2uPAUDP4kHncHxnhV654M7cFNxx4v44ZTV8g0BlCS/zzHDcZ8EXCK1J66ZhPFVP68eauiUfMAsOKje8CJ8rLjD046z+c0Ko1dXK0umghKLNF0BVEk0RuKrpD2N+oS79xlj60mPgHzbxzCHMDyhLb336Lb9WcetWHkzz2sfIv/z3Xzsc4QmZBH9kGZXnSM6Vw2AWAwSVEJLJYXF2rnznm39Rfuuf/4vyvW/8ebk0PVemtLJtPFmxsqR1URLwfpldmCx/+5d/qXzxSz8upeReWVicFZLD8uTJ4/L40SMrBlyBnP/XgfgInQhwCHUIdCx2LJTnDtmNyJ9rItRz5MU7FhJiAO/UKI6GRHBg9ylHZvatJX7pS18ql69csWA6LsFhX2U9WXnmPxZ9950b5bvf+a7/V8TKEk/lJYxeuXTJFzy8/9475d7tW/6D3a9+5csSNiQY73JrHu+AMHHxfy1qbo599U3MnaKhxrCBjaoLOwoctcEmHGEdYToK06aEMOUbmZDSx1NoKYA+aseTwjQC0waTB3Vjx4aGQ4Fqx8uCO0I/+Lmlj12qQ7URfQa6ELR5MZ2drnWO7kiQ7ylNwZ2r2VOH9M+KT599aFS9HVZNfyfMpQ90RCkXUgJ4Bw1Bjc4JLv9vkgQzhgjH0vYlHB1RlihTxILLT3tlEwZdTUiHzw0s0MogmLKEbO8wSEWL+zHh5M+g4GNlSyngGzh9rIyyEH4UvideeAFWXmgnP5ceUCaKfLs4wU/tpWwwwEiL4GkBWXGEoeBSUv/xKMrhiBa8ZZeV7d4t4Ub4mpcCg+IEx8H/6iuvWpnkRf/FxUUrOPyr9Kc//Rnxdb48Ux/e3FwtM9NjUpqelGWNLRQmDOV5LKyveWxAJ0fzyMe7gdeuXvPV+ODluBTHBVP/A/Fvw8qSeSc6oNkA/8Sg1urwqbVRhNpmiG+TEAo7vZbwtAVpDLW93VdUcpRVIiiHPiab/oDBTZQSTIpH8Bs/4TiIbX2j+jxZowQxX+SCjxyhhPjIG0pT24H04KYs6GWeIQgBhvx+l0q2i+vKxC0+aDwxhsxz9b3DkXHhYHLPfOB6Kz8FM99xkx5K0dT0rMop6g8c291V/uxEM+bX2DFXv1nb2ynr50SLlPbJmemq3EqoV1tx+Qe37UE3c8Li0pLHNmVimGOpLzuY3u0Ujf5PKs35/AXCrspSQitQtB/zPuznD7i3VDZPunmXlF0U/kOJF1156MRlIyjgKFDsdLLbxtzDbuinPvWp8',40,'2024-11-27 16:55:56','2024-11-27 16:55:56'),(37,'TRÀNG AN – TUYỆT TÌNH CỐC – HANG MÚA (Ăn sáng, trưa, chiều)','2','<p>Sáng: Dùng buffet sáng tại khách sạn.&nbsp;</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn xuôi thuyền đi dọc theo suối giữa cánh đồng lúa thăm Khu du lịch Tràng An nơi những dải đá vôi, thung lũng và những sông ngòi đan xen tạo nên một không gian huyền ảo, kỳ bí, quý khách đi đò thăm Hang sáng, Hang tối, Hang nấu rượu và tìm hiểu văn hóa lịch sử nơi đây.</span></p><p><br></p><p>&nbsp;<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAz4AAAGHCAYAAABxkYdMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAP+lSURBVHheTP1nk21Jlh5memh1Quu4IjOrsiqruqsgicHYgEbRaAAECQMJA77Nx/kj+btIAt0ArEmYgRwYwe6uLpXqitBa63mf5TfaJrJO3Yhz9tnbfcl3CXcfWlxYeR4aHmrDQ8Pt+empPT4/tZGR0TYyOtpGx8bb8/Nzu729a0PDo6214TY0NJTPR9rY6Fg+H2njY2PtOf/d3923x6fHNjk50VZWVtrs7Gybnp5uMzPT+f5t+/bbb9ve3m6ubG1mMNPu73P943Pd7ynPvcsz8qg2PJx7TozX/VsbyjOG8tlNm5qabGurK21pealNTM20/aODdnx6Ut8dGx9vT/ny5ORUu7u/a+fn5+325rrdXN+0xfn5esbd3UObGJ+q8S3ML9bfdxnzzNRUO9w/yv0n2s39bbvNayHfmV+Yb7v7e+36+qoNhx7G/fSUeT48Fn3Ma3xiol1cnrc20tpgdtA2Njba61ev2tDoUNHx7OSkXmPjY21jfaOtra+0/f399pvf/L4dH5zn3tdt6/Vm29pab4PBoI2NTbaZ2bn2u3z+/bfvM+/HNj4+3a4vrz094zDXkTY7P9c2NzfbwuJ8p0fmdHp61j5u77Sz04t2mevRZSJ0vH26bHNzg/aTn36Z72y04+Ojtr3zoS0sLLT19bU8dzpze6z5XV1ftt/81Q/tN7/aaTeXI8XfyemJjGEinBhpI8PDbTPz88z2/NgO9nfb+3fv2tXlZbu/GcWt0Hq46LO6vl73Pz05zjMP2+zcbMZ01zY3XocWr8Loh3Z09n0bzI235cXVyMNjxn3Vxkcn2+hoCNoe/vo1OvrcpqYnI08TkdGHdnVx3i4vrkpeRsYjp+HD3f1TO7+4bXPzS+2BXA2PtYfc8/joqGTpIfJGRsdGxkKP+XYf+iwtLbWpyclci7Yt/LiMrN7kdd2urq7yus2zx9rS4lybDC0HkefN8JHcvnv/IXJ2lWvzjJPLeuYgcjM+NZ17jUSfnsO33CNyOB7+T0ZGHx4i43nuKPkJ3Scy7ueHpzY9EfmKXD3kRS+8RsdG22Rk8/bmtt1Ef8bzfbpBp+bDz4nJkYzjOjR4zL0G+f0x87+ITN/We1P57mjmaqx0o74fftJn19xGN4ajF36MYzY6aY6PD/ft5uo69ArdM49x9M1zpzKvMDcygjY30YOHNhL7UHoaPtzl+liR6MRY8f8+47m7u6vxTkxMtqfHp7rncGRoJPwlnw+5x0Nshu8/3Y9E5u7bxcVlxvzQxnIf9uQp4zPMsYwDPcajp6OxTc/57Pk58jH0mOvvSx7GRvt4LsO75+jqzMxMzY0deczzzfsh82MvRsMTvxvzU3jwGNo/5/fhIWPrtgS9yYzvPT3ehubjZSfwc2RkKPo6WvN4iq6b22X04OYOT55LznK3yIfv3+V+5Cz0z3/ok49KV/Cg2PAcDct7oyPhV+ZmbO7tGvdDh5F8f8LYM/9hNjt/o+HF1WVo+hydng+NJnOv507b0OU5Y8ufdc/7jIMe1PdKLoaLr56BbmTIWNmCofz/TWT3Lvfx10R4vTA/kzkPR//oRmR0JHb3cagdHR4X/9ntydB7bm6u7Itn3uZ+I7FrnseWojP5PmOjQxvyMJSJD+XfycjJfHQzj8qP+T/8tV14Nl48Dx/J5eTkaMbORzxk3HehJx5n5HgWW/DwEBsQm/WcOV5Hh8yNbE6Gf/fxEfzbdPzI+GhsR3T+LDbF89xzMi888Z1784rfmJqcydify9a16DYZoKN+LxkIg25v0TxvxfYcHBzFFl/m/dzoOfpwF5kI78x/OLIzHjvuSzd3GVfuw+YNhw7kCu+GhujVcH7v9CoZ9JD8kCE8RS++jb7gkbnNLcRWj+W+VxdtKPcZZM57u+/b4sJc2aTH3IuvGh4ebyvLC6H9SDs4u2p7pzel25ORh5GMvz1lPPH5tzfRrcjX1ORYmx5MhlbX4d0phY2ORt+jl2ixuDTIWK8ziviozIUNovNkC9/v49/HxycjDxlpxkyO6Sb8MBX/dXODx4/1PhkaC3/M1zzp4HXGMDMz2q5vT2MX7kqGkWNoeKp4bQxPsQdHx3vFt8H0TGzaYvzXfN4faXsHJ+3k5CafDcd2tXaaOd9kbsPR08nIAV7ehsaXGSv+l93LayL0owfk/ilzuoyNJY8zg/lgh8n2GH1Ha1wZi/zTTTZiIuPhq0YnIoWjw7EdsRn59+7+pl2eX7S5wVy+MhK/fRn63GesC21kaDR8jv+5C70ebiO3F8EhGVvk4i4+YCg2YnF5MT5uNs8Zbudnp8FUe5GrsfBypWzMQ2zZQ+bPrrjm9uambOr1zUP8w3XwivsjXDBcrh8szLbh6D79Gw0vRiIj+7vbbWd7NzxjQ+dKn9EbDlhcyjhHn4Jj3hcfImSRhbF2d8M3XGSsQ+3Nm9dtLjLG/uDb3u5eOzk+i2yPh9+hWfR0Jp+HVCW7D9EB9BuFbYIbl5aWO7bKuFvsC2PJD56eHsfnHrXx6D57/pTvwnOLsTXGXvY0Muuzq8wTL/hz/Do/v2wX52xzx7ZLS3NF2zZ0Hx4Ph5/xLeH3WO4DJ97ejec719G9+IzYl+vMje6QAb51cmI6tI7Oh65XF/cZfnQ6skIGHu6fM+fD8Czjy3X83fllcEjs2ur6bFteiW8Zvc99r2Ijor8P4zX2e9gjssbOG/tjBPwumGF0fLhNz2asbFz0YWpips2MLbT76OuPP3/d/s4v/7CtRb+H4qNGInO8jHuEqaFZ5P7wvP12Z6edZOxLK6vtd7/6deYRH5H5jEVGPn/zqm1tbLXzYMjHyNlFMOtvfv1XNZ57tm4mcpX7vvv4Ifc7z7yDpWN7ChNE48+OTtv48EQbDg3OTy6CCw9KzuFb9ouPjZfL55Hj+AO+C9ags2PBJI9Pw2UH+YHB3FSuDG4YxKYsDiJvc5n/UNuNDVsPphRbsB9wOvt3E/k2Vz74KFgP/h95Gm3zU/PtD37yi/Y3/9bfbn/xq1+1v/zVX7X37z8mJrgtfRmZmp74mrFlqLoB5fb8BAaEcOV4w4CnUBwILOf9yQAbAMeKCIwYx2oABIPjvogz4bRnZgZ9sLF6jPvq2mqM3VQGfesuJbyCqQqEKGB+9zenCIQwoCygsRgD41zCl+8BdCbiuYKRh0z8MoZoJM8BPhDLGC6jRK67CTPOTk5jNARHNwGVhO0mzwnho2PjATccw9rqajlvIJlBMTaMFMQZ83QMK4PgWRwDYzsRpQG2FhYX2mqCtBAqxvY4IOEywdpkBH6pxgUkcS6dVuMJJBbC6KkC25SMM8BQAcxUnjM5MRUhWMjvU3l2AtHQGW39LSBAKyC3C1K0y0RKEcfb2tZq/g4v89zJXCtI8lzjJcCM/XWUjTAyRiMBAhdnN213+yBGsPMGDRYXFttSXnMJYJYCsHJ5O00QdXi4H2oYVu4fOpUBYQDiSCYC6AU7Aom7e2C6O29A5fbuIq8EjXGg1IKCnh6fFMhe/ATgKAXjHbbHiACpptbl5D6BKzl4jELiiyDWtAE2xnYqfJyfj4PPmxGj+qyUMDcbj+zhC1r6Pjp0ANENsP8ivjFIIwl6IgdzC5GlWOmoBgX23/7efpxseJsA4j7OZixOXYD8EHnleAA1ulLOJO9TzvHwiCMvoB1do1OeCyyMh28MCXl2keBJgORzesCgAv6DmdnMjb4Bwfl8GIAF2jO3BHCcP14KUhkrzicPyBPMtQMmNCh9y7w5dfTzu0BZcNf1Pd/wbwxvorKSA3pJl9y/gtPI0QtIR0O0Fjgx2L77EDkFMv0+ku+QiTHPzdxdJxDswWB0J07R98nIfZz/0BDQEzplDuS1/9Tgy0b41ffM3ffMlw688HEkwI6tyKNLdtia0vfICX4his854+foyssrJMp3M844edeQtW6HYh8jPwCZJAxdG4pevQBSNMmjeyCXn5I7dK5xhX/ha12TVw9iS1hj7Pv30MykRkYzrlxfcpH36atnVVARvgskgbDicXgggJMMmQDWondoxaZ54Qn76b7AgGCVXQDQhwKypqai75mrBAHZLb7kJQiid+jf5ec5zjZANfx7jr5KKElUZYS590iN1TzxmN4txAl7Jr3vvOhO/Tq2smxA7vn4ie/5KDL2kGcFUOQZ8Uclw2RAQMLBoTHQPpF5spec5nRsGTsJCeAtkCRIA2Tx8fETj81rNAGxJF7Zx7zM0ZiLwLnMPHwG5I5Hr0bDg9IYshW9zS+R456YEKz5Bn7Q0evQ4uwsgCH8GwPYYwfomedXAoS/DAuwV0CAH+WbwkNPAdoF1F4lu6GvYZUdCA1LR9Cr3vfdrntsK1oVeMxnxjs9HdpMm2PXo+fyJfzNTT0PqOIfJdlGxhIghfj04ermLrTL/AKEwsX8m4Al/87OzIcPQORVARaS9KJj45Mj8XXjsfcT4clEZLPb+8kAfHbb2MPgfK+DOToiqKmgQEIt1wv+njL2h4ebXPsQ0Dsd/zIIeTv/7zP3m8gQOZ4Jv7m2m1u0Ds4IPW8ixy1+dGZ6Ns9MUEn3Qrvp4ACYYzRzfAxwvrlJwHKVOWYuVOA2/vcm8otPwBawKxDoQX4PsNGajrFtZ/FN/Ap/iGf+FdjMzkyFSuFhaOo7jMd9aE1+6YzvXiWQEizzCfhKD4EvYJ9tqQHng27rJALC39CH/avEQ+hO3x6iA5LA8wvBUrH55ELCx3gEQuwCQN/tjmSyIWRO8ZPXV7EHsX30iD2VVJqdmyk5mAg/+KH7jOcpshiRj66GPhkj3aCTrl0K/lhYnAtGCOAN7wYJgvloycLrC+Az9wz/BG3TkeWYiuiAeSbwOj8rPcCjkbIt42WDr/OMu/CGjAkSjHl6elAvCYfDg8M2FJpOx1/DBWjwcB+s9ZQgMBMfhM9LsTWSdoPBbNHq4uIsgchFBSx4SL7QiC9l1wRvM9GThaXp2Kmp0C4YaWM+358oHlxlLgKFj+8PEwDmtbebAOgkNoecTQRHnuZ1XjLg+ezSyeFhgobjzCm8l6wN/x/ur6IPw21qwEdLtj0laJ2ObLLdoe0QDBQ8mflPjAXLRjfu87fEF1nDCPcuExd5n6LboTu5oFNXCZ5d+0UCn7dvNjNPCdLLuud1dObk/LS939luv/3m9+2b775rf/G737TfvfuuHZ8FZ2U+ErLvE8gIZu5iD8PA9pD58zdDsf1nl+dVWCC39A/W+f7779v7dx8KG8wEl0qGSaBex/beXiSIC37DazImcIfb8IBOSe6g13xk9cUmPT3f5/eO9ctX5fkLi7Ptp1993r78yWfts8+3Eisslk0eGXlqW1sbldyjV4eHx3kl0Lm5L3liW9hMmJ0t3t7dabv7+xUc/Y1f/rJ9+PCx/V//+c/b9sed4vPIyvrC1yLo4RCxCB3l8UFlWxiGjL6/J/CRaeyG3EvmyjUvmRuZHeBd1GUil5cXlZFgKH2fEZC9AtYNSGXGdZSW4FJAkSigxGnIyBF4Dvvq6jpEvWgXjHCMFqfPWXEiNJRhlxW+vrn8lHkYCYgbtM2trXo+IGCcrqcg7nd2etqOIrQF0vIMIKQbbQwj2LM1TlkUimiuxgd0M4GDGFcguYKHzO0WgIwBFDipJmCQ+zNgSwl6ZmPU/X4SIbqMMeJYgRUGRUboNONRQWJkOE6genZ+vhRWlUzQMZ3AivHc398tkIHhgjHPH+SaDDy8Azpua45vPntbxubi4royHxwag3t0dJJ7HOb9qzI4uWV4OJk5zZcRO48zZ1Ao4GTorNq2sbkaGgruJkPD63Z8vJ/5nLe52RievJYTwC2tLub3qVLY5yijzO3wqOy83x/zvNN2cqqSliBnNEFxFI0S3We8Z1FK4wbABbH4wRkT5KrYxDnL4AK1IxH26YyPnNQ1Ud7YtroPxZO1m4ljmo5xJreUq+QW5+JcKgjPvxVYZ+5Aqt9DvpLD21tgcawtL62G9oNSKtc8fgJAArXj0xjZgAaVj5nIGrAMeMX1eFDxTdAj0AWaJwKKomUhKRCd9/JgMnWbQM2YRvMMWUa6hM747BqyyIhwtsZRVZnw+zlzjqoidDnL7qiBOnMdKnp5ZeCZG3MKWJHh2Lka132+mmcYS14A/nSCK2MqR1WOFAgSWJGRPCw2otOTHsnodX2UaassVZxxD5pc/xg+A1uqA58+z9hl7+jNi5xWRjX8ERgV4fI8z3n2LIaRTuJLPsqdc0n+yD/uL7BiW8cCcl6yfRXYRUbqTmid99izh9DLPYqYmavr0MW0BEFA8l3G+pT7+5vdkWQo+uc9AQI7RpbKpmTcdL/kJjT2nt8FuSO5t0TIbGQH2GNXKkAJX82zzFamQd68KsgImBnLBwXQBTX5vZI8n4KfAjSZQx5VP57le4DwSO5pvOdx+mexk7fhjbkBGJ33cTYh6/NTZONJkmIQ2zZTsuw+/d/Huhea45Ms+HCcYI0jOkkOOPU+v56RB2bm5xfyrwx37Fm+Pz09FTt8VS/jzc1Cu4C3++vQMd8POwH4ClhrLvEheSYgiYbogK53cZ5kwWdTAdWDmYnIJ7DfZX0otuDZHAGn2GS6MR573bsTMsbYMQkfAHiCbgrAEgwQATpGR2T9+SQO2ByNTWKG7SbE5igBJYNMBlS2HkLnl+RRT1BJfEl+AHVjoXOvSvWKEJmI3JCLkrcu0xIdXYa7rTIe8ikxh/eD2dmaIxAjAIy25JoeWEyHDhJMApya6hB9kfgIl2NTAQrfATofAwBvb69KhgAm+siXTOf+7MRl/r6Mz1TtesLz6ICqJ/uggnoLpAs+P734P/I6MTUSEB5/EQDcASafTB7ZEvag2yvJUHIhkBYAzwbAAZ4T42xkl4vRjFvmmewLds4CIiXK+EdBLb0z/qGR3Dt+hF3AX5nioSHBMj8cuQk/JANngyUE9U/5/OoyfvBadj1faeP13n34oyMjKCNgL/Y846sXXxf9RC/zUFUfHg7/L04id7HJwRghUvgYv5UAcyZB+Cg5NBo2N58Z80vQxL6QFT6K3bitLpPH+Kg8S6BBTsLTmeAf9AEWyXvpXb4vYSqQ5lcA0vmF2ejaXD2P3pNn7wvy2ERVjUtyGtqoRNwnkMkjSlYL7IW+0/HdC0uzFaS4D/m9uYoNDp9vr6N3oVXEP3IQjDbpReck3SRr4CB8EYhORR4lSS/iA2K3YtsF3nfRefTBy9H8+yxxkmfzK3w2vwKPnJ3zG5G58IVMdezHjsdnRqjhmaODvZIddGX5PT+aXuYbZlTlmlfpIJCZjST00eFBOzk5Kr9yfnFcOsHv0EvfWV5ebEvLscnTkh2PwVexXwmALq9O2/HRaTvcS8Dww0H78H638OZl8Bh9Wl6eb+trSzWG58j6eILQ2eCcmIx2eRY8d3ncnhPgTE7DyroubkIzCQKsuW2Li4KzBDcJ3E5ODytZchb8cHGea8Mjc7xL0IgvI1X1v69/q6odH0y/M416/l3kMxdUBf7Nm43Swb397fZx+33b2fuYgOZ9+913v29/9fvftg87O23vcL+CoA+724WxdE1wIueZ35kgMTSm25IMT/xlxnJxdZ6gT/X0qZ2enLXdnf3wmS26i51WcezJeUHmRT6/zFzu4g8z8ghPi77dt5XV5QSWkc28FytYtIcRYYSb2BwdPPAfW1FBYGgj3/jFj7ba1uuVXJtAO3ZuJvMTpAta2fmD/eP2w/eZ5w870c2MKRjMOBUI2HlFkd6NdZP447B99dOvisYf3n9sHwQ+0js/+5uffT0bAs4nql9cTOQbAFuZgRCgsrsZMgWTvR6OIyGUjAxnUaAp1/khe655AIZiTMu5ZBAMvDYngQOjzkmIHgEmQIqzmIpAEsrrEJKhKEOSZwIYpLyyxpQ3/3GIAqiTGEfEpQQEZiyGNI/PPXsm2dhUZRDCGGTLJ/JaW1sNmF0JkSYjO1FkAEF2LjcCXjgpSqMlTRB3kfFqnQEMXDOYjaLlOu1HBjqVQETWFVjnyKstI+/nkqIJh2YcyyuLUfjhCvZEnTvb2xUgTCZ4mZ2bCv0poyxzxKSAdwKGPG8iwQiguLu7W8bl9avXiWoXyzj7AYgEmtvbHyvjqGoAcHMYxycn+UwFJIJ8mrmcxxHGGN7EuB0dHEegz+MYOVSAPHx9CMARUMTITU+NttWV+RjpBJxnpxnLU1tJ8IbGMj5xM/nOXeYw2d683mxv3262rVdrJayzsxN5oYmK0XCCwBiptfnQVsvPaK6ZyRymw5vRKMdqe5U5zSWS94N+DH4FKrGEnMNLMA503MSgk0oBIXAgyBSYyJRfJuDl8Bn3crRRwKWlxTgGLTqdNuSAXJOLmJvIDjkOHSMPeCiA0hpzd+fZ2qGeSh7IZFU58gO4cpQ3GQ+QPD4RJxJ55aQm83qp1Ix8Ald3uR+DMhXF9D5+Amkyk4DhbYyA7Ljso3nfR8YBTqCSHgGAdAAocL22B0aZ4RSIcSackBeDNCL4oos19lyfcQL17u9+/o+xCRlKz8hL3ilacHYCt9HouZYTWS4g9SV4KELkB3gA4vp7spRAZuace6HFS6aIs52anK7vC8T96zmcHf0XgKrEVEUo8lCBQQIE47wNEBsOzWUymc67zMf79MKc2SVvMMb0hRM1zwpM8pln00l2A8/p9sSkoFxVIXOITgOpvm+sxiN4MD6BBF7RLeN+lg015k/XASYSKOxftSLlHuYmKJBgAfokDAAphr+qGQnC2SttPSFx7IZ55vvhK7DkRcSM2HfQmuz7l/x7Dt2owDcyYGzGUlm1zPsmDuBC+6W2gSbzMBKaCNK0iAbQ3TznWWyGhEZA70VAT8AOYFBVvzwD7Z9Cl/OLs/BU0BCeZkz0yZiA8rLLfvJciQX2m1io5ABu7LJWh5vYZbZZVZcdlKiZTnCDDoBsr+gOhV4jbS7+R4VWO4mxkHEgciyfc/DzsZGAPoCOzmy8TPb1NeSUoCW6LRHCBpJ9lTxyR7aJqCCZX+N3BOICIgkgYE9GHdBQPbwNsBOwGT/ZruAywZWsovZH/BYMc8A+EzyQxxf5KrLkbyBXmxg5B4o5BTTS8sd+SHj1RNpj2S4+RXJE4M1+cd4AiATTSxVXtWsmPkPiaSx8kQkuYFfRo/ldF08uA1puzSG2UHLv5OSw2pPppqrGRHiwNL+Y8Q630/PTdnVzGj4/FbAHUPGFnblKwCfBApQAf2WrSu4SjDwEpIzr5gj4z/P5Au1AZ+fHkc2rfNYDfSoqATUfW13VwIx9km3L+wkDoy+t2qLIA7k5D9DED7o3m/cF1RJjZpjwPPdlZ+NrgeiAc/EpWWazYQsttk+P+DGScUa3JCtyrwpwJePVaPAjLzZFpUOQGySTeQcD5KOHyMJE/N905jY8JJC7bnMD2Cf6dncZXR6KX4nfj0+kK3ReRwB+ld3+hGlmgxXgAD6qgky+LWBMdwRfIKFQwWB8/8L8bMk7PyGZiQ+qiXNzy8FlKxWsBn5F/3sgKBjiH9gqrZ3mtr9/EuB/llmNl26PDMfHRe7C6Mhb1+W5qnIItEKT6NnVxWUwm3nEjkaXLs7iZ24F8L3Vl96Tt5ubs3Z+loDiRjv1TX6/aA83Acn3AjzJVC18J20k8j4bv7aQ8c7E5g3FpmiBgsGMt5JTkfvr6B1bzZ6yaxJ+uHMV2VXtCxdCDzj0PnQ7Db8klDP2BDoww2CgK2S6xsjunV+c5tq78uHsL100TrhQu9tVgiJ69fr1VugdHz1+38amHtv0LNx31w4SHNxcRV4y96P9q+jQZZeJidHwcaoqEcurC5HHyWCZuba0MhuaChAtoYhNnXxug7mxtra5UO/Hykdn6GMPhuZDc616x8cn7fz0OkHWReifMSYI7olHifC7PGMx9yE7wH58b2RSMqMNJ/CJ/XsOHQQNC5GZ5aW52KSRdnx60H7/za/z+m37fQKeb77/tr1PkHMZTDGaIOc8erm98zGyd1HdNHDMUPg0FcyzGDsAn97ks7/61V+13yZYOjo+7J/jWfTsLIHNyXFsRCa2ubEZeZjNuFUS4xdji+8jp1OwR/wCHQjDI7OL7Wc//yq48FXok0A8NkHS6ip+RfAlmUI34HDJjKGx+Ijp2NMRVf7z4PSFjEsVl40bKr2BX3e3j9u77/cSlJ3E1ly207PYi4wlw8i/PXDX4QHXstl8vbbNn331Mzn89v7DTmRooY38wd97+zXwup7obGN1rS3OhTCZgH5c4IViuYHWiBeDwS9XwBOF4gg5Yu1SDGNImsnIDgZYxNG8ALUvPv+sHKaAglHbevWqfZXBzA7mAsBPq/rAcAEgon4vQc5thJoxiBSVEo+OBozFQU6UE5DxH65In2F/jpEq8CVjcBUliAHRk8uJM07z80ulSLJZEwF4nNJFAhFGC1B6jiF7zOuOwwkRe6ZAZjPOJIJhnEBltZ8BiKFFHlX3WVxayhiWY4BktHs1yRzmYvwAlL297apezSdo0XZxkfsx6EtLC1Wem5wWBOlxH1Q2QCtV9SOG9mjA8V1kngK+uMswWenaGDvQGs44zTsTKSdMAAV156eqQYKojLt6mfW4d0PJYQiEzs70ml7kOQ/lpNai2AuLca4j1g3MltM7i1Fr+XcogjgcJRTUrK7Mtc/ebpVSw86jcYR6MxcWp9vSau6xHD4xDnGqC4uDtrax3L748nUvYUbBlcSvY8jRi6K8fv1Znj9dz2KsGESVLzAQyLW25FLlKuDl/MIagQQAoSPjAExpE1TxYag502l0iQGVBat+2ziTGU4ocjgCiIReHKP+c0qo3ST6E6ACsM5GfuZKJi+jYAKivubgOsHuZPGOUs3GAAvchiIXt9eRmzhYmWEBSAH0DL5nptE8gV9ksoLymTi7BWuM4mAit4C/lsKVtbUYvdnKspijOQFc5IbjIK+Cnvub0OXhZa2Zlj8BQPic/6yBGxWETcyELoMChjs7AnktADGwcQocbjkj8pzrZSVvYiCnxhMYRiYkA8bj9Kb11cfZqVqBbuQw4kX1M66eXRH0CC7MV0uee1VQZFC5uCpmeZYfOgD4cfrkFk/MayryK+CuBEae4Rr6AECMjHBkgo4AlIBQwDZELX4AHq73uWw+mxVWlfz0gEjAKLiNDQlI0uY4HL5pgVEpML6XVriqemXs5M18AFwBp+TPWIIHwsEIA3TGz9ao1LJ1QDLAU1XnAic9Y+dLJcfGmmuAdnbNOgkZ/kdZb+NG34xFwITOZNK46TcdAJrcUxAf85lh99YZtsyakha7eHlxG0CS6zIv9vvxwYVa+VQTAA42ApiLXQyovYhtxDO8NC7zUJUQ6FZVKnOsIC+yTCaB7ac4qZAgvwcc5dkCx8omx/TUupXwhW2ScQsp42y6bgHt5gIkV1Uocru0qI2YDERW4xQDv0K7y9xPpjyDyQQXFqLHM9Z7CUTu6p4Gao54OJT5jQ/PVNB/n2vwD6DKLOpCNoL9VD3no4Br7XNorGoVbNMe8tlI7H4Bggx2OEqrrW9GdSmyNhmdGMzMRVfGKzuOrp6TL9X8yY91Vp1W7G/Glt/LKcdW8VuShvV+rq/AJyCCS2OvEsYV7avqEHrhXclNwJC/iXtV/aYEdIIx8hJaZKzal4EhQQ/f5vqqukTGXMM/W8dqTYl274uMSYVB58BV7D39mJ4aamurAlLBpaz9bYBG5ChzuE+gdh3QImknqHyM3MnAUqaHPLP4GxBN97SEPUVGJePI59n5WfR3sr4ruACkJnOtjLVWJAGdAJNd6i1tUdDIj0CQb3tJNPTgQlUyOi0wvQ1OyNhGR2fy/kQBn8Ojk9A7slOyzH/HfyT4fA7xtPW14cn4Cm3wV+0mY7QmlB7CMTAH2bMe5yHgc2Ymdq2qPZ6r/Wco/ilgNHI4o80rsiwQ1+5EFiQXhgFUNjX6z8fMzs1F1scic9oIJSyuK1k0OZ0gL+MW3KE132++WpXMDT3oi26S2anZ0DmyH/nhM27j63Z298oPwmUCa7799DRB7k38+Cn/GMWJTlif4xpzKxwSPz42zgcKAi+r1RuNJD/3do/adWzH0PNo+DkdIDtTCbXL4Ka7+6sC7mxZVVLIVfhxdJAgK+B96Lmvu31IQChJ9tVPvggon4pv7/acLFzd0D207kkEgVtiy8jzVGEnPK71afneXHxFLVmIPB0d7YX+wPFw8NVsW1yxlmc4fFTFfIhu6Z45qjXEAiyV5pWV5eCSldBvpk0EOAtg7iPn05P5vhZ67WpXJ+FXApKZ2Jvbo9zvtNaXPtxFlq5GoiMCX2t12dfo3nToN595DsUGPQbAxyfCOY8PumXin6dHCu+srM+12fno24APps8JnhL8sF/aHQ/299rJUZ6VAKs9wleDjHchwU5sS0yRoA8WkhCWEOczTs+PQ/PzPDs+hP3IS7Lj9lqgd9MODrbbhw/fd9+ev6+jk+OZ40KwqPXGx2fH7TR8VDH5/O3bth58sRBbfnLYiw/V0h07tL+z286Pz9pwjNJk5EXSU7fCY3QI5ur+TIAfmY78CWZnBO/RAR0NPrf2k3xIbv3yb/0iGG8pfmMmgepSFRxUrPd2d9tl2SBB11zJ8vrmavvl3/5x+/IPXrWFlZn25U/ftNXQ8ipyKuG/G5n/7psP7f0Pe237w3F8nATIIDIzVmt+dNJIJkuYHUeuFVlqDX/sMtxHZ/7Rf/Nflz7+X//3XwZbH7SRn//yx1/fJEg42k8EdXoe9ecLYopD9KsYGG1jlcmINhZgAehIRKglqvYZIw8o9PJ/fg8xKC+HthgGaEtjFG5jiC3W8j2OkTEXuPi7jF5+/E6ALf6W1ZNd0mKB2QWucv3qeibLsQYsyZyXoUmAoeVK5UhmH/B9ASbACEDmBTiCI7Jf5SBzv4coX40511cbQu5tnnk7RiIRKOcUgZABA4YYIZlkP/cxspwqZyVyBnIEW1qhfIewAC0fPnyIQg/aq63XidSX6x6yFBcBQLcxGloNZQFl6mRF4paLeRYRU/JBHJe1VB0sPUWQ1vPc62CD4RhPVQ2LCV2nRWK4gqejI0ISYcwcBJvoon+W0++l6b4+SH88A5h3i7fWijAwgoKqYmjjipBz1AVo8DPOrAOL+wCOOI4AB87vJob7lhJEaPEM7au1MTzlIDlEmQLOSRmUkud2leUpRx0Zcw3Qj/bGCoygc8W/jxZ6xmAJiKN8aKtSKHCtcmj4JhhS/rzPa3d7u338sB9DfRpjG9CR+eLcY5yC3mE8A7AFoxbBSqs9BHhdheYXF/rTI4MFnrQO9oydMeHF/LxNMBbK2Q0HfFQpPhad89LC0XvqgVftawGJkXHz/msHH9mr1sEYjsqG5Tr8zEcF3GT9rC+SLfX9idBc+8Bj6MTpAYgcLFm2togcanPCJ7yrDQfoLbm/jsO/Vc0EIDxeqxs97+BfZk/CQnZXdk1LjVe0uhyoIF8F6SaGTUDT+c8K5GEhqJyvhAnZA57ReTzzMUc6CsQCdmyEq1XcZiKPgwRd05ExwTX5MF4/gqk58851eomrQkBXQ1NOzvMAyRp+/nKdH46+WthyP+OW4SYn1q417Vn1WX6tYXsWoH5d4xRUcNRVVfgEytggum5hJjBqoSmeqVIA+uiGZsCE8eRRuT+5D+DKfAC8oOfSPzRgV9jFGIC83Dev+s/9rPUIkM3YekUnPM53VA0BbUBJ1Y5eVKUnumou1mcI4v0rqSEIH5+wFgC4loXLTOvZ8a7mG7vhHgCMqoOAkt4hPdmkf2QtprDLdV7kTgKKzPXgDW1VK+hNt//Fu/yPbAAytfYjdmMsgatnAzi1PiI3lu1/ir3IE6vSIKh6Ds9GSvZUV8ajm9qYJBBkwslgbp85a9WzDqFAZeabNwNuyc5t0Rxdq3qSMVZAF9r4mx03P0CaHlaffkDCYuzQYHa6gD05spHBdEDnUILEcDz37O1zaHb2KTCrACvzZXcqORYaCAr4L3KQIdV80bIy5+EFlmd0eYb54gTZRHugWSAe8BXdFmSpkAmU2XQ+yhpRLxUNXQh8qTY4lFet1nXAF2sLVSXLVwp4SqxphZkbaGFF7/uA4JnK+o8HOAxmJ9ryoo0AJgqc1uYu1xI9oWXU9uEp4O75InZmpC0sJtgdv2tTM9a4ot1ovhewGr8bKWtP+e4geup1H3szHtrI/g9iZ20EMBOejscn0BUtcOyq9RLkDz8Qhx5GOOJTBJMXCWhOY3cjE1Nz7S5zv6IX4Z/E3fUNOzRZlfezAKgbspBBX8VvavEczXOHRiaDa65iy8k8WgdzxA7YVKCSQBTWA0PJ4eEeBA6m4rMmYw+mArgXJtvKsjUuM/l7rE3F1rPXWpAkj0KckmMgVBtTxCK+TtVBYiCf5/bWW8hOa4OeCj1ODnfD/NBqdrJs3unZael52clQUgD3cXs3gcZ5OwuYtJ5Xlvw8IJb/kSWX1CVnlVQJ7SR5yA9cQQYFvDYWEnyST75W9lziTouu9VgbW2vhz3wlEfgTnSA317F9D3RcwG1dFv0ra1s2SiJNEC9RKsGjesUWCkw2ttYz9+gQXJd56VSQBBm19isySD8E5ZIZs/NTecUHzI4lqJwJIF+uYIW9KAyXewjsBWd0xRpGrfEjw7EX5nZ8kAAiuhiZELzTeXa/1oZljhPh31x4594b66sVDGHHu3ffZtzWnqtYXIUXp1HUkdiT2NXLh3Z8cJRgYqfJFwpitrYkZNdr0T1dlQh5qQSzcdojXzoTVGQen65LF9lV1febBNs27nn//W473A8vWrDQ2CA6BsyEopkjf2qtz9X5XY3n+DDYLa+Tep3ne6ft+lKGJs++D01i96B0fvEw4/344WPJAJtpicXScvg6WIgMRL7Cs7W1rfZq800F0oKTvd39tvNhN3zOEPLa+biT5x23oYynNuWJr8dtrZKBd7EzCTLjB1VCL2/O5dja5tZy+9GPX7fNVyvRMevRrmJ7ErDPxebPCv4TOM2pXPN3I8WPDx++iz0fbX/4iy/bf/H3ftG+/NnbtrA01V5/ttI++2K97qkdThXqYC8B7cFlaHHdfvOr79q3v3tf7Xb4LEmuQ6Cq4QmmJe/5sofofU/2Bf9Gv09PriITHVP9kz/+4wRAu+1//ZN/E9910UY2t15/jbCHhydlUKYScCyvLSVa5vViuANoASGVm26YGNa+kEgvqowJpejBDQUJS/Iewy8DCigvR+iAdAbcbmnlKHI/Rj2jrAh/ZXUlhLIgMUqk5S7jEK0DHoA4RRUYlBMIOPCgiRgxGWPVHE6FIWUILDxdCgFljwmnjFO9MvaTk7NMPAbAGDMO7REMJ/BuPIyZ8vrSUhQlnwMgHGZXLIoIdOrF5cAi+IBDkIoWOEDNz2mCDiCZMMpyADAnJxHeGAqBiY0TBHfKzRatPdvB6PkuBmO05qzCpkJjUabABZmAW9lvPb2A3srqWmd25oEGImrBhTkCnww5gynDJ4taJfTQTebWuJQaLZQD1O2wdBeD1x4Za4Ctl/z1UHMsk1GYkRjbyyjceUX1AIdWr4Di/Evp72JUOWK7pRkrg3d4rB1REDWWz/o6pJ7Fk60eCr+n2nwc7rhMWxwto5VP81kPqgEGMoTZQI6ASdtesHf4HIMj41XOOo4n9yVrWs1kCwU5gA2IxZDfWtyqNJtnj2eOMm4Muo0CVF+Am9Pz63Z5fVfzvAyv8IsBQ2fldNleRqoHATJpFoiP5e/HNhMgICt2en4U3p/FiAMaDCXAGZomqMYWWVnzwYPbzBdYYbAojOfIVqgYVUUqL9m6fDUGNM7xIUY1ukDY0U8wLOB9zo1vMuezOMzj49PItmAl4w2h7vO854ANbV13t4Id4DdgLvKFDwWuGO7QXBZGqw99H48R11t8GZrZpQbAZQC0KfSsemhYwSqgjKfdkdBBWV8SyPmyEQWITT78FGhlZnl+ZCxTmQi4FPzcZG569wF6YDUkKplVjdUyNur7Gefd9UUby9zHYweeOTqjyjUC7LxTQREbQYZUSm4jJ25XfSICh/BuNN/jcNCxgHB4IEGiilwJjcy/qjAFzAGizgvREvsEpBs8uZWVFyCxdwJg69I8v9p8ot8CR3NHZzx70U8B+kQ8CMdESqtVUfCW+5ABLwGQjJx/Q/b6fsxJ9IQtVn2JbBY/epWXLmoHvI/eJiTJtaFPPu/PZkPIH2AQvn2yTexlbRARnZeE8CrgHBrI5lt7MYiNEsTWmiHJykf6qsKm71zyiKM0FgGjoC9zi0xXNSqOZ3SYA84AMpZ6hogKWAztZPLpiQBR5tizJSIE3bltjcGakUw4/5lnXhnDRYDk2cVlbPhYBfYFOkftRCijHEcdOaRPNhlBv6oE5kWw/G281pkMZoDcECY8EZTSjfs7O1QlwLiSwIlcx/vb7esyAcF9Hm73TbZJ+xw9NjK2wBQBoQpSA0oE0ewo3zE2YoG2xCE/lHAlIOrhMT4xdK4qZy6TZTdeO0G5v2Cqgkq8g/7ygMpm0oPMhVizgyNFb8DSxMjubdF5Nj7UQuJJGzbENqG3Z2aUHZxn3j5zDXvLXxjfYCZ+QtZ+EP89Hg0bvgogmWyr6zPxUXaFC6icHf/r9Tral8cyzunMeXGgUjFV4FTQMxa6lk7So7zw2g+7qspqcTT7KOjUij6eeUhCDYWeaH56Sr8yjsm5AmI2gxCM8k23sfFPuf9hfPphgoRbFcCx6XYevyAAnEwA+/A4HPB0Xok9QY7qe1V481xZcnqgdUer//jYbZsPaBsPwB6KPx4eUn0jJyqc0WXyHVkkO+xCVfCiS8MB0Wg2NNQTTRIifEGtAUyASi/I13CCMgnF8ZGbtrGWYFuwGZ9pR0GB9VwA38j4VHzIVdve3as1O/gvkWeB/Vhke25uIf6KT5YYgH/oibUg2np6QC1ZQJSPjg5L9y0IV807OjwqX8+u9h0Ye/tmXxOl/a139uhMeMz8tcYJwMk3MFk7lMWO8rsSgmxHJdbyLOB2Kj5PUlZbHt2AgySVVFinPq1LsxnG9CCyN/0UnhsHvBDbxb+HJ3jEbvNNbPFlfClbMMh3p4JJpyee29xM3yFVW2yLTTI2uKyMXCzf6OhTgp48Z2Yk8pnvZlx86HkC0Mu8yKRk//nxVS6P/RhR5XqMnByFRrsZw3XbeDMTUG/nN+3pbF2wYewZYH18dBY/e5brRoIVjJlN1/6uBTkBbgveSRB1eRYMcRH+nQb/7V/E5LGCdpF8qiLDdYLY89OLWobg2ptgG9dcnN4msLtIkBu5eRjLZ/GnT5Gvx4l2fxP5j9xPm9f0ILyMaGXedrYbyxhmJmdDy8cESycJcq7zXnR5ZiFB1U3b/bBfeNJnZ5n77WXs2tl1xnYS35155F6WPUwk+GTj2b6h0eik5HDoPzoV3DB2XzvTbb1arKBlLPrBtdrxcSVxgzbAucXxtrBs3fpIMI42fm2xseuR1c8/f9W23iy3hZWptrQ61TY25vIda9dVjfDgrMb28YfDtvvxpG2/P0xgdtiWFtbKjuKwQLvWE8aGVAs1e8N3xiY8PcUux4bCbtq4I/65dqT9oz/6b9vh0VH7//7n/5TxRR6mpue/tgAwnq+yEYMYgNX15VJeyqQqIKpSIi6HG0HTIsBRy5bLOPUsYRweJ8hg52nAAqUVNNTWpvlcW0PtThbjJmtVgClKKMtjhzROlOy+ZF4rCIgBM5bKoORzwIvCAbvlXPKqdUNHx20/xuL05KSebTEaZqBUb1nJ2PPDAVrUdRWjC7Bbo6OfvzKrGbcgSnCwvLya8an4fALW+Z7NFmRagDNzVHVyP9l/4xeYuE4LCZoA/MCQHww4ODioz615EuwBB5tba2Ww9EVXwBFP2cvYjxH8KEAMtgwLZyBTLMipNUsJcizk5HgZKgGljIk1AIyCPu1woNWWhAKBCI2tWwWPrpelVlq3tkRAEnMchQLecu8YpqcA7EfVlTvVlTj/69t2HjrvbH/M3/pXM6mMlcF2z7jbGLheWQLIgZ/z0AHdVRbQXOsOmqEXoGBbzLFRIJuTmqjvcCha11Q7VP3MGah8qaJpx7NAm/FGZ5nnlwX7/uWTyKHFlwsJRpVCF+ZX8t5EviubabtIrQXdsMoGaF8k/wd2Cjk+idxZFOyG+AbcAMiys/rzZfO0UMbR3skoAFsJfKdCwdDB5hRK1oIIwS0QR1Z8v1rLAMvwpoBqdENp2K4l5KUqizH4grUqHZfO9QzWbe4JuHjWuIXes4NmO3OtO5wNGbdRhaqkbI3qBnqo+qCRrN79rQRB7p45M8Gx/8VvOlftbwFpxlYTjzMXlNmGN66tjD5lqmpO5JqTJKfmgZ4Cn55R7xUt4NNnsl+1m1i+JztOdyeBeTQJAAnuq8xVvhXOd4fH8eEv+pALyYiS47yAD2sFJvMdOhu4XPOoBdSZhxYlhm7MmDwjtsu2zUEd7TnvK+FPZUwAt6CQ7AN7Eis9rwnYArGykxI46GTeZL1XhFUyZU/HJ2NoQyf9jBIsdBotyYxgyvwFOQAqO8FQ+4MNkFkjS8A8m8puos915lgZzLxvPRKDXu1U4W+vXuFCPo28CmbJpEqA5IrgnL4KfmTpahF3XSPY7C8tNarLZCQfVcLH+P2H1iofFvqbl+/2dkPrTULH2IMHQCO0YJPckcJVEJBndT5HpzKPDDPzCEC/DQ1tIZtpor0MsvYhfAyHMhaZYaDnqmjETpI4QYtsL/tEVqvalecC+oIa9ijDjx3UvqvP/yL8QBeJDvfpCZdwrMZF7gDVClyDCvkXC9aZHEkgdoqcqIoen/InASYAcl7VqqM6INhlp6x/yH3JuoSeClolN/JStR2NfbBTk0QMexhxCI8BrB7MSXJVtjIyJOAWrFXAH1BfUQ6ZCF/ZaUEMuZOEA9LNoRIP+Zsv0NeOv94T+KgG23KaHgC2tRuYADwBpPevyj5dtuWlpcw9fo+O5x5euVGA/6Dv4DVvzWnP1grU+uLsAK+Hy9xXIBWeRG/ohmDgKSBDZWc68sJX22iHX2eXXtZslW0I/6pqF17KmmfIFexIPk1VAmoitAgFwiNVm9sEoU+P1hHZSVHLK9vN1qMZcHbfdg+O28GxwCekC28urq7zfPoFELNhmR87C6HTgei9RM/FxUlo9tDW11baq62V4J2HAMiZaue+C1jT2i2BUTY2TDQXeMBLdR3d2UktwTYeGgsv/Ugi8FmA/EnA/0juAWt0DDTWPn+10DbWF4ovAh8JKvhqKjTThl1rTMNHNEZLCUpt4ZubMvkzobkKvQCnt5P5225ZWvRUSQWt7JM1bd7X/kUGtz8ehP8J3B7zjOv72jWNzi0uLhVw5q/YJN0B9L/Wj2Uu9LYS3vEBeGmdct1QIshc4wPtxCfJRSZVpCR693N/dkFHSZ+7QEsiJ3LwFB8bPWCTgO7tj7uF4V52SVThkpAhcwtL8/F11g7HFqmWFl10q4zHLkdGy0beFw9cNzdHBlXNbRWuTRvPtPMft6l8UC26kUM2dCHBJr/c/Vf8+fBDWw14f/V2qS2vWpcs+QxnPOS5UwmcbtrOzmGwXIKF0BBWeHqwZXtP7OLZyNBEOzux8D8ycx3snKAmahzbNyg/LOjRpnctiRyAHrXOPeDaYKGxvk02uQXk2Rrb4U9PzFW15+pcIjI2YeS+cPTM1CC8W4rOLtU94KMP73bat7//oR1njHJ3gp53375ve7sHoct07o3mt+0iQdBlXk/BOhIuKobj8euSxxK8MKP1oTZdCqliK7SBjrbFJdgVNrb5g3ZWW4ovls5LBM/NT7X58IFd1GFF99iC16+srxoURtrZ+5CA/yR632XC0pTt9/vt3fc7bX/npJ0cX2e8J203tNaa/Td++bfKnvYlHnAmOwInxu9Gbnu1lN94qM8z2sJ3MJrEw3/3x39cePQvf/PnbWkltml0bPprhofzZGApQi16u7QYaabNDRYywUSsiUAxxLkNdiYh0H1ReW8B0NYj81igKgMyUUaR86csMlIAE2AggNlPECDDxvidBGzu7ETwE3Fz+uyJ+wtCavFVAAXHwjnpCTThl4DE9wG09+/eh3hhZKJo312OssjCcCKESIkYUFteXSnFlSFgCIEq/bQqKbVNcAhYrTx5dt9FzoJ5xqIHOmtra3UdAnNWKhkFBONBGSt91HJS5i/A0YIXfuRZE0WXcvJhHsdsZzYgmlHh6I3V1pwWJlrIdc4BH56UsK6tr38yGs8xUM5GGa/yNeBAqa+vBTyUSKvdWb1n/qpiMpRTk64dj1G1UFWVKMKcMQqSgMYCYAE2BHxkzAzidKLY+zsHVQo9SUAJjHuOuRkD+jEWMuPGY074Us4sfy8vL5eRYfjMrwyOcmQCIYIZVSvjLKttoSIZkYEiV/jhHtplOOiT4/16FudnTmhdW91mTGQAKJL5Ibecmi23BdmCqJkEYvigoqB9ApjSIlY7CWawgmABwmmCGUGLeRb2j0WiREAsueXgJgOQrYOSuXS2i8wtgGz3mgpoEzSTS2u01lfXK+BSjWFUKiCLcSBj6I0CHIcsoEpLgTOkCR2BrO4gVBsD9uPQJCIEy9MJCC2AfB5+bIdHe3UdJSejwJM1LNMzsxmzLTID/vNSPdQehPeVuQzPBBD9TCAtUf09VUs68ZLJnpq01imOtAxKAGL+RQvJCfysV/S4y+N8OT00rWx75AAgoyPAPr18DJ0F6Jyo73IsnL6sPYDvmpAlzxBADyIPtkjtToWekIlyeqElGt1knA8VHNodSgtdD9K0xZFHQILBZHPwfzK0DgtLRtgNWW48NX6ZPQGZIKYWUOceAmOOcTxAlj1ih+gcAQFiBOeqpH7YAfOUiNHTL+A3l2qrzX3uA6LJvmAGiEIjdsZzgDM0972XHcps3tHtYfQxL9cD9WS9NpkhK+FRt8EBZbm/ChBwWNX0+h1YBlJycV7CMMBsOHLZhuPwSWGmw6ZKAOFXBhu6hT9xgACo6qekwENsv7YqdkrbYyW5Mh52WdBrPJUMynvOFauW1jhzYxasAz6AjsC4fE1kiXNldFggC56BiYvYeC2s/Ar6sQuykJ5HljiwiciFNZtkiF0HIvXaC9BU0aqtV+CYl7GSXUGtJIP1ebXBQpx0JSHyjVAx9w2oi+29jr+ztqUqcIQ9/HbMgawnW/p0JzARHMfeRC61E6EB2vGl2oLZIsBdBlvAqFpMP58DEF82UhBga8muSh7eZuy5afmVTDX3Pg/tzzL3XtEBqhDEnK3R4U90H6AjvSQr5sOmhLzhh+ROvhIZEAj5/S405UN+8uVPS1fYOm2/5L70Le/5CuXN7fPDBkyXXgN3h4enuVZCjB2I7OY/ayBvIvPGw6ZpaRWE2Srb66loaHdWrbLP7YyPzn3HYlcidGF/gpo8Yzi0vQ62ODqyfiH0DBHYM8+iv+trq/nbejfbM+feVw8BmPEhERPngET88xN5iH2fm0mQO8KG2YFMAGe94nhtlLEwz37Efzxcha7D8ekLbWWZT32udQcCIzrDFq7EhtM//OmboVj799gOjmz+Ef2XOM3cBOMjkf1afxhC953YpqqNTdu3RBk89PrVelueDxaI3xA4sQ1sxrsfvs+9VT5jF2LLJhMszcfGG/9KsMyXP/4sY1ysjgIt1UN8570AxTpf/FYp7f6SLZdktL7Cgvxa63x2106PQ6inBK+3I+3k6LLOLyRzkgAJ//N7T5DaaYztxH9BrlZJVSWBul1zHXFQW1praxsX7Fi7PF1tlXb8Uo39/rv3dSQGPZmMD8Gz/b2j+kzSTOVENU7CdegZjrCuTHvSUZ5xERra7Xes/fznXyWYyRwyN/MkpwIEfLbBwVKtk429nhxpGwkMbUJgHodHh9UueHZ2HjmQrGMn4odDY3ReWJprW+GF6pNmBrsUWpO8sbnSltcWqwJJh60hsxnMcAIA4Pw4AbaKDxuBVqo2ux/32vsfPoaut21jYz10S/CYYMfr1lrc2E3rbLW76p4gS7qmYDXraxfmHVUiac7H3pe/y0SjX7k2Y4W3yD9sdZ6A8CIycHq2X/ZJ8UEVjp93rtrF2XXb383nx2cJqmJLz2OfTi4i07qS+oYQMNI5TMbX5odvJ8vkk18sbJP3BJQqUof7e8GBH9rR3nb8IJoIsJznF+yX+TzcPkYH73uAGCXkA6xlukyQNjk+nWBzUJj2/PSqOsvsnre/d9zev98JHaNXCej2do6qvc16Xl09xyewmE1/LMkYVCClVZKu8FOScVpm6cDdQ+xJxhuliPVBP2dvSkb25Lqt9//pH/+TtrP7of2H//Pft4nI1cjU9NLXkaVczJj0oAE4qUXDuRNHZ7tIC+BlzxCXpwRYMMuifpkuwIRgMVYqF4ZA4JRRHQhabW9RQEQhvIwownNQDARwDGhN529Kx2kypJzLIO+trSfgyL8OhuMfGGNrdF6MLKIrY1trAxyxP6J/4NbCzirncoQhmAy1igLg7tBOVQyL/frheKpOTH/viTcnWzuLNI1LZQcwJyhoYF2LvvsuQFGqvACZ1Rhp2bmzGD7P5WgdVmpOAi9O0v1kkgQRWtdcV2tIYiwsVD6KkwFmlOwK8GTc1TcfRVcFULoN6TOm0CICq52K8avF/QmKlJYFThRRn+fS8kplL0+jPAC4dkAVve40A06jPJxii9DgYYGtGJmXjQYAts2NjfAwAdStPnAHVE7EyBy0o5PDCkbwS5T/w/ffl3LLIHCMelFlFR3eplQOJNqlxRgFgp6L7rZRBEjNUyZLMAfYW3jvgDxlTMDLLjDAabVgPSdwDKDMZQWqbSPcWzMF59Mln2jH6FmzJuMAtALsqgaAmszNVXTAmjLyryVO/7CKi1YNLCY3dihxoOmbt6/a+vpSBZcyi0cH++3g+DD2eDhGdTHyNii+GqOgikPr25QGLOQ+HQsIeqzNYERtJPEpc0Mu8h+Fdm9lfmDcosECyaF732mpAwIgugdRgs++5sMmIAyiakL1wN6Gp7mXilEmFnpE9yIraFTVv4AFmUWbcdALtgDAtOtRZUzj7BgdhpkBFnyYA9AVBoVfU7mngIkzZ5ii13kPn0v3IzPuWzu/hBbT0QfZSKBiL4YV2GMDAEiBBl3AH9VFyQefl84CoFoXAnS1H9iKU9BpjHq+HW6Lh9rM/HDqKhhDmTPw95h52ma9zjyir3GSzg5RiesZdrwQKAS8ZBxshzV5iwHZstkAUa/mdoBZW3HnvjKdQCjwySHIvKmwzs8t5tm9UiHoL96GXgIc8i7Lig+qTZU0UgnKvNkXki75Upn+fM/ndAqNVEXQ52VziYtLlVuJhPCL/Q5dBWldzqhlJCTyAjBFfWKz8ky6Qy9CrxpH7KvMNHtmw4yjk5PKWBeAD8jV/sBXVoAiQIvNAEBtzVvrXuqap2q3ZN/N2by0VOHXuaRDnDr5YLvvMsbMqgL14SrXaIXU3geIccC9lY7+VJX+Whtmb3V2sDPQRsYlotgKbYe1u1/oa/4VqIef5BaIyK1qHBVAZ0xsX1UapgbhyVBtAHIcR28d2Mv6T9+vIIX88lN2zbsSpIQWYZCzL1S/+Imr8mnhTPSggEDk2fkxN2xLQF0tlK8A0LNjp6MDbAAbRH5UcflI4yWHqj0cuLNWyFitAcpLMM5u0FE+s7cHoTV5mqizTWIAY2v7+hn6YQ3F1uZG5FFnhXWhC+EP32KBdmx75Lm3F0oe2S3pNO+zE72CrtuDHZmfWw6QmalEEq9nnFpuHDrJzpJv9lSyB01GBAABZ8+h52Vocnn9VFUaAc5d7vcc2t0GBD9L0uRf61kJrUXw/FZVTY6PMterjHkxvJIMeAxwOmv7+9GNW7IqeJREkQGeaYsLAb8PAfUPF2Wfl1dmE/zEpkwEjwT0zCfwWFiajJ8MTrDrVgKeDDPyfFXAW6VMlUTnBwCoukP+jKWD4dEKkB0kLmmk5RO2HeKMQz++CTDjYyVg4ACtrVr4F2PzHm/ZVbY9smv9bAK+m+AQWyerngkqbJUdbYjtoLO6P84TEO5XN44Nhxo9HtI90pOfrJ0EMl9clc0MZWoa4MePh1ojcnkRu5bAZ3RIC6Jk6FSdjUImbcd8c3Ne9Bt+nsy1p5G1q9hO7W7aaxPcJhDnPzY2VtqXX34RTLFU33/1aiX8N9fwLYRQcdj+cFDPfH6WwMQf2XoBi3P6ViK/PQhgN8gXm2AO5P+zz1+3r372k9w7gUzoxQ+xAXyZ6sVT8FG0uXjOTjjX5+4x2CByfHxy0D5+/ND29mASGOUpvni6EuH9OJCJBINLVUUay7wlbW1uMBVZULW6Dg0SWuW+dnSNgj9ZljGc4OEy8nbaPn7YCx6UZIsNGp1uOwl69naPM/axtrqyXoHYzdVTQP59wH8CjFM6Oh5ZWsrfZ7W9MhslkSBwqURffth24J0MsPWSjxITAsuj8NTGIf34FwdpR861lq2sZE6LpW/uy1frEDo/S3AaXZi0e2fGNRn7JkkkAfT7331TsgyDObi3/FbwVy1xiMzMBkuyHxIoMPXJqYNnW1tdnm9rK0vVYr6cAHdKUJSg8ofv3tVucNYI1SZMwfr8Ffu3sb4Z2s/HzsTnhZYScp774cNujfHt6y/a0spaO9g/af1g1NbOEixZcnAVHwP7VhIo9srasarsF8ZswV6rmf9c2VLnw8F1cKndGAXnupkE43/wB1+2n/38x+0f/D/+QfT0uh2cfmx2xhyZX1r5GugsQJYZUhLghtPXAiTzpXdc1pgD5xA4I8a91iiE6BVtIXEUmeHEVIBPplXgwYDIbMiEHh/bpaKDQJUlgut3rS3GUSA1ho9z8q8q0O7OdoF1yrEWYjKAiFzVqThfTs6CxRKiON98MUYqzE00WKAlYBKgs/Mb4ujvFV2Px9BrpSJYMr9AmBdn4NmCLdkSBg+wQhttRYx7OWbjDRBGjx5sARHWJFlYCpzJPPb1N048to4J07RocVrmqD2mg47eFiVDwbk66ViGQabZDfsuZoJBNIqjnBiritE1Y8SZ55kqI6oCPi+HGcVBF6BeS4T7GJN7MRYANcOJfkBbTHbJQBgdMgZYhf+CXC8gCnDNpaFBzw55VWYsxmkzTlXG3/1lnwTOdg8S+KigVfAT5by+DPCJs6ugI7TMxblPnE5kTGUNT/tYzJFxnshvveSP5gKdhcXV9uazz0Pz6dDxMfePaRkFxIdjsAXAUbQCDtZucG5Dbf9gr4JbIHgtTs0aMnLieeSdYR2PLMzKvlTGNjavsuUyLzLZtrW0Dfd8ZbbsxtIzxqpfeXa+cKHqFrBAd7wiHl2voit99y1BL/DXN3fwEFk/uxJ5SSpYfAv4kDMlfz+Miey/isWTABeNw/CqIMSX3ASUKPvracdv/ESLXn3tQZZsZcKffE81TqYyQCuOWbBzn4BSMITGkercv8tJ18HerlJteJF7IK3mFfkAMAvgBECZm+QHAee8gPH8ms/65gAv+lzjydxknh1wir4A1lWMbz4sWpkbncJL3weP2RVjIXPkGxj1fGcoASr0lLEm85IMAhmghV4MZdy3CUYsSh4eDp8nIk/T0dnoLt7ZfIMcW6vDlmXY3X6VPcu48x955pDQstOmt6cC1/iVadTcXUC27VY5Ow2A9uoIfQf6OSm8CBvDb/NVAe+7ErKDEjdaC7pc2NWxV4vck30tmkc/0KwGk1cBzTiUCq44a5qcewFl9LaqAOGXKpUzUyQBBF94VluGBmD7vGeKw4dQXKWmV/gAWFn1HkydxhlqTaHTkjbkW3Wx+woOrrerqaBURjLAU0Y48KvsjmdqL7Y+6zZ0eYhtMWQborBRsvsSMYJLcuZO7Lq2FM+xpo0c9NYSCRPZdfYEwNQi3IMB9rdaKDjByFlVbSP77D25V/lBY4HqxdVtO7N1c4BZJK3GXwvow1dyXBuzhFeC8Aoy7vN7vqMVm57il3n5dlUFQjuBIVB3H3CnS8FaEOcQ2RFNtd36CbL/ANiSgdgHP9r7BJT0VOV9ZLzPj9+yGxI/RPZq/VrGHgmq55EB2dzaeS+2RQJAVnYqOm1x93R8HZ1z2j+gYyzkiA8W+Pazd4wpVgKt+JM8s3xAfsiVoxG0UhI9Y69X/qhEEZnJc637o8t4WAFkaHOZ+ewdHUd2LsNO6whzD+MOfQSGYwHGZxfXAe2nAXhnAW8dIFpTglcWtcvs5nGZz3TswlVVDyIy1SFRspS50F36s7ougUQH4Q+Hmcoin7fri5PYzMvcRybZmldr2vjo0Df2wprEPi++vVcJ7RKlBava/CMbXoIyrcRL8SPkqVQ/tCNgWm+8V3Yz/hovJNAkevjmSuCFL6rHZJs/lbCanwPM5zOfqbqH1jYqW/aLXMUOSgi+tCgKhPua38nymzpNmAMYwg/dyyW5fwLw+N79vdN2cSJLH35nXtoXp2YA6GC+RwkD6zBGClvR9Z3t73PdRfwvOy54uk7As9x+/OPP4v/mip5VGctL++zzk44a1YbDBD37GZNEg3PC8FiiSHVithLP7A/9urtSrTc3+u7cm9E6sHJzc7UCVd0XAgF+gC+EiW4vfYceO7MwFi28HKPLCVb4spsAXnq9ML+cgNeBl5KQ3b5rA0cXfqja6WqHXPbqofhDx+gW+xnNCx1iAzI+G0wdJOg52BdUhH6fMAfdFhA93OtOWIjMLZYen5/chgZH7eP7/fpcm6sxHx7YnCLYEqaqHzqDtjAPHsS+5D9JfUkoMuJ9vgONFA0Eb9pjY2lrbvyTzQre/fAxImj31r2qqMBykkN272Sv7RCs/XB3T+eMyl58XL5rHTR/3M+jEnAFN8Zf2OraGqrxzMf28wkRQ2y4XVV0Ovy1SUI/F4gzmw8mWttY68l0OvApsFPUkACA1/nNvvYdZuyH4ltDfHBw2A4OE6jWMgM+B1bpfsIc6TA76eDdpZV+FhB7D3vBMYW/Y2d0+CyvwnaS+vPt9Zv1BEjLCaaO2t/5xd+LMj217cPvMo4E2qtba18jKMNegCuKKjvIkBMgwIPjGAtYZWyBHFEY4cEo2zwjpAhVppYBwAz34igNqLJn+Zwjt2CRwyS0gJL3GE9EKYOTe/tOZcvjdDgCkTzQpT3pix/9qBTHIaDWCRkLZ8sBMDZVATC2GMrLRPKEp4MFinlbAm6OJWABPAKPvb2dGIezuodefk4X8PGZwI2R0Y7jO4S0Ax+ZyAhCjEW1yeW+HBSHAWgI9mR9KJN5HR0fFc3Qhj8XYDFi/j3OZ/qubZMt8JAttl+/6obMvf5LgR8FBeS7gXJwF/oyxI+19zoHxv6ilzlW6XJ4vNpOgIpwtZzkeXim/C44ME+tfhZ82s1IVN13UJM1CvALPSugzZzdU9YV6EQ7AgksO2+BESZQ+oG1uK0sLpch8FnRIN6hbxCgLTLjCx05DIvdqzIRQ6MCWAuTr+/juJVRI4shaGYRx0Tp59vWq7ft1evPKlNrIdul3XpimNyMQQGmZSHJJaAC+DF6J6GP3tjZKNPykl1BYkAyLrIro+TZghUVTmBOIFBVEcqbOQrAtKXIlPrdYXNaxiLWGYc1G6FP/sZfoNP8ZERkacmVyoMAwDbnZERLCTnpsmkxXvgTh+rZ+OR/9EeZl1wwfHqvzbeD2zwvtii+Pv42hjWGOJC7Mq/mIJsLJJmHamDpNLSd+xbQVjkJr+AtDkM1i0MlQOScPaDPleTIgI2JTfC7+VZ7Wj6X0CDX1eKRa8gAee92QwVEFjz6Fj7jAyDA8dZ6A4uL4xEABc+VfbKGgnw5GE2VVRBWMh9eGZkydgUQAtvQh47QzwICmQ/AK0POHnFhGWzAThxHXrZbtbVoFa1jyN1bhdQCXC2NL0CuzxU9Oy0kZfRkqyQJwjLd3FZw3beKpbP02A8+0RW7E+EHcG5tTreHuX/+cz1AamtzNGcb3VdLsPYJn9M/8y+e5Mc1nRdaW3vgjM7kJ5fGSRkPWSB/XV8NFF0Ehn3XNIFKJCfXsFWSJxb4j0XOtTBo7SRUWjr9OxHkZYyc42P0xJhqftHXHtjH/owF5EWIBMf8RFXM859Ahe4Jpq5vL2renssRou9RbdceXoY21mQ4mJptJc9d74G+HoTQidlq07BYPUDEOraQu5JQoQ0/lcg0/wugzL3ZNM+ijyo2Al92TdW0r1fIfKK/MqjGYBMIG4QAs55XzwyttStps/Z8QYIA0MGvuWWznk7gIxnhWbaVJrukQIVeUuI5NADOn2Jzbe+7ND9XY7CZAdp4kUHZVj7n+roHaX6vyr41SBOR//w+HZ1W9fBZ6WPkTfDnX7qVEWccgSeZF7+n3Zl9ssGAKgN+3sZ+1MHLsYVsAN75eQjRSwZDR/Ydr+gkP4y0dvByULMMvfZnMqhTQjuVC+hztzUSIbftIuMUWI+G1upQJwHeJzK6kc9m/UP+tluZM9keJAZiu7S2yNIDQXamrIX9j8Ph+1T15PNzZ7kGgfkwh4CyN+it1RCvVVrIzdLyXED6bHjFFllHGlkgvwk+63DNyAJb7NvwAP3wPffCS7IsSavSzIeoQmkTV42VoNMSWfJdOhCfFdrCIYK9F730X1WU86pkcMCqaolg6CHz1gKtwqV6qmVQOzsZn4mMq8RIhpI73QsEso4XSFDTdSL2NfMRUJMB2XQdFXy4lnpywFaQc0DTgY9HB33DpbzdnOWzuJxnJHaw3fLxyV7ZQGCVn3Vuy83NaYKH6bYSoMlGaBH87PNXzSGeWitsNQ0zHR7sB9PZmt8ZjRdtdye47MKcVDMDkAUHZxc1F0lBmXnn7dXi/nNbN9vdDa/ouMSj1jI85h/6mU50yXytux0ZmoqsPWcOAcQZE/91rx2cpEWF8RX95ufstpqgN3QUoFn7TddjAuvU/3fv3uVf60ckeAXACY5C19q0Ifwmq2fH0cfIWa8wnlYFi0yGxcEZEjIJfsIXbXvsvfVX+LO3fdp+qLUqEr30xplJfVdYCSV6Qm6YnBiQ8FPwE/sVA84ulz0JLyq5FvmTqJR0dXitCpDkFHC/urpW97XbWe1ymd+dz9jbqbWnP4X3++0craPXZBQO0dnEt8fFtdEIvYSgnQnZCzKax+caS17O82987b1OCstQztrrt2tV/akW/9B8bX2lff7527a+tR7eaftkijte90wty5XMODvNM3tbJ1ws4egYGjhBPECH4TCxiL0GFB1UXflnuwM6+F6Fjh4Jwo+PDzJP2IqcJ16I3tiQzBlP9IOeSfxoDfz44V37L//+fxs/c9b+w3/6s2qXHll9tfC1ygwjUuslIhmIC5AYJAbJpADBBVzz4gDdvEpaDHUcFUfEYdcp6/kD4CknyRGSyPyU887kGRnf87yXaFamAsMBNtcBQYjAUdRiy4DoxYA6/2ofe/fufQRJm4ksaM+oKkHbfpnwyVI4RTiPKkdpod3R0VHNrc7hCfEHc4Pq493b7+uLGBdnNTAaHJ6xCGiMzQ4lDCOjJgsrw2y8HJ9rXG/u1R4Qd6wvVf8vGqpyffvNN/l2X7cgmvcMRkYA5zBTVSDv2x65wEEcDmdiDMCNLCChdcCs6lAd3Jlot59c/ByHsR/6y1Qz6p4Uxcq/hN9WnrLBSo7Kl7V9L0eX72kJck80M4+R0AdilK3s5wJFOaIk5syo+54qkVa+1UTXAiDZX6XKKuGGVrZf1iJEebVnARuMhDYBve7GILNbVbvMzWdAogf3xaiP1dKIbr36GCecMQgCFiPc6FNrqWKELNDrO6TIpPSMF9nVey+rVAtNQwsG0vwEO4hLngWsAG450iig78nO9wzmy6YL+E8mAIuAkHy/BzAnpRdktSpUZXQ7OKUbFF7A+VCVHBkJxkUm2InF0+VwZfzx+c5WmgEU9AZ9WXDPkPH0kgE5OjqJQwoAiSFl+Iue8jAxwqOhj7MNZHZkUawBqkWzNxe5zthsc96rIr6l/aVvDxwZiXPsoCf3NJ+MqdQnzxdw0l/rK4DADrwBpZ7R1gftfQER3RD8cHB6cYGhapHMs14Chsou5Tdb9pomQ0x30dR96BOAKjg6FSDmWQC8ymxVhdHVvHJvwEpbEedf1Y/8XT9kN4LgT8GoQNiJ0gBmBXvTsRdDHNtdJTnME+D0zKJ9frwnsAKm3Ei1hxE1n14FLFhT9knGle54zzgEez5T6rdzkKGhR80tsgbkqkQIpqt1L/Nm+C8u4xwCxG1MYJ5lYyMvgBMnQhHdA6/o4SeTmueGpnl+rZXJmwLRskOhq0BH0FgtTPkeO0GGyaMgsU6izzynJgKwQp/hfMeOeQN8jQOcDL8Hmd80JJIxGBPds7MU54XXwHE5uMg1IWDTALBMofwDZ3NxeVI2t6o1ebaqpzVDfMl1AI2sH72XINO2moeVkwRGXkCche908+j4tACMeeJ4B5yC/Ov8cdsDtdAJYAX+8cac8Z78q2DJopJ1i8itDRkeyXwjg/zQSzaUjZW06fKRAC3vC6isOZOgAMRs5kJuDESg4HOBeLUmh+82S/Ayl4WAOoE30I0/vapKvwAonQs9McfWC2T4Du03dkZiP+1EhZ8UWGbXvPgGz/7rhAR5ebRVdABegAlAoy1XCxLA72KHGB4eHBTvZFPRmC3Uvs0mSERKXpBrsqUSvr9/FB4FGFWCqq8tY1+9jF2rkrVC7EIlN+lK/karpwzYzophXcaYADm/2KHzXMtgAOXY2HT8eYAV+5Xvep4KjlZalTh5zJX1yM70eLVtlx9M0EBv6KMAzKGntpnXDmPdnwXY05PDJRPOJJqQvCv6JOCITUfbahmNDyK/fFuXJXotsXBT/ljSYmhI66l25uhp6HGR9wRmcSwlA+y5pAngCsgdHznANbJSiZjcN7xku2LGyubVepoHY1HRJovxD6Gfiq1qPd5q6TIgQHwKf/Kez8YnbF4UABs/fhxaHIQv7IvWQ21ul6Epn619jq1hNqwTFrjmjiVLW68X26s3i215NbI8w/8/hP7uk2dNzFaCm/6p6rx9s5lAZzHB82Sdu/eyhTAwqZVIEGPL7NrkZ1jSiOyrCvIlsBC7GP7Hh5OTkzzHGqXn2F9rfe4iU7YmfvV6M4GKRDcZUfFVldKFECJkDrcB9BbuW2/z9BAcGr6xP1rlVUW13Zc/y5x7y9hzyRfcYy1pXzvkEHbYMwF08Ie/2bOZ0EqVUKu8LaT5WBs2PSSYuboIuBeYJ+A6Powvve/vx52VHkwksEI3+LKwY+QosKHa/FS+rr2fz7UCs+NVHQ0dSBn7zy7jKz/UkyC9Q4jfU8VSFeaD5hNQ9I0n+Cu2aaJtbm1GvweZRwLJ2EOV0JNghJflHmylOV4koHiObFa1KIFTreHNTSohFlmcnQ3mDJ5TBZUIU3XT8idwcIj985OK0XF09jQ0H22/+OVP22KuV3VaTAD06tVmJZKrfSxfvWd3z7SbWyJy3t59/6795te/bh/ev/+EqyT+VPzuoku2yVcN6utC2XRboq+srbTPPlNZnM9YHiMPYgkVwfHw/io+IIF6gsjh58jCNbwYbBHcDqeg5d7eXgLPHypGcG6oBP8/+aN/1g4SLP27//CnPdm++aOFrzne8XxJUCK6qswspxnjolXprrIKqj3dUHgAo8uo1La0EbiaUP71ne6oe8aOgS2AG+Jzxibth0PJV8rZcPS91WuihFSUnyvKILgv58YQ953fZF0clnZWgJPAALTnQGaIV2AtFia+LmO+rcMlGQOGzPxkvKz30TokOHm1uVVM3t3ZiZDY4jjBU5ygwOJl4S6HxAhWOT2Ca96cmXs/xsHUYqsELcCPHluZIhG5exAwTkEEbfG7NShAPMf7/sP7PFvZGdgEdi3Et9hNCbOP2XqZymJHcDlXVSiGeygBi40KZAPs6CYA2ooQasOiJMAk2lAcWYyTGD8KX8YhL8K19WqjqjZafFaWlzJPbXrWZQlaZKw5uMtS6NpGM+NwuvqbN2+qv7QyaSL2yAbHxXjIzih/yj4A/ngLiAh4To/Pc304GuUEdC22s3bg4iL0veQ84nbyGVBfZxDFweCnMzXQ9yiK/N1339UpxAyi1rA66yCBj+0wyTF6E6zqyc94TcLidduVWgsAWOCjXlgA3JqahcXlqoDhM5l0H/LP0OCpoEdQBNy5pnga/nV5i5xGFhg4sk5OjjNOrTCRwsw9ADcAAA2rNSf8kC1HW5mRnrH1fc0fskC5Yzm6ngmSWdb+KKg8OTovYyuTVVsLh161SDQvFSMGUJumdTCM19OT59lxqjsyCyHdX385AKS9gE5SV4BCr7NkhOwSPa/WqbwAo3qFDvSWM9NWAwxqYQR8AU0ZrapmMNKhOdnzGQAsCKkEQT7T7+6HTk/nWXS8QFPuUUAyP4KH6p0XaGTMsvuXnhMZ9YyqigCgMXodyMrM6QuOHIWmACj61Q4v4SHdqwrbUPQ1tqHAZGyb+WuLoyuYIpNbzjPPFshol3N/dsCL2XK9ZBG7Jjtc4859yHm1y+R71uYA9uQ2tws9OTkZ5dBOZSAAzRjQl54LvLURFlDMPKqlKbpY7+c9967gNOOqykXu4T36Ycykx4PCmtAlQUro1oOrT1n90NUctfTk0e0p932qYOE+vM1zEwiGiG0iMjyT78X0VvXEAXXj+dxahWrlmeltl+y1oAroLcCeZzrjAr4mg8YpeMyIy2HZqhewvAwYEXAAFxIqVbXId9CyaO85mY3nkRdbDaM5O2JXSdUCgFWViB7TZ5/THQEcfezVJ7pMsuiTRAcdvq/MI3tLfi2k1XZ1FpCkikYH8Nh40Aovq9LHRgMKkd08poC3CqoKO9kw4mqtDN+N6cWnCUhl6bVSjQ5Hdp61Waq2qQR1O2lBtOpCBZGRB4keo66gekIVNryPHAi8M5X8LQEhedOTJMBCgavIUc1zjMyNBJzMtNWVANz4uMkEBbYj9yxyyb7pva/ziuJL5ma17dqhNXQPT+ilsUtOAa0A5K3dHYe19FmzGfAdGtF5cmYDIvawt0Di+2PpPT8iaWWnNgFgVSdCP89ixyS78rUCLmjGH6ytbbTpfG86gZhs+viE6pMkR2/LYxckoyTsnIPHTkYsIzehR94DyKIW7fL0OADsIvhEEOQgxtuOETI2QdNogpluI2LPojfV2RAdZYdULth647JBjK4L1Z5qw45uVuY8gRmbrdXcelsJiet8TwuV3+mdYLNXb9l5yTftOQkyJ+Zry2IL5QVTeFCBALkOre22pvJVwUjGasOA6RmbJI0VmLSOT0XM+FdX1jKf6HjuQy5qI4q8JDcsKL+MX2Z71jYW2+u3ywl65tvkIDo3ctKm53SdxC7m2sHUYoLzlTY3M2hbW8ttc3MlfB1kHn33Q/JuzenxyWF87lGBUfLS6R95TWC6tLQaHZzLHPhKyY+eCKwOiMi+hefWpizGF6FdTGYFU9ZkcQlstYOEY4giz5IZD7k/Hbwpf3oWfLa/f577au8WgB0VdpF8pb9lL0MbFZB337+PfEk62MxBh4n1vsFJc1qxggXymo/cLi6ulG+zg5iDXAU0S4vrwRP0nJ8dznOu64yfsD6/J2BPsIrOktSwsXXL9Jl+nWjpjP+vtXgZD/rAerXWzoTztwqulnl+dtLuj9E5GxxJiEiM2367bzHfOzZgNOc9CrQlm3/60y9LVo8T6MBVZJz+w4yqHuhm3bo2wbmFQVuI72MLrHcTmMznfu67tBz8m6DTuidJXn+PjcMV19WS+3f+9h+GN/nO3UXkfaj9+MvP2quttYwLhult4pLolqKUzc57ZXMT/NFFuvDD98FrHz8Wpt/d3Y4Pv+zdRpEHbWuLS5/WqGUO1ittJvBZqo4cyyZ0e4w2B6AK9vgb6xH5K8FWRhB+hP42pCncdVYbJBwcJsCOrrMp9gxYXlluf/zf/NN2dXvVfvf9b6rgMfL//v/8868rCxHFYXCdKG59jDUNFv36V2AAZAsUnCAP9GufMUlRMyfHKHMoftcWQBAwujKtcZKCFQCBUTk7Py7FnEsA8pLxNEjvVd9xXu7j9XF7JwK5l2j8sCJ/5+4sLq9UWYxxcvYG0O/7jBIAwhACrhxiLVDM3DgWgZP+YQ7QT68iTEU4bENL4RJ9D+u1t0uG1oNr0yoF1WfqxYARaNluAcjE9ES1oWEkh2aewKXPrM0AeI1rc+tVOXeGFUgwbkFMRf25vmeSE91njAvF9NEKOmptUz5X6Xq1uRlBnAtdMs8IAMfsDJTFPGc5nwNSc1Fui+ysazJOp24DX3ZxIlycysysE4ZnaleTt5+9aitLS816nPPT09A5DiPGN18uQWMg5ubxfaEyoBitLU9rXV8r9FBg4vxcqZTT6Yv58aoDszhMjiI0tbjPImzCuLG+UVuGAyAMvIoRg6+SwOnjJ2MlC1wVh7zH2R2dHCfwScRPRoDlgCwGD1Cx5qwC6ozdAm1VgZsbwL4DKbsXyczIbuJF9dPHcFK86alBmwptXlpaPGtIHXgYv7QwdDBdJ0bLVEfRABbnIpBFbRvGmG/U5w8BCv7wvsCTENUuO6G1Ni+L6umGwEcP8GJoXP2qDApQG56rVKA1MCUoFQQJerSoMC4Wkupx135BLsvwxAA5yR3Ysnf+sF1NJjhcbVUAQwBavgxY44ndtl52AZIJch/AguB7TzCKJgBHVR4DFA15EKdoTBbAH0duZNI5dSdea/kBFNFdWwP6FdhMMIq3dFQgeR8aPA/ThYCBAIWJjC2sDJ1lnq+rWgDYVRtCnm9xvJ5lALPLlipkHET0G4C11bKWFN/JLyVDQGkdohhjTzRC1shFHGvGhldArYwdfkrUACH4WpnayB55ImfsnIBXlbASQqGnObFzPgNwXCsLLZnBZriH9iS9yPr72bO+ux8HYQGos5fsEGTHOvPW+oO+eeVaYK/O/UggIqIw79odLbRCy6pC5l4W11fbSwJPbYBaVUU3nKg5c4AFeMNPTljrle2Nnx8DVLVIaMeIrRPk2MlHkDAeHfK3bcGHQy8yYtctILZ2/bw6z72tz3SS91WNF0/YAw/tLRsCmtFyUhIuwB39kUEHfAXzHKKAfGF+KfKHn0Ai4RbQCBK00gH6wyX/dI1es49aV2UEZfEF6ksBznZyY/foFhs30IKWOeENWgA9y/EfbDtHqcWO3fB9PoL8VRuY4DZyBFSFFDU/5/Dc5vn3kU2Jg5eDEOm1lg/rOMkXgE0f0IZOCGeHHVipzTIgy5yttSFzfWx9N0/tKc616TsZ6suXKBKQ0kVgUHaTPREsqbIJSFQVu/7bDWxi9LG9jV1fXZmPiCXQOz5pE5FjoIn8CJjnQqfNza0CBHRF8uDxHn2G60w79iSmLrSN/EcWTk4v23EAt0X+hmMTjamAKJX/OmBZBTA+Hl6QhNNGLOkneMFryczjo/3yn+ZBP3qiKoFBmFKn+UeH+Cm80dJDJ2ziIqsvEy0xpuoiaamlyFq+CuQn2bxgh+imrgtb65IfVUfdG7ZpHsS3nQQ/uMZ5e/TFmko24jmv8wQHJwmSjM14LuO7bAfPvggmrF0THAHSqjGu4QvpP1NTO24GR7DfK9q8+bXYOXYE/a/zr9bg2pwjtmpiPMFBnuHMOxsi2FXU2jmbY5wcn1a3A5w0mZvPJhBR7YzhLlnVXlYbQEQfJAr8fpxnbG28Cl/nIhsSiLl39JytkThhM9Y2ginGc+1ZQOj9QWgZRoZuqiW2WZ4drEUGYYjwvEW249vZNr7i6vai3QVv1O5Zoe1N3ncmyuHhfruLjbLRz49+9KPQSmvofPlr8sCOnZ4dB2/E7k/Z8ClA+81qrhkt+bdhg8NvlxJ86UwYGlH1jQIZWXgBF8Ada2ub5assiL+8eioMc3V5GiC9UzSFo1QfJV57K33mHOxCHvmocKnNz9rIaaZaNdkdfFUVef/OMgeJM4HjTHR+Jvrdar3Z9vZu+/AB9hTYhP/PCcJiK+EbsqSjBTbWEWJr99v4usvMl+3VDlwdM/EyfVMZPs+GAuORD+uEg9kC/M0PTWEp9gwmYadgPIEgn2AzpohpAtetBAHLGdthxr0d+yDxT0bZmcn2+eef13d397ZDj4sEKevtyx9/0V5/tlXBwvnhQfTuvK1vhgdToUl84mzs2/MQvBP/enkYuTsK3abaT776UWRaJeo+Y5xsX/z4bfvJz74K3p3MWC/beejuHDVbZMPUdFhF9jQYjx7zqcbHoEqaL0Yv+DZ6UocqzyU4Dy55/fZ1zZ0di1mvSmYF9ZHf89OTth+sd35yHhmOD4C/8lx2eWF2ue1+PK61gHaOZEv3tg8iM2xlr3C9ev2q/fSrn1dL4D/4e/9l+/6H79p//E//R2Qudu+/+xf/8GvgswQ6QMuWwRbEFdiLsDMyX375o7YeoPrSmgaoMzy10LMCn0/OOveoVqEMUMYLQAIQ1vJdRr1nhoE32+71Pt6HDBK4lc0kpAggypc1YeTdm6PnxCNRUaSzKNJMxmKx1lG+99RevdrKd0CcOC3gK/f3cxXGYMB5GKP1CIAhrDY56CA+1wRY9sXeMxG8RPen+sdth71UY5Dd9Pxah5Pxy/oYh88414VEyewhsMfoLyfgcC8/nJ41Qv7u1ZIY9NxjJworY8E4EFTOEtNfdo7jMDDOpgUicUDEeARpWog4Xc5OVUaUT6GAVMAK4zP8fMecBhFqAZ0sP5BijIsVxCoZ2uAAeKG0MsIMRgUgqi2hHcVjhvhAzyMjnJbna0WqTCW641fTnhewm+sExZwwJZb58MMJMdRVlYihN8+SlzxX8FIGOzw1F/KFP4wL8OoajrHLGFq9gFFrhuJMMsKebegZfjtTAaIqIs4gspBVub6fBt1li6EgKwwsBQWeqwfZupPc19qtsYA2C31tVQ6MMOjAEbnlWLUOWq/E+czMRLnDe7Q2R5lS860WlIy5ArnMoWfKlZQTiOQZZAgYM/5QLTQAwrVZXBZYRwf0B6aAFwFMzTVzQj8BdPGftc6VtRYmTBO8kCF78gvy6KMxVdtQ6ECmVAR6sqIH0uXI8zlwRh/JpIwooyI7DbCRN616st/0WNVEde1lPRyBIdvGTyatUak2srxvVzSZ0Cr553kqywKfCqpiNyqgiOMlsz0IUP72dwIUgCy2QhvFy7hk456fM4fwUWuNz+tgzZKNfDeDKTnLcwQKnq8lgp2RoBAs2EXRoIF2FQg0kwB6CWT8VLtd5lpV1MwfDQSJKpKCc9ejl6sBd98zfvMChizwr0RRXhW4hO6uq7NT2I78TSbZPvPwfbypDVNyU9eSd8GEc3aMvaoseYbvqZqSDe0D1PHFZpCP/pwEsEBM5I9ttb6gdqDMd7TyAAySAQtzNo2xaJh+AXvorH0v4wptHRapzeQq9sN7LIvnGAP6mF9VHDNOWU0gexA5KRB4cZ1ns/MBDxmPFjf2xncHWo+jW6ridt/DYK1OzuhJiBPbJQt/VZVU4FCGW/KE7lRFMNf7ey5y7gfvqhJS8iMw9q7KrZbTvi1zjd8E8D3vV7U99hLQFJjiDSdrTMajRZHD1cJIrkUj9NW/gh666lnoLNh9irzyNealyjYzKfs8HJnrO/9VoBJ+sAt9vVT0Js8TiPMxdJLMkDc+FPBj69hlySGgVJKEXtFbYDz/C9Afa+sBmLL0WpJ2PnyIDdDKaPtfFR6+no5G9jIfFYfr64faSekgPq4f5v2p2ppBRewCfMP78GE0c1HxwT8tiwQeuGYXjFdVoFpCM3+yv78fIBI5AmDpA77YZZOPqLVGMtYCoNhptpXf8hn7ch35tttl2YrbfPA42l6/+aL8oHWaOiPmFmcDqgJUI5tsK956XQRUa++hZ7PRP0mV4dgUSQvXVQAXvTiL73dm0+HxWTuLT6sd/DJ3yTlst3EKEeEfSr8/YQwDJTNVVcwV2ijJHx4AgXxZ1wu+4LrWZsIO5M62zlr7PMeapFCnWvWsfVbxrdbr6DFZGMozJfW67bbI3blu8QGhox3i4IpaZ4ZfodXFxVm+H+wScEwYnLFCPq2T0sLkc77FobkxA+XD2MDhIa1eI5Gr8EIy5Pki84tdyX/n1YJ7GrqOVlIcBoSHpgehawKL2gAqemdB/fv3AdzhZ52NGPrYRSv/JHCxIN2aZ7ZTJ9Fw7Rw2Fx7acY38ahmEPbUmsVe2eBYE8/mSg+yEw4rvEqBXssJmF6GdpJiDU/navrZntoA1fwTnoJcOHevBj4MXt7c/lo8XnOAB/69Kwr+XLxvRsQTEH5d82h5aN4utmAuUB38KJumeqogqytx85HF2MvzSwnccPgro6WRkqOwx/EA2E6CEjpJgNpZCG/OT/Do61inUjyGxXXklXuIrbMYEK/zkqx/X1t4C+++/+659eP8xzxIwSDCPJYiyw5vjZdixifb27Wb7w1/8tG29Wo3PCH9t6hGMsLgo8T3VNtZis0Kjalm81ZkjiHpuC4t4utxmF/qmIk/hoQrd1ps30dHp9ptf/7796i9/277//kPocR7x4msmE6yftG9++321+NWam2CBleW1trX1OgHvWgXvjmR5/eZ1W1pZKv9A3nU7fIjc2DBmkMDbJlUTsFkFjtZw37TvvnlXSXNrpi7Pb9vjXb53dpPfBeKxHeH7YCY4PTZEFRqOoAMSO2wn2/P3/87/s33c3W7/4f/8j5lz9Orzrz7/mgHTsqVcjIn2QrdTFwbJePXsxliV8DhlwUA5atnsT4b65YdxwPQOBrqjLYCUAciGcjhaGLTR+J3R4pcMcD7C7sf1onORLNBR53ZEsBmDkxjz6i9MxFwtefn+4tJirnWd9imlwtkIMYceI17AVEClkhSDFAfStzXsZwMBSIIfYNwOHEd1MNVlBGSxDLV7CqTMUbalA9ee2Wf8ltdiZCLh1pIIdDwXAGSIZMgZJ88TKFTgwDHEiFGAWq+Te2nB6uCnV93seAGwMIAWeFX7VhwUA8dDuqpnwvVGKo/bbcROOPsxdoIzGQeVkgDJRO2U3tkD9tTXR81YUn6ZYIEPWnKkrgfqtBUp5+NfOYoYGu1W/pW9skDf/LRE1E5CEdbJ8TldM7UonQGLeIRftkp9LKdd4CJvaoeA9tBRJtwuN0D7bAyBhZQcY52NEmdd+7YHIGcUZaRkg54ye47Sf4CB1iE7zyiJChTr5PzQK2SJEgAWArunthKFl42zTqjay9CIVcr9OJZeuToOjfrGDTNxqOOREXQBKgUNmUouj9zHMAt2VD+sI1IVcd4NvRBwGh++6A9mTGWXQsoKAp2YbgvvAviZDQPcKx0BBkPKuMCxdig96zJGeNCrMVHTKHc3mjKdFnWiCcXmhPGkeBawQV7IgHZA4yEDVcmIHI+GD7UbXe6Dfrm4jDVD5CGMcc+a955oLZ8ykOggQ22DB0EC3Yw4lr4DK2wEGVdlFPwACwC8JIlM/EzkBSDoG5YkIM2zPYe83QcU4Kf5CC7ZC8EI4KHtRnBTWz2PBWBERgW/Ue/wJYFOeCngeQ6wFsAC1doYyS75AyYsEtaWK5MkuGATrMUA3DhpNoeM+pGV4qjMjWwYBz7VG6GRfwDWOjwy9MRr8qntS1DKDuBb3zJcm0jsa+bLKfXgKU6cV8w1soUCU/LBFgra2QU2Q9aSjEryuJ6tIPcSD92WBhxmLhx1HTKXa9lwNHS95FUur/uSY7aZzRCA1PkLj/Ql8pFnz87H6cT5k2UBPfAr2JTIMgEbaNyHFqcV1Ku0FKky7h6Amz9bij79nCUBRWgR/tqcRatKLindsXOPAwHxEFhhd+wsFEFrUeHO6+gM2gu6VUFOEvhrkaNL1bKZuZJd88KP+dm5WqjbM97mK6GSQD0057PQQeDnuWyQdrWSo8zBOHuPfuw9OYi8sbWqruzhqPnnIWRF9YLu6k13bADQuxYnq6VP5UvggpksS285Vh2MvZswjmh85iyIlQCzHqbv5NgDHyBNpZOvkMwoval79IQLJ89PCZC7X7Q2t8snGZKkXF+zvtIcAmxVGRIE2FSBbOM9GbBO6sPH3QIjAtGTU5tL2GL6NsC1t3Wii5cqKt4Lep5ybe0QGp9KFw2aP1NNzPAy5+he6KMtx9o6wZ8z14xTa5C52JWU7GoPElDIjL8ELHwOIErGnbcm6USEnVaf2baNja08UnvZZcYYexFhoU98EFtMruy2pcoyGT1cCWCzsQNbZw2Q1ss6YDp+SVX0DIDO82IhSubsGkUXag1PZiM5pv2M3LAPZY+MiZxnjCp/YUPZY0Eu+Qdi/ct+qIAcnwYcogw7F9261Zp7px05MpYA5CxgV+CDn/yOYCjClu8IrnwvtgMW+BRYkjd4zEvLK1nTFXJ4tF/3g90A21AyNjgBSy4hp1qh2DuAkk3P9HNfa9W6j7R2SFJae9XTc19QH1HtwWB8IltT8loyGXAaAK7TZjA3l/cfEyScRy4ey26QXefP8VErqzYlIZ98/Vn4fpzvj9WW2IJWGJOdlHTf/vCx7W7vBUfYEdZnNiboVRyBxuzcfK6drJZ3vk6gWdWOTJIOsQGqXvS5ulJCE5hPwCfQ1t0hwUd3zQ9tJdQdAKqaxNbEgoYeT+0wOPDkRFU3gVNoZAMlssC268qBOasaGX6M1s6L8VsjsRnh3eKyCqgEH7/QEyBkS4WnaBcez0veRw6M7yp0r6A2fhPmIxsCH3K19Xqj/ehHn7XNzfXIyFACjL0EmO8rIIM1uy/qiRR+VYXduj67mS0uBYc+XmVM4cfNZRh+nzFrXYvcZu7Owbm+vch7tnjX+TSToCRjH0y0y1tBlTXy/dganSZneeZvfv1d++5bQc9lAsr41wf+Otje74/BLPHPNp5aX38VuzcV3HDTjo/PMlcFije5z8QnWYudDm8/JhDd3w3mvoje3ycwbhI8d5Gns8zR9vLn7eO73Xawe5zgJ/y4DN5N0HN8eFYYGo6HsXV2wY2WmdR7+Z3M7u/tlr/8r/5f/1Xb3t1p/+5//99Ck/iYpc2Vr8uJJoK2849+OpUJu4bZms7N7X7BGAtUGFiOh0OQrakdhmI8KuCJ9aOs1acdhrws1BTVcUalEPmXI+pZg77In+MEGl690g5G+SmXA+qiNPmbU3UPu/CUIoYZovo5pfQYPvfTWqPdjEMGZDhIrQmMlUyp5xASz+852gBAxibGQwBg9wuHtF5e9DYGoI/yGVceEANnP/WjgPO1UhYgvjKEiZCBPbQBDmWBrSeo6kQeKFNImba3d8KEvaIBJmlds6iM8RBkynyI5s1BCwGwA9QsLiQAy/OtY0EHdPNsYMZc0V8LAUf68b1sxnU5dC8GeHZxslqRrqO4tUgvAiVjrIrCoHrm5tZaAeqF4vtCDOegQJeMLbitgqGcbl2VsyHswGEcdhDTiqLsHhcUGiR4ODmOUFo8C3jZRcrOT7IXKj4BQXGk5KQA31TA1L2KzWN4PSgAoc+UDFprpk1KRUDGQ2BpowTARXDnns6BMWYL9OwKg596rznq29vnFv3Os3pQMTeYDL3nM9+ZjDdjy9w5Ua8QuAAnOZCdFoBPxTA9CQrCQy02KmGeC0y7ZwFvgU9e1ppwblVVqIAugTJHE4Dg9mTQnIVtFiwTKcBc9Q4Y0ko0MsKoWmw5FsMZ8LIQMNycO3SeZ9qcAEiRFAC6YlwGHFMAfOSkpLmcUw/SVEqr3z7Pzts1dkkL2y+7CT4AhCXb+bEoG93ySb4j+BotvassfuYpYDAHwQ5nRP8LpEQ+6WVlOOMQQsXQProf8P2UQIH7lsGfr/YUWx733auqspn/6trQ3nUW1husuRp3Ze2B7ci53/smClrN+i5bwD4QcREjKYMLwNWBm7lGxcc9qkqScXE2QKzESSVpwi73yKzyTIPMyDNHgRq9UIEzfxcKkivAqwrVc8aQZ+dfIMC4/C7B4kaV0YuD7tl3gbUs8WPkJN/99Dl7wCayW75TAQJdDfA23pcWIvJtrGQaYGO/BPbWUVXGMbRT8ZFJFqCMRVfxlKMFCoCnqkzleWSWPArKBSXVAhOH1QIi7DwW5oWug9It/NTqpMKjBUfVdKhanuKQVF4kMzKuakkJbbR02WwCn4AQu1J5JhpXa13GJma0XkOmFnDOcMo+uQ4oCGty7V0FPn1dxHAFp+cZC9uDNpd4nJtqVdL/LSGCxoLnasnNfR4yXoGHwAB4x1f8KNkMf7uNlo2XHe5yhAcCHnbA2jc6ieeSTewffrG7WrN0EJjTXPRvJjaH75A1VWGTsb6w/gI4zP3qu56buUTdMtceGJItemqbZL5oaUF2nu3CGxWJ8CD3AmpsEiNzjZgSL/hJjnzPTVUD/G4efJXzXVaX9e/HvscvaHWzXbP1mJlSPRcP9vcP2/5BAGh0kt5cXArg2U5t26dFP3LiVQuBMw/rMi0YtyOWJBobh28q++RR8s5aEQGs3QFhd+OvNuTQcKbshuDAuiiLvnuFptZbTM5Er1hHdgwItmlBbBXz8JwA+DYY4S48ie3b399pux8/1C6druFnZ2bmQ6OxBFy37fxEcu4q9BhvG+tLRRO7YDkU8+ZOFZqs3iXIi+00Broe4DQeXgLXEigqMuZbbW7RBXM1VnOic2Wz6XjslW3B+Z+SpXwu0YtP/lXpQm+BmQBf62AkoU1MxaaOJwjSFZHxsAW6Bfg3Z63pwLDOw30tNeht+MYhYdg7F6piGx1hww8O9yrYtI7TeU02IFC5GR6x/iXyl7FenfMLdFZCmF0TCE8FbEvGwgNsjCSAaQh8Bel4H7mIfqn22G3LplMCUtuWs30qhgLi0YDcGfIULp5d2Cb6LtjGOmfn92jP4z9P8ty78l+SB7UuS9CQefEL2x+3M05V1lLLjNu5S2SUPg6HbtNxR1OVBCH35K4nPuJ3cj0/5T6XV+ehu53+VPWDjRJUSCDBWgLD5YB7ssQPasuSBLOBh00gHCXiHLKLjEPQc5tgUbJienou+MGalKWqrsxGroy92nJtllM7yz3VUoQ3b14XjpLsYlMEWZ6vxQzO6Wd4TUSXDiqZo7JBP1SNaz1OcJDKvuBWu9rGxlqCsOP2ze9+m6Dnh/LxT+GfdXpsmcrP/r72/6vIBjsSrDH8GDm/bnt778v2jIVAQ6GZXdokm8kxvdAGv7m53KYTxGlllHBukYHdw93io+SLDWcEPQcJNrZ3DqN7V7kPQXGGTmQnPkLHy+qKo2YcWm/d4XD77rv37S//4tft22/eFXaynfn2ToKYxBP8KJ++m8DkLPc73rtoR7untbnE7s5eXgftcD+YM5j8KnqtuuMQWGvEHcwKe40lqCdHlVwyztgLCRE65N/jPEegCIf+4z/6x203v//v/8d/zPXh3U//8Gdfy6hhQm0LGeMMGB+fnFSGyALFKg2XgD1XqR1wUZVIOBDGai+RFQiUYV3zw8n4LWoWgdRm1Uu31fue6/xQEAGCFwEE4Bk/f1d5N+MQ+GxtbpWQVstGhIgQc76qDsrdzukBQigoIiplCpAqq1/Ko12sZ84EKjJElZUO852nwjHKAJjDzfVDhKqfj8ABKc1xspSJE7aeQ0ahWhhi6JVilVkJC2N9nMBIAMIJcboCsupVrGpJBGd3v7IKGKUyVeezBNACOgQdmCDg5qtFxrir/eW2t7EB5+5b/YwHO/msOwjPrmdlzsALR8oYqO4oXdrUoBZS5iO95NqW2GnBB6UEHDYyV6C/qlbhO2dnIwY8xD8LRfVJkw1gjVwAD0CfLOTlqYAxxuICyNYWdZ3PBTsCoL6DG2Mgo7qXyPvDx3cxstZCAZgxvpkHOlcLQ4wK4IHXtXgxBrfGE9kAroE4937l7KC8p6Whgqs4qocAojoR3I4yAccyLfcPF/kW+U2wF3DJQE7lOda7qOIBk8rzspMysFoC5QEvbqwhs6amt0jYelTbjWtmpshtX0dCpOPKImO2U+6AoJfX44TDG7oDPOGvccvMCK7JdI09BvTxKYoNLIcmAvu7x7tyfhydu5Px6numYzFq+qQd0EUmZRPpm2cYB6CoJYg8eE+lB3ACFmVCrHWjh+ZubDImgj00lN0m42QY7+mhZAY6M/p4QQYu4iQEPF59QbbNCjju3CM6RR5rbVDkcSZyAvzQBQeOijfoujEINDiP2dCZA6gKY2RH1hU4BkTs+KXChu+ckKDTM1WcZSsFCHTdTz6tZ5FjO3wtRM+0W9FnjpJuA3gV3GZcrBGqqWKwT+TVT4H33DTTCI96mxtgpxqg+lbf8nn+Za+AZ0E+sKnHnqyRb/alB8tanXrWuDJ0mUPZmdAkTIojicTld/Lqb5UFMpKvhVZGxL7KTbNrvbWLHuKroOA6NkLwgee1zXPuUX3mQFie6bl+N34Z1HwcPZGJnAivbQ1vbcNVZfztLGfLXuum9E+fR5YuvJ8xGgveaWeWmEEKNCOn1lLQb7Q2bkEAfdNGIjhyb2MvXY1tQ0fBGv7LdKrgaxepimH8Qa9mAbyqi5INz+WI11Ydmo0oWvT6+i1yyE65h8DJDl8qZwZCT4ufsQJhRfgCgPYqGeCDLuhVviV0FyDhF9nHB0EP2qL/wuxC3V8PPf/htg7O1Ronw8iGFT0C5ksvPE/gkHuRYz5T8Afw2LhhEDvKZgPXfI1sJSAM/FgLMBYZUtG3lgCtQ4I8I7JMVv1NJmI3yJmT9KenntvV2WEAw3HR3kGjgtoQrJ0E1O3tHsYuhf8B4f1sN8GnpAoAq2pio4XoO980Ox+exaZHLqx7ETRKrAkGBKjPAUpPARj4KYvvgGD2T+WJjrn+NL7PLm5oz9dMz8U2ZxIV6MVOe24FmvE5FZgGqLJnaKwyMfQ0HhsSfFAtgtdt58N2JWLJB9tFRjxnfrDY5vI62D8onZyaZMemcl/n1p3GN++XPlpPqKYkYTJMH2Pbq0pc9tp6RC33PflizNWxIgDMcx4zPvpH9rQ9TgZgzs33Vk6yJ+nih62WLHOfSlTmHnRVkCJompmxiZRq5EhbXV9tW69fVWKIXsEStmDWQgUTzOUF9IsG+FE4QFWwkpDBJHSifEroMRc9kO3XLv2Y+09NsUvdDp+p6iX4kS23G+og/stLF4eKDnwk+ao6KXAn62VPIhNM62h4V4v58571PXy99jbBD387MjZZ12uvo17V3pvABu1rTVr4apcyC9rp7EGCb+OqiIU5DQ/oqJ3X2CJyaW2I9cWlPxF+SZirYDTJ5QysOij4bi2EdlBzZMj5hQPbdbFI3Ee3Ykvo+9qa7ZGD1xJ0aIfnt/lKOvrxw27kGYi/rcNX9/eP8x0J9R682jXv9au3wS86ixIMC5zDA1hD26Dt6QXUUYgEn/NVMLBZlPm6hk+XJJkZRD+jo2yYRMnHDx9r3ovR+831jfbF55+3n/z0x+2zt6+i/yulL70l9Lj99je/ae++/yFypg1wMXKv26HbfH6R/5IMi5rHH1oHS7f7TnqePR+dnApv6Stf9frtm7a6sdpmEoSSZ4Hfb373+6qESqIdndq+Wluls6ccSn1VFZd373YrEIGtogl5TuZ+Zz2sddkwxVU7ilz8xV/+uv3f//nPqwVOpVPLmg0H3mu9DU744osflQ/++H67Hewct/OjyHSesR+MbAMblSRrmKur7JodVVVDOwnZviHE9d15gjNtet2/PoQWsDPboOLHNtY65mD1f/wP/3Htmvrnv/qr3CNzXllb+NpAjzOps5M4p3PG/iEG8qTtfMwgTs8jkGMRKAvLrvNQWafHMO1DCGhrT9k6ChljESDXDXF3hgyz9hUZMcrlfWU+fwu2ZMgo0cnZaSkUw3uSgAZwdtgaZ8FBcgJbW5sRhNEQcj/XKvuK6u5jBI/aft6TIbOQUQSsxUHrAhBngHWiexyY1ojFCORahGpjcz0BR4B7AKYWK5+dnjkYzXapWkms+3gqgyDI0Sr0/1+9Ajxkvpdl7ILlnvO8oRgU/chjwwFKozGWlDQR6/115jE0nuAgARtjEayzvJioPkAhohjdjyMZjoF5vo8BdsK3sxNO2sft3RiS21y7Uspk60bl1KXV+QDQsXZ8epCXk4CVDZ/LUbU8Z3x8EKWeSBAlc5WHRblOT64yB1G3jSYsKO59upRChmln91373e9/lYD3oIwRI4yHP3z/fSke4XLyPEdq8aZFrRVoxODvfvzY9rb3ip+VzWb5IhcTDl9NACZrwhloEbx/sK7rIs8eDd2XirYCObJFYFQUHLRFqV+y65yIytMgTmTdNtpLi+1J0BejmpuF1sO1IcBElAGvhxMYDA3JvOo3tosQIByZy7VnedZ97jlYWKqDE1VGrHGQ1e5r04biyPTmj2U4uXeYEdbE+caIZYh3V1Gyp9GA6hj7yFfthhUaA2chZZ4Z4PsYXbnWUnFZwSPDwlmRG61FsqgApxPNM9g2btvIyJ+FttcxyPuHp6HJfZzecudlnAEgNzwWWb6nh05THm7ry+uZv35ki7Rv213G7vsTsqgDwflYxjQSQznd5hdncv8AzIz1gRM1+ciFzEhlDjOOhRjHQQyLwz5vou/D0WnfX16wmFggD9QDQhft6i4OJyAv7r49jU602+cAqwvnO0TX9N4G5GVAkc0EANp58tJ6Z7vJmYnQLr7uKYDoKXo+HID2UO0EAesjcb6T8+FRdGh6KfNJAP8QvYpOPUfe2BsvbTLWSwiE2SSAQja5ZYwTcTgC3fE4Xv39eBWr06YD8DLVjCmhZRVFgOLwI7oL8DCexsik125eGRuANx7HdXl71s4CKIfC73mnvwfgjT7etJu8NxEHsxSnFjFrk3EuwAMwWOva8tyYxPA5PI79Q39txXeRw9uAAXIc0UzgF/kJv5yhM5wvDEsW5IO56MO4cWXOCWFi0wLc7oeaE8GvLgRO0bVnrS2SHcYu2yaoYjuteQntKmDM92PHBdccJDkdGw34DjiiOyqvlfl9CBjIPbWttOGJyMxku8nfl9cASubCnGQs9IS+AN0SKBIY1b4ZR++lbcO6DyB+MnaO7mVwJbfdL2gF62eBZXq5NgzJLABydieSGZlrsRFaGASeHF++Hxso8B8eu4s9geczt/DBDp4SY+5VrYrhu7CUMRXsqMpal1Jny0T/AAaVLQEj33YS2yWJAJBrc7bOkvsgE90eCuxD+/DnJNfballFFx9lb2dnAmryeSxWBWFA73U+ryRS6H56Glsc3l3Et56Fbw+1Ns16m5F2GH/3HFmdHIxFnW9a3GobyvwShsRWqOADX6MBxOxt7NXdZZ4ncFApjvzEzg1mngPMcs8w6Dr2Eq9lqR8frc24a4cHDoAECFTp+GYV/qXIW/xBbM1jxsueSf5o/RnMBORGf89PbdwS2yL4i63n4wHr9nQeGY/vXBq0z99stY346OkwjJ+w69h15OeHjwexE7Hf8X/78T/HCaYlj2bnlgOil0JcFRE7rXW+9WrbUwHyydHoau4huy2pORX7dZnPz2Ln7mN/RyfmAtDmYgd6dXN6kMBvYbjNzD+35ZXpYIb4lvDFWtar28vKaI9Gzm1SoEoxNBzbODnbLs/sNhofnflX5TW+oZB+5MWvQLf2MBvj9HYvZ5MkEI2Mj0/GquRle/zLvH98ftFOdX3EflL5wfxcdMIYbjLXHgzoCLAGIjMKrWOTw5/j/fO2u72TgPWieGAA2q4lyFQVqnWnAiCtvD2hK/DqGETr1Fhk7jIyokuj/+425T/zS1VqE9Q71V6lKea6WtVUl2XHtatNhhbDsb3DkYfaCCmvsfhmyUFJOAqrCnumVTC2kc0k4+8D3m1Nj+f+1lGi9Z0NAnZtGjAcGzKR4KEOMA0msOHPqQXsoXFPXIXO0RMt6nyiCtyEZEzGcHhyHZ6pqq7mGru/9UCDTVMFUMkSsJyfHydQmmivX6/WDnZT05GR6KqEleUCmxsbCX6Wg19mowdnGacE7XXb/hj8uHNauPfhLjo8sZYg5Mu2vL4VbHqW7w/a2zc/bbPTi+0iweNpfPMdvxOjUjIR/6klbCKB9uarxfb6zVJoZiv38Ih9Gg9eiI1S/WJ3LUn44YcPVQ2hg29fvUmgs5UxhgfxK88jwd4J0nf2d9rHjzvtu++3Y59UnoLoxpdjZ9dD28lgyYyD3t5Glp9gPuuEJ7pvjz6M2dwosjY9PR/ZX0pQO5XA2IZiE3XmDnxwG/8toXEXLGD3wpvgoJjDzEkQar3jSu4feYq630SH7eZoa26JCsUNVdur2Ezr9bX5nh2ftIO9g7a9f5DA9izX9ESbav5z7PMcex+jvRi7NB7/fr4XPoT2NyeZx2XuqeocuaZ/dsuToHsom5A55T+7u9aa8OiFZMz1fYL/4D3BoWKHNtG1lbWyt6rVChM2NqAv//C//qO2s7Pb/u2/+7N2d5lg9M0XW18TBHvK30e+LVy04Fd2SgkrrKuMoBavyi5k8MCyvt6HGEYVFy1HKiYAqwpPLSAPwImLKxAhSyEDLBPL8QmAtNHI1gh46imJQrUxVGtBNEFgpF8YeDTZ3DLR/1zb3NzsxiuK5xkAp8ywMcuIq6BY46OUJ4sic1HVpjBZsKTlhVEQTVvotWqNToCLViyRoMXTzvRRNpwGmiLBsgOqNoKByt7nOb2iJNsyFZAh+9FP5aVoMhzK7QRC4Ghhuu84KJRwitqr+pV5WwcjEIGu68yiBGZ6eVWPnN0CLVkcZlclWVF0lMFkUFXHROUnJ7bQlDFczB1lumxprdJzFoFIIJkxuFdld+JYBFX6pOECmVptGdbraMWTybEzloyLTLVqByPnjADPVV4dxIDhLWFXZs1Ny1EIjHp7jiBCFpIAaiEIOMuzGCxtInbR0yO7trYeUONsHrubzEc2bH5wWUAEk9BWn7SMxvxcnPFgLs5apj7OGgAIXyxok6HyI2tKNm00oRqmT1y+SgUHoKld3iLfsjzaD2QCKEWmVwDFe/hq73sbZyiVa+fTDlK90NoCYmwEalp4enY3Di5Aq7J0AWhjo5AhEBcZDQ20THoGMIT+5OxlwwyBtezE7UOv2DH+FhBq51JGdg/79O8fJriNgbX1s+qgRIMzqgSY1hEJGmXDLHK3Y5HKZpV+P0UJsp5k34JmegAQWuBON9GOPhokoG3nN863qhlAf4II4Jb8qfQYs7H3qq7Ki/MrBCHmICCMsyTZ0TuOmu7QY/vu1/bd0UvtB1o1ok41B9fhMzHqALUbbXzhUAVP9Ftl02JPdO18DPD3HOAgjtwBeAt6lWWVA0zuolv0OA8tgGBL32ppig4znreZTyxTs5A7jyr5A3RkHrXx4tlDaO0ZBquaIZAdRE6ADLYK6YxfBdeul9oBX+7BdpoTHVX9k8li8wRFSGSdmXv0v2MnA1rpoUoNW4ZGKh0ToYUsGRkWNF/EntER9B+PvAyH5qoXHXRKQvUMWLVChf7oBFCWbY18V/U4Nk8wq0XM4tRQPfcbieNk4/J5vsuuClhUjt1T1OPE7uq314aFptFpMoRGxdPQqSo40bFqM4wsjoRWni9BoyLj+zJzqoj9evIV4BT7xi5qzbDWjS6rMpo3erJTTgUHdGt753ANf/DTXMkkOmQKNe6nzIlO9d2yzktOORLVJ+0sKuG2PlfVVa3Uf66VR4AE7HOm5AI/VTpnMl4VArwRBNAPwarEERbWmsMEycbreWSMbvU1ciravscPseESQvFx0QXnbQ0CRFRNLi5OQsuMM/LrQNbh6J31aSriAgP+ZW1tpa2vr5TNWV5ejA/WhmOheABmxk62qkIWfsqQ+1eroU0MVHv6wZy3bTl+pfxwZcUTPAQI40/tyJc5XERnbeQijSDIswveeeYhMfTmzXp7/coObKrzAa35L2zM97tduEyAsx0QpHo4nHsBtYJNa3RVvsmMrg/8Q2u0Ye8qWRA7ouWIjyevY6GxdahlrzK/zvO7ShKg7UJsogXdUwH2aGFdIVDmvL+XrZd9F0jtCVxgynclBC9Cc3JJVsL30FjSNJeXPFULbCaG9pKk/UyR28iEVs3YxwSk5oKeKg++6hDhaocmodE19ppOsInxkpkDmlsTdpfnn7adj7vlc9BZUE5fQyImp4J47Y6qo5Ix/Bn7DuNIJKpuaDeszWUSHEmgste1OD7yzI/6MUZ6J8Hbq6Uq6QGPBSIBTK2Y+NETjl3/+Q3+QZdJZDHv1XqtYAuBkhYotNQWhld0CFaj9wbvfqoAEpcSjNb6SUrbpdd3tN77nNyE+qUvsCYfpkpYZ3zlX90qRxLzwTHWCWl/s9X03XVwSe4t4YGuP/+DL9uryKX2Yl0DqoSqOratt7kTPMbuRKRC59iQ+HKbFlj7dBVeOCdoMFjI+CcrWIYxbCWuGqQ6c52gD57UDn57F5/mdRv5uTqt9TFvEsBITuzu77aDg4OySwuLdlDcjK1NABz+7e7uR6cuIs/LCdLets3gT7hBW7sk9u+//U0ln++i++FGZOa5sCQbwNcICCQfHFVBD7Q5V6vcjM3DznOf22DI3s4Xocs3hhJQ2fl3us3P8H+PbT9Y1dlatub+JgHYX/zlb0MD1ckEm7meD15eWo2fm8uYJbHiK0ITbczkxBKS3jY91dZW19vnn31e2EbQU7sThm9ssICdPVRherW10f7wD39e1zKqO9u77TRxx0SCbeda1aYxkfuIWGGMlw3S/FdYI3KrhV28QPdUpK2XltSESV+/et3evv28eHwRHSePBgGTqkL9oz/6o9oQ4n/+n/91u46+j0wOxr8GKiKveUSemgH3lgiOnWIxRCMxcPPloKu3NITXjwq02G7VnuTTERAATGmwzsLhrEIgzphTpYiCHk5XOQ2IBpIpExAPVNhSWUZEGQuTgSYlvDLUEWRRnG041/MChk0MIMiNC6gwNPbjR6jKToVQDBdDLkDKB7lOtsLOO711wHoSwEVpHbitvs4ooDYTxoISYwQhI4TaBxhdmSjv6XcVRNhiEKDjnL0vMKwWozhyQFvfPYfBiQI/2oyMQaVM1lNGBwdUPJTOy2iEaYxLVUSqrK1trJ88bNeRjQ3n9ti3/TEGVPADCAtOe5UKrWVfOZVqQwt/ZEqMB71yw8xPtoDjGqngDnBiKJxz4KTsxYXlBFJKvN7Dp6kyiMCcIMVcBSLjY4JGTgxde+DLMNvq1Toi2T1OWqApwCPQZAC9AGkgCF9+/823ZTAEbtViFhIolTKQnK9eUfTva4si2Jmb9Wf64u3CA+iMB8j4neyrHE05ByjyKdAhG3gI2JMXQXRvUejGXUXvOIGhnWyMx/kJsqLNDmLwb8bMeGuLkdFmcOw9XxuCzJL5OI5otvEbYwVc4UOBzzxlIcE2/gDbFbBExjOEkjOAV6kfz7URaAdwInfpVcZLLy3wFJBXWTvOJbCi6A7AjURX8QIIrMPC8gyGmgySpQp8yFRGCPBWWsKgogj0rXQztAXM6EztLJagSebMj4xf7QYVuhsvR11l9owPiKue7AQG0wEDdqYBUIFBBljQMRHHq10D7ciNh3KqpYh5JgAqcBCgWiSrSnjFaZLdAD/gj2H0/FqnBvAmMAO+LQSdmpRsybwTeDoPYiQyBxhYc6Rv3RqnarWN/NoxTmDsGfTRGOrMlTgJtk8VUMD/skucbWcHof3kxEwGEFnIGACcScCenOYx5O0yAOg59xInCCC86DJ90bZK/mqdTd5n//4aXBlXdCZRTHiqeoMu4VDs1jBah/fPmXztPCjoy5gkiwSIWnEKbOSHfcZzWWD8oUu1kUfkFmi0C6EA0vPYt0Ci8CNyYvwZD1lh34En6zXogGqMyteoSmpCRVVjuyfV+TRxbGFI3VN7gcpAJ7GAVsVImyZg5BnmW9MqZyg4LxsYmeAHyEaGWcENvZIocoCv7DGa95Y36wJVFrXTstWRg8hKtUBIGIR2gmJtXBVED40X8BKI9IMyA4hCA05fZp530nLGVtFXAYKAyJlBQB9Aixd81Esr00tro3HajpesaS2xQ1LfxCLyFfmu3zP/8nsZo3V9IWbAfeYTWtiuWutJVCN21s6fo6HfRT4LHSKvTwG0j/kcbapSFnnjHyw29rsEUyWu8hIY4jU7o7KPDuzwuYRg7NZZaFDbVIfR+CSY5bP796N7k+xL9ERAHFrY7MTungAN28vHAIcXAbCT44MEX0ux5/MldyqvZcfi983zPM8/jD86Oj6JnYstlMHPPflVwaLAQdIwM+r8ywDZob4BgrZLgW3ej/EH0nviptuQqi7Gn2ipmwid+UoL5NkFUsIuAsPG3df0kS1Cp93GltGSf9GM2FktOipGdNEzjUN3An5rraEUL7wWNMX7Rw74rAQVsXG15gb+SLAHlMMO5IndMH5+li5W9TdjZ48FUE7Zlwjha+AE1WsJo5d1sJCh5BPgSCcBudoyPuMj6/TYj0QoWtIrY/E20O9fto8ySQCwb7XOJ3Shz3huTIItyxgE+NWREPmUiC27l3uzW4JY5Ou+T2Xdsy1xiK07t8W4NubYnowX5hBYmANfgp6CPnyo7ctzX74Trax3Uu2xs5znsel8awVAeCJBkPf4Qefy7H7cC7AWMJ22sQQoo8PTZRvwFu7SPvjqtUSqnW+DEwJ2BTXWppyf3QRk21Ld8Ru6azKH3JtD5vkcmYIPbDH7dHFx2s4ujzM3vkW301nb3n6f77Jt4Wn8y/Nw/ExekuY2zth8tVHtbRLgMIy1KjCw9tXZ2ehJgl2HzAL4tUX3+nqN4+bmNDrSK7tnl/n8QWIpZuL5NnS2q7INHgRwCfRjG2diI2YTKK1vrkRfzSE8ypgEhDe3p9Efa88F/totz/I3DBI7kTFOZz6Cwb/69TcZp6rXWYKBvfbuh50ECJH12OuIV/RsIoHScttPIGMrac6t1qud903A8NuaN22I62sbzQG7DuGn77exA7lFPpsN1lspmqyvr7XPP38b7LMYO2AHuMP2ww/vo4/B9GO93ZWM0lXJELYBLugvoiVt0W2wNn1dW2IO6wod/bIcDFw782VMNshgU8yDrKG5s7H+h3/yT9rHj9vtT//k30W3EgxHhr6WgWCGiAGj6kyT6rWMsBNWQsz5yQhhuvMlFpfnEgwNIhQnYfxYm19cyfcFHAKSOHftJSGQwKUHSD3wMZNyArknAgk6KosQZRQVU+q6Pq8MJxPQe62/t4O2yGoi67clNCWoQEzGyMD4jp5PW177cs/KqS6paFgcbTvRCFmYY+9wi+AYBOAfse0gAVjr6ReYlNGKsxWUURD34lgQlAGh4L3U2UtvDxUE9B1G9MsDAwwqYGO+LwYeHQQo5zF8ehBlNW3mICvouc5ZUK4jZKpHNi1QtUFXkbCswccP2wEfC3/dK2nRGMGUneIEGQTgo3ocPwmX5xOIOsE4jhG/AHNArNYRhS59LYiWxIwnQAEPZwcLAZbzuTdA3Y0SvjKM/fR79wqvwyPBA57JBshOAqR6emWHBQiqbBS2O+i+UcLR0UG+Lzv0UKft2u0DDThvu604fVoAYJcVAZ/nzM0tZjzaE0/aoW1YM35BD4Mq6zsX4zIzmCtZ09agj5vhFhjjNTkpcBMaWINgXvuHB9UHyhFWRiP30w89MzmIERYYA4SR3/CewzFm63BkI2UcJ8ZpkYxedwIWzMpucnZoZY3S/NJCxhInnGDB+h8KLfgDFmXAbq8f4xiuosB62fXZPkQfEpyGT0BpHTYXILEQw1LVxdDMOgw8k6GnA0BtRLVkFwgr8FtyJ3MOrOpP70BOIEwHKqDL/W3HibdkvbLx8XjkH+AscJDnAd9knJwBtLL7MqyMo1bWyQlyJdiwmNvZUg6ps7FEgvHcz5iqhz//9WxqAFv0Q2VDCyDQ6nwgz5EprPGbUCbh+VpPZFLd35aigMjMTHQ0gFHWS2YOfrCIlM0CevpWrnHueZ7efsGJNhuZQYGWhMS4AN7uVZ+CXJspcOh07lEWNZ/JaLNDQCRQV2A71znR3Q5OMuK5vD6vAx5jm9C7bFD4NcHO5T4SIYJG9ItAlGMcn5xJUMPemW+ADPkLT52bYX3Mi27iLjtIjjF6OPKBh3jGZvWgpgMQfGEny8bnu1dxAh2k5gZ5345MAgNzJN9sjgBEFlmWWszrDIhq+Qu4UlnjcAD6CjAT+JBtgWiv0l9nLJEBPaZ5iOSPNSp8CL7TH/bBGIEQdlSQzebSFboA3Ft3Ri/JlEx6geH4lr4VtU0Y7OwlmIrORQ5VMPFBi6gqoYBVux9wKwtpHYjdgmpzBXiFDYzMa+UROLoHG9mr48ddX2ccP9BtOFr1qo2dsYaqrUsbpfa2DD/MkPDIWMrF9TVYkgbVbpo58XG5KPahA5Xa/jlCZmerufnpPEuiMbx7FLQIVj+B2vBCMkBFXJAheJYxVo0k11qj++ZEsafxJ2yaNqIKojPH8wuV78vqCgiBKngEct2HfR0LgJ+eNs4IR2SCjPLVdOUg9hAwrgNLI6aVVAyNJ8asTx1kXmOhZc+oCibRUJCkMrQvERg9Rl+tjtan0r3VleXSd3rMB/LddIMtMDZ2sxIB0QvVFVndqEA7OT0M2BmULFqL4mBW29NXO5tkpjUNsQe1NXD4V9njyBr/x/dbi8uuZQjRtfAielxn+TyHTnnxjUCphEftWIeb9DLjRpN+3ttz/FmeqSUptqYSo7nX7c1jJSMvI1+SJB2vxIYShvCbbEvqaiM0X4EGeyQIk0CVJOT/PQceoqgwBr6fZD6O0nCeU23HTw/C+9oZM5iMHmnjhsmeh1RbYKLAx8ij4FbA6wwhmW82R2AyGz9E5+gmnpMfa3AcLsm3CmRtBV2+MzT0DIvVrfs71e6VIOLoIED7+iFyG7teicbYq7z4CnRjSyqJEj4IAKyN0RWSIYeO8cOqKqFXHSWR6/kiHRcqffSb/32M7u5+2KsF7hd2Xcs83Bu/nh9VnedjM0cj2/v5ro6hiegy+rXYofDiFtCXGLUmyvd7ElqbN6xU20EnIHv37l3JO/pYo3RydtgenlW4JFu1xB3le3Yp5V90kQTnDSaCeQdVWdl8tVYJXbbsh+9+iPyf1rpWiRvzInMTsU/OKUTT2UGC+9it/d3dBAs7oUVwZoKVxwRS7jU1SFD+eBX5eQy2CGaYjb3NM5cWZhJELFZgA3MIymx+YbOC9+++ydyfg69mQiOHvR6Fd9G31aWS7XixOoha4LO7exhMFT7WVt2WhfDFwZvhPdpL9Cp6vPvufbsOnciorem/z9zKHkZH6I+5wXG/++3vakfhFz89HHnc3Nxon33+WdtI0GPDB2O1ecXu7l69Tg5P60wk9gLe48pK59jz/MsGwB/8FCTBZ0iiO9xUooqfc/yJxISxSOof7lua40yhiBqfFD3sWP2p/fN/9j8EI2+3f//v/6zs8chPf/HTr18OUfLqbWKVmCrh7QYkjj/eYmzCif/zbXVjIcziDLrjAr6UzpQoh55iSAIc6pyUCG9tfhDj6Ed1RkaVIoj8vF7aQhg/Z4MANNWaxphF2QkqRanF+pkEx0RIGZJe7uJgYvwEGnlf5A5o2iXDAjFtZg4F8yO4Mhb3FFkySpT/+Pg4Bm2mTQWQAMIcmG2ZAZYq12V8GKyczGAzFECFMTAkHLrWOsxdzjMZcH2wFL9XiKJsYWQ5nrrnTDl2WR8tCeistAuUnpyehDHTxbC9KIaeUJnDMqx6Ziv7FprkP8y1taIzllRHykCGH8b/UmKvXTcCqAU3glrTFjDUIu3QVabUIsLZWYfvjZRBEGwwLmRBJenkKJG8DFzmbh2PzJln98XoqhkyZTGsZVQ49d4OxRHZjW15eTkR/xflOAgdAbaJAdn5i7/48/b+/bsCXAXIY/xkAmTlZHptMf7x/U7ua8wCm9KEUjqK4qwHRnViSttMwGPmWWvAMrdBVSJn6sDTb77/rlqNjJkM1IF8AUHuI8AprgeM27LXe4sxqusZN7nztyyihbMyCBlB5tHXZHAwZ6d6nGMoG+dkx6jxWsshg2HtBNkROMyGzsCB6gxjX9s45xrVJ2O5Cw0ZIdm0KsurskUmGAF60hU6ihkmcnbaNVWOlLtZHCBRoEyvFqIb5NOBlPiOtp6/uKjP2SF+AriA0dzbAlhBBGCgKiJgB/JsICLDxtmQSW1A+CbbAgiS+9pFK84LDa356mttgDLr4LT/BcBGL2RtVf0Cd6stjF7J3lbVKgYnItouC9zL4kfP45TomERIVYTzIuMVkBhz5m9XQFUHgY/qFKcPGCFUVeQiB7l9/bwkRmoTgNCpAEQMum7eCfQJ6JAN7y10qkaxBHl2VabxKeMm14yogEXFtG/6krHnfmohEVlevd3mGoEtmWbRJXLYKocv442F70CO1g+2yli0OI5NzLRrQJ0O5vu5TZX2ASn0AGqNERLkIDhq9Kp24eiuah2ZY2pkyeiHBIcsKtnQXtOBVoAIeco9VIAKeORLKqsCYZtg3FeW8Sk2MXQOrWWSLea2LtC9aze5AGiVfDJYwRZ+Zf693S9BeewBsBKhDlnIW/cFKui9E6BVew57wHaWFGb8FJy+mAgQZu0NvgHUdpc0XnbixYew/5znkfay2DuJGPyz7k2QaqcyoMcZNAIyaywENbPzcwWIbcghe8wussnkQtJAMEh3yCu6A9Wi2iHzDa2HQqdMvw0s7I+de1nYLL9nzVxVxSLjZBXYAYDDifA8oDKgXjLI4Y8qJyMBObc3ugBU3XtVm9/lc5y9JllGH48SUNCPWtcWSvEPtUlJ5MgbTssXbLAStSFB7Ap9FviyAXeh72V8K58kAFfdu384b4O50bawtFRrsqxntVC8dm2NftcBp5k/mVlYXMprrRZgC4Tx4/RUlTzAkrzHVuLseYItOmWt1HPpfXzV4nxbsRNo7AZfTs9q84WMg420a15vkeybzqhkzM4JCANIL07bm9dbuS6B3eFRdOehkq8MwtnZcegnMHcwZoLC3JvMoQl3sZggaRZWCP4g+/RAICzgH45Pkf2tFj02FKyJJecnjEOSToCKTnbAsmMW3gmEYBv5r+vL+wquJTvYB3bLs8gme0cfBS1soeCHf9KCXomY2GA2vZKFsZcZxKdqlUqMe94nyI49Dx2110r42tjCuFReJZp6i6wAM1jKWsx8xiIdwT7RHTyk61sBo9Y2SwwKhtDczrqeqWuCfAPk+IL2vRsD5nlqO9v77cOHnfi/2KYTFZSLNje7VPRkHwP9agzB2uEhOrA1CaAiB1rzVMqfYcPQWAKJbFli8RDZqk2F4ju0QvLRDk3XvfDNNz+02+gzHECm+Yw58jJOXnrwbD3T6cVB8V+bm3Xb6Gr949xgJXrnwPCnBEeCnMhD+Mwu7QQEf/PN7wPYdz/JoMTiVezNeWQ4WG5MFeKqHR3uRk5gMglTbcTaHK0Vnw+w36pDRTe2VivY1MJnicLyymq15POvximJjMcnkVOVke2PO4U7tdJNJGDbeL3allYX4z+CmxLoB7LH7jgqxeGti21tZbGt5rW8OJtxtRrP3t5O7M5km5+3iYqlFvsV9Cwuxq9Oj9Rygtev1zNuttFa3fjI0PAmNnFiPFh3ai5808Ia35GgdizBTiWWbGsfmt/l/Ynw5Obyun38+LHGbO0ue6NFTYvo4f5RgqHv214CDsEk2rJJ07HpDg9dW1sNve5rCcV27vH9t981O7YJbq3prTMQ8xxyCGPwVt2/q2bH53zyYZXoi36QYV0esLVxmPNBaF5J8dihswSc/JxOAAnTKFWwh112J9r/+M/++/bh44f2r//Nn7bnyNnIH/zNP/zaYT9KU35ETIS2g6c4hqkoarTb4q3z8/0448u28SpA9kev269/+1fVFsSRWND2cAtoy1ZluDEg0xHwldXVKJ62ARnagIYoqV0jfvbzn9eis1wWQ3sRpbNzjUxJ70FWkaGwsSJVgcqcyyH5gvGJQL23vLKS+6yEya+KgJwcQMDxcl6VdcgzBS+A2Gzmqa3MDmN68mfnB2HSVoKHVRQPozL3gCygXAbN/CmuCoEfSiJQ1Po3l0hWBnQhwYf+eWuQfvazn8fhzedWQ+VsbarAqMnUEwKtN3olGQIbNfjM+gdGmoFmnKrKlDEAfQIh21qurW5Ur6V97mVvBGlAbWXOQgibJQitnHZ7lPsKHGVfYqNLIARFlA8/bCFq61/lSsBaEKPPXyBE6An0cQItwdLJkROWr+q7tU4lNGG0+qGI4WkEtrI7mSuhA+zL8MdIlxYUzZxsvhZjy/hwGD1TNZTgmQEXDFvXwuDZMMJ2q3rL7VV/cxUg1xj86fwrw9AzWbY3JQu20ZxM0GPsAJLKl+279XL3bJIdu+6qDCtAAJ5VG05P49gzL85LS4ysuZ3dgF1AKm9GwY8i10DSIOO+rQqMzALw5tDCt2+2AvSe2vff/z4OwEFtAsjJuBxBTwfaLwvtOhC8q4BCZgXAlpHWOqByJ3N4H2Nge2z8n4rMy9oai3VQ1iAVeK82xIDcBBd2lVLmlYlVqZR1tQON6oF+YsGTCmzceEDjceQ5wpDfyRZ+6rMFMBhGtCHjPhOMy6Sq1CkfTwPlGT+6kVe06O102jbua45z1riEfvfRX6eBa5mhE2h1H4DII760N3F+fS1gOCqAy9y0tNRiXI4z86SHaAWICLCMSSaaEbRpiUyu9wSPGUo57wLdAQYWnQ6HfwCD7JDM4Mz0IM7v0wF8GSde56sZSoBi6A1vA0QxOLmvTPZjgcOqduf3yzhYNgQv2YnLOFfJigdGCC0yUMAvj203uV6V5in6MZq/61DSjFXARmf6gu3QIZ/RHUkGdqUO6Is8XMRwC5zu2AbBTb6jIltnRuU5wElVp6Z6G4Ppk69qU4xS+BuPKAjdBsbQTbZe0FA2NPOyngEIeKneGRvb6vT2OpjPVr2Rg8GU3briHPNMekYGVIPIPL55Bnsv8BUA0xlBRNmFBKCCf5nJqhLlu3Tezl8O3LMdtLbiQzZLJSIvGWT3QX8V4TrToSpVgnNtahfF+wKnoRl6qLjRndryNhTQDmhtydz8YuaUwYX2eMdPWfBrnYLsvI10JHLIIEerHdkRAl7WMWmtGIt8o415m8NM5vx4F+D4cB3wof1C61mccuhpcxWtn+TdujgA1BqgqeiVRIkscrWvhSN2HbMezZbTqj3hWn1mncZSgoSlBCIAO3oAhWgXNuaevfJZ7dwRXGaWzcVHp9qzYS4li76gSoYW5LQCmcjUYoAUYAs4C9icEzI6PBkadhlTERsLmlV1A1Tpvh/B7Zy1RBmzVilVIbxRYdNiJ2Anr+zV5qut6Nl0bVh0FPvDJ9jQp9ZpxhdLKvBdQKCg2P3Y3Ic4LUkMmWxrKGxgsRiAt5qg8vhwv318/0Ns22l4xlaH/5GT8dzL4bO1bizyJSjXqmkN0vLKUtlt4Jqt0krFr9X6JRWf/BRQDwgnx/SyVxbyd95QTVHNIK+CVYG7Z6P37XUC4lNtlb1Nvdpy8lW+u+8SGl5E/4aiL9bpCD61cRrHyKik1GwCwqUEzCtlkwUdI6F9VX9CYy3J1X4b+stwu19PcOg6SAASMG3nLhWPsQRmz836UvYzuqNCc6a1Lzhp2aG20bXoCZ0SuLHheFBVaIm8/EvetDAtLS9XaxLQKPlwsHeSeUl0ak+MjOQxNsRify2o7+2LGVfxke+1pgf9dLcYe6Q245Dh14Im0GR/yK2kmrWlbK/vOKAVP84DrgU9Ah0+kD+5DD49PxdsH0a0Q6vaPOCuvf1sPUHdYgUu+3v7edZIYazf/ea74ImTBJ3zNR/VTvqDlw6+//zzz9oXX7xp6xvLCawm61zGX/7yD9ubN5sZm8TDVG0nXTvNhh8ra0vtsy9et5989UVhgF/95s8rELE8w/mNE5Pdr/CtdiyzXvz607IJyWA2RMXvqna/G2nzK5HP9eU2NbDzqKq41vXYy9gKu1cu5bk2E1Fxt8Mf3QsZis7O3DHm8Vy7mnGtrS+0L3601X7041dta2ulxg4nLs8vRX/s2gpD6FxhD8fiR4OF8nqw1i080xmk/VAbMDy3nyBl52PmkMCCLTZHybpq+y9eskHxbZ+SBoVXYue0G6Lx/v5u+/D+fXNUjDnzOS+HxJIlMiAZW2t3Igvm/9IJUGqYf+mEgEjl23N61TDy5rn5j5xUUBTz6aWTBS4GHATVdNnY//k//6cVdP3pv/637TnjHlndXP1aSXl4lDAkYowRpPSCFKDfVs8Yfnt/HmXMjaeHA5r1BMfQLAwy4F6uMiBA3+41lFs/LqCDCMqBy4lcZaiBAOW+xRgjAG8QAayzY2IQRYjK0oyZzD0nS8EpB2JQeBlBgY3shJfg5GWtjHYAWQEZLhkrzkHGrHpnYzhk7zhd92f0lQF/8uWPE1ELBiKU5cC1KUxV5k6mz8J7+6krm1t8B5iX4c69vOf+tnZ2SqzS3tu3n8VYjLU3r1+X8xZIYqqMnWsZG5lgoE57HIBKGQG5VUFcDI7zgAgBx7u4tFClQlliQYl2PPMlSIJENOC8HZblNOc6NTvCU33PkcWQL4aXkdSjrAWN8R8OQDWGiwIdsjIWggIqghftOcrwImutMVWBy7MorR+GXFbF+HvJ8aF/xgOXYybAeXbo2aseKnedBj6V1RMEUN6JaQt0V2vzjAU73dnWM+DcjieUUDmdso6PztS4oDr89CCGs6BqwLOs13GcgB0+KtiNcsjcWfyNdhRTZcI8tcnwa8YNDAK/xkMetTlQSKDCuSDWNdksQvsOZQMQ39gKMvJrNyKOh6P9/IvPQ39bx8qmqwL27FxV/hJ8AMuAq4plpCx8kEnG16k4gvN2avMJbTjRJW154zH2AA9jw6kK+jlcztYzGH0JAqBcIC2DypkzBoJDMmJO8ihaUXvbwqfAMfrhOqDD1sFoAUDGB9bzbA4xTS8j5xWU5bOYFvFK/l8b110BayCbrgOUDI7dwcieoMfhgtVmmWfjP0uJLvSw0z2BTuhOzgUjT0BBnv3X7VAMYOamxY8zrF3WIp9aKw2iMn4Zf2VVy/DFSEaeHsmEBEnesyU3O4KeAB2ATN7sYqQSaNOL2kkv9xW0kH3Guwx6xkSOPOdFtsu45xeVgFp8m+9YE4K2tulmwB8yhqrAZDwybALCmbxYVPJj9yw201qTCno+zbvAauTlLDpuxzAAv9rpwhxyIaglB/0so9jG3FuQWsmNjFcLLz1HZyDSsyroyWeCI3JWPM4UqoUgMusPPGDTfIYXYUubz3j7ifeR5VzT24usG5ytuTlwUWIFNczLOLTqsHtkiu7X5ji5X6YVebL4NsFmxtAXa88U/edi38yFrNJbdpuNkC03rtquP3YS8OqZ9PAekMr9V9b0uMt2xxaFT5Id6F9Ba9jlffJH5kKSTBXI6/aHLnmmAwRlcFVtySNe9+BH8NbvjT+yjLK91eanspjrtbRqe1oKULQ5QYHR2CAVLraZjWL/+kJksvFQtDcYW9xqzRpOcOTEd0DGmRqce22SEoDjLD0bQwhYyCO60v0MP7cILTIfrZrsKp+pfYkMaRGtXvu8by7odnSItp5nAJ51Wz4N8NIZoTqsuiwrXpvgxE6ynUB24YCAfWt5rWNSHR7MjscvnJXvIMsCKz8SaXigcks4bBYwme9WMJD7CBq1PuEfO08Oyq6FTuSYT7YmAe6wEY42aVv2ryzPNgcyPoeWpyeHAWYnBQSdNUj2bOXck4olHrnnVRsPUdkjW9qXvwsP/dBlem19qiSAalMlcdiPmGngusCXNS6Z71DsrCqPwF3FRrWbTwZiLZg/T9Dj8EYL+wXcbDw9AADL3uRfslUt4flcIortRSDVsxVHYuS7TrjnLwRodN/3gHNV4rn5QR14WR0GLDG5iewNEgwCvQ6dV4mttciZhORjP7Q8Nlcgv7xUuqZrxPbi7HfHU7pXBCwdF0jcaiWan52P/C2UPSQ71se1Z/5hsu5ZZwI+CPguCs/hrep7b3+cji5HNoLLVAh1jehUgQ8FdVd25bt9SuCqeu25CbaCn6qqavzGFF92nIBBaxh+aX/EIxhGsCe4I5PoMpibDB2nE7gvxS6dNEdlwFZ8uOfu7hwm8Oj2Q2ubIHFl1Xk82uAlRA+DCY7D5+f26vVm+yy+3e8wmTXJmwl6CoMlcHz9JoE8us9NFc11PF0Iwk5s7x2ZC95bW9soOWH/d3e2K6EDx9lOu7o7Ip/siPVD2uM2ttZr0xSYgDzCFwJHMoQPw7BIdFeiMAzO372NVgBWQX/pzkStpZkOD7T72dWWPziJLVANkfiUvLEBEjylG0sgakMzbfUqtgIRdLKFtOQq/34erFQttdFXtuCvl5fkjhJbxmtc/HV9Vgpow4+x0NjB+yOhy2XG0s9REnixEbHE4WPkLzzB/x70PJTNIBMvARD9AfjYusIV+bt8cX4kAuq8sHyn9Kmu7T+FO6NDZKl8YWzDv/gX/zz82G1/8if/tgLrkfmVxa+rBSXGPFCwG58AdA7DQj5OS1DknJHlFbugLYYOd21n52Mp90tZkkJrh5Kt51RQi5+ydavsNCEBehgMQEAWmAEGqDnRTKNaA+pchnzuX21kyl4m1okBQGaUmUitrcl3bS3pcK3ra8KSYKtAngzpdWUTBRscg/YzO8swbFqv8EjJenFxtoSmAoLQwTMYBnRQSdIuBzgQIq9qWchnIlEAwg5djJ5AiCHnXB0mRdhXElAty9plPha5cWyChX5GRz9MksEGljzDuhbfI7ScSm3lF2iv2Ce7KftRwhZuK80aRwGtXMcQvH3zKg5wEOO10NY3ViuQtAMbg1EZHmA0NHUGhV5WDkI2Cz1vE8i4T+QrQhojF6eoXAh8VvYrIwE0KB1DzYkW4CxhBH9yTd4zf686uZshi3D2IOmyDBi6AXBlAXKdzPfCQuhfAJbMjLalhZXMT6DXA+m+haI93VVwtM34ep5P2PEx/LZeSFXDeOzCIjMBqNr1TbaH8svsHh0eVrBcPMtcGF0gElghZxTTTctBh7ZoIesF4BM+c9anTkbtOIhXgmMbTXA4PjcPThRIBQpslVsLjmPEgGVzk3E2BgbJto1orbxsTY95U17Oz3wEoWQ9Uy75Nn87ywBUWnk4F0GNe5Ar8iFYQH/07e09KnF24bEdaz8rQ6sEQ2O86MgOAGjW2ZDnyvCEht7TZnX2aa2Gz7qxsnBXy1+uDX2AZ3I8GrsB9LAhdJI+ub4Hbn1nMgc7AprK3hecfeRMe6LxshOMnflbzwTAEq8aJ/5mLuRH+wOjj1fWp0VYYxxy78wdDaYT8FabYoz36XkccXhrbj3T7JbdGGtvQhdEkJFihDkuclU0pG90PmM05xfQQEesFQqJSpwZZ0AOUM4Xc2+ASeb2U5Uk3/VgfDN3czIerSf5JPcZyTi1Guaz3NfaIyCo7pl50T+tJzJa5kceXoy+SkFtbGCMeXGIXgC8iqVkTq1LCG3JECAr+CH7Ktod7N3nem1ZAYO5rZYsIJP9qORPHCIZ0ILDoeA5gG+dCDkVwHq2F3rSUa0nANGAvGfctX6T4wnBOCatyFpizAfNBEZ0zfkx2vsEh2RbNRB/QrKiu+w6udQ2VOA7PFa1BLZKBkOr3lJ1mXn0hFkYgMqxJfjwkGd9AgojJQzRw74WIgyqMUkqXWa+ZScTmDgbxbqd2UkLjPsGDON5hnM9yABdAiTpas3HbfOSgCjdQbN8vxJxo5HfPBd4ZzvRGDhAZ8CBzdGa9/AkUabKddbBD0HLDxna3duOr5Y4su39ZPzgRTs4UjEBDDO20FtCxGL6TsfwGxlDB9/Tgmobcjpi1ywnwp9UK7nNL7S3JijN3PmN6RkVgcixrP4jOoWm4bOg9CQ8BIhUh+rIgNhXOu+sEzYRPyuICi20SmsHqgpW5iNQNCPyWAc46sjImJyKv7m5GlA7E7kZip1ESxljshM65MfvQKTgsic0E2UHZzyEH7YYd65QyTU9KLmIbYndMw6yRIboBvqTIRlltocehMIZM/2QIIqsqHzmWjLMJlTw8MBPqE5kbJFd641tkNLXjPV7wUey0vTy5vKm8BE7VmcoZQwSBqrSkikSoqrSkmVwEvtsYxnrwSq4C17RgkY+tGiqyvsdDmAG7FIpKcwvOgbDRil29CIH+G8nw7I7ZhdZlRxhQ/h/lfdq949P6sklxySctN3do8hDAOT9UPmwszPJWnPv8i55RNZ0pRgv2gqeK8Mffew8dxxF5hGwrapui+tq8ytfLiHdg31YAc5h0yxzwG87ogk2VfDubi/b0upCe/v5q0pMV8AXudSNNDc/UZgJ3+Zm52LvZmrzhaPD09Ai+CNyBvNMTAwHG61kerqGdoIvjkv2yDrs9RBm9jU/CWRiR9iAvf3d3PWxki1XN8EjwUySneRC8kMbMJ3Dw4hGXk/13eOjw6L3T7/6qoJY1RzBmo1BnLdEziVqtErTcfznO1Sd4RLdC7bQPtg5iFgHWyTodMBrrUGObMNGN45KGZsq2ms1hON1PcE43OXpiWoq3VHpecp3+Lqb+t6pLeaPzgo3qHxaS606V5gEf0ILmoYnMFUkOn+ZN9zn/V71LC+UC8mUhOf8wmyt7SFfdqSjG2X7E3ChT831mk/j58hf5CsfdOzUAxsqyqb0ZFUu8sxwge4xgWx8+VkXonkGZEzGRv7h08Khn/z1v/pX/1O1Iv7Jn/xpn9PM3PzXGCKKFkTos52dm+v2NYZ5JEGP11gExkJuhtpOPlqKDg/PwiTKMpMB20VBu02CnIzEeiCMYIh29z9Gmc8CalSJAu5j3PSQ63E8PNxPVLoXIiUAinCbXC0KZWhq4Weur/I9A0OpAwAyXobOy9bP2go4H+NXJvQ3g7GQAICA4lcHS+j3VG1Xskl6OO3gUWW8GE2HW8nEWeQugyeLtpbgRzZK5YZDENxggioJ52PrZ5kRAs7hybQotWLmxsZ6+/LLH1UbnZY847O9ruwFRwCE9GwTpYkARzgKjGaeF1G4w6P9ykZgJnDpZOQ69G52pg7vFNgAluaoKiRj42wc5xLJJmxtbQT8OStCkBnhDq0stlWSljnheKsFJd+vHn8CWGBJuRKYjpCHXoIsBhpI9HzBpAqZZwtISupJYP7hYGqzAIYg363qYQSxC7UMiUqXLFP4l2vzT/g5XvSzqxzlV2Gx9siucocC6VzvhU/GbVvRcnrhBQfBQMrmyOJ12sqM9jKo3lP3Mr7aHTD80RKF1gxd0Tv',40,'2024-11-27 16:58:28','2024-11-27 16:58:28'),(38,'HẠ LONG – TRẢI NGHIỆM BUFFET 5 SAO TRÊN VỊNH HẠ LONG  (Ăn sáng, trưa, chiều )','3','<p>Sáng: Dùng buffet sáng tại khách sạn.&nbsp;</p><ul><li><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>9: 00: Đoàn khởi hành tham quan Bảo Tàng Quảng Ninh .&nbsp;</span></li><li><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>10:30: Đoàn di chuyển tới Cảng Quốc Tế Hạ Long và làm thủ tục checkin trên tàu.</span></li><li><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>11:00: Đội ngũ nhân viên của du thuyền nồng hậu chào đón Quý khách lên tàu với màn Múa Lân Rồng đặc trưng của văn hóa VN. Du khách thưởng thức đồ uống chào mừng và nghe tóm tắt về lịch trình và các quy định an toàn trên du thuyền.Tàu khởi hành và đưa Quý khách khám phá những điểm đẹp nhất trên Vịnh Hạ Long như:</span></li></ul><p><img src=\"data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABQAAD/4QOJaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA2LjAtYzAwMiA3OS4xNjQ0NjAsIDIwMjAvMDUvMTItMTY6MDQ6MTcgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6QUEwMjE5RkM1QTg2RTgxMTkyQzE4M0ZFOTg5N0JGQ0QiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RkRCMTI5QzQ4NTI5MTFFRkE3MUZBQzNGRDVFRjhEMjQiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RkRCMTI5QzM4NTI5MTFFRkE3MUZBQzNGRDVFRjhEMjQiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZTAzODMxNTEtZTEwNi02ZTQ4LTk4NmYtZDI1NGRhYWJhZTIzIiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6ZTFhMmRlZDAtYzQ2YS1lMDQ2LWI3NmMtN2U1NTk2ZDZkNTZmIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQAAgICAgICAgICAgMCAgIDBAMCAgMEBQQEBAQEBQYFBQUFBQUGBgcHCAcHBgkJCgoJCQwMDAwMDAwMDAwMDAwMDAEDAwMFBAUJBgYJDQsJCw0PDg4ODg8PDAwMDAwPDwwMDAwMDA8MDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgBhQK8AwERAAIRAQMRAf/EAOgAAAIDAQEBAQEBAAAAAAAAAAcIBQYJBAMCAAEKAQACAgMBAQEAAAAAAAAAAAAEBQMGAQIHAAgJEAABAwMDAgQDBQQGBgYFABsBAgMEEQUGACESMQdBUSITYRQIcYEyIxWRoUIWscFSMyQX0WJyJRgJ8OHxglM0kqKyQ2PVwtJzNSaTs5TUhtbTRGSEpLR1haW1NlZ2lsYRAAEDAwMCAwQIBAIFCQYFBQEAAgMRBAUhMRJBBlEiE2FxMhTwgZGhscHRB+FCIxXxUnIzsyQWYoKSssLSQ5PTouJTY3M0VJS0FwiDo0SENf/aAAwDAQACEQMRAD8AwccklQQkg0QKE16g00RGBQKB9eRoVPWRDRkcweQJFDoyJuuiXXTz1THYmWwygBKem4OtJg7lst7Qt8UXAlsWl/ZCVihrTfQhqHbJu0aVBXNnj7cjtpcmnXEx1cE/nFVNSxULyVieQ+mEjimlrWoNPFwN9DXr8dEOCUmUhcgEtpZHJYC+oBJ1pqt/VBG6lbLbZ065sREuuELVVdSdgNeDVgyB6IV2ft8df6Z7P9wOK5CTUn7tbhi1lcARRUyRCaWr/DPL5E+lHQ/ZTx1n01oHk6L7gwr22v5hl9bRQrY11G6NeceOyIdxybILzaI0CUFIajpSHl71cKdhXWrbcVqhriRzmhVewLX+u2xHMikpPLfeoOpuAAoomuOi1fsVVY3ZFBRI9hBUa/DSp7fMrPF8CvcN1txoclj0g0Ff6datapvVQh7koZkwXUJWFVSoUqdTtFFpI6oWcOVuNwb66lLxSpPgCfPTOJV24JDtF12i7KWoFb5IJ3qrag/fr0jOSntn13KertJ9QmQ9tYUVUW+Oz4jakl22THC63xoB+WVVKKDyrpBeQEvOiuuJFs6KjjqtKe1v1c41mMFDr8B+KGiUSXyErShSAOR5+W+22sNaQ2iAkdHyLWbJjMc7t9v8pSn9Ou8GSsmikBaQvkf9VWtw4haUCIKf0G4N8Q2y6D6uVE9ft1lzV7mqxf8Atji+Rx3GZlvjSmHB6mnW0qpUeG1RqLiKr1eSVzMfo2xW4qfkWdBgOupPFFSWwT09O1PtB1uEO6KuqAX/AAz36wz3WrhbA+1xUyi4shSgUdBVBG22ojcOZsioWBwoVXsl7Q3TD4CrhZLg5CkNgERllRQqvUffom0yjmnVRXeJa5vIbqmQO6d9sccoyG0PJS0ePzLaSpBA8aiurFHeRyBI3xyQtprRE/Fu5uPX0ANyW0rVTqaEH416aIa2N+yiZcMcaORehyor7YWy4hxJ3BHjrWgU7ZSeqr+ZPpatriuINQafs14AKOZx8UvzspcmyyIqkkrJUEg7VrWgrrJAO6HbUghCrtZhdntmTXGRdA2hMt9ToooFSSfDQ0gpstrdlHJy4hwkNKYkSmEoUnilXGoI8K7aDdIQdk6YwHqs/PqRwO1quzl5sZ4t/iT7ewJ3rsKa3inIKBvoBSo8UsGP5DNsM9pxJUj21gEdAafb46noHpeCWrS7sP3jtVyS1aJzoK3BsFb+rxTU6gEfFGtuS/QpssmwWzZXa1ux0IUXEVKDSo23prZR3VqJW1QDs2X3btDeEW64sKVY3FEMSkIClMitOKx04/HrqYNBCrnz0tlIBrSqcTGO6uLXuIysTWFlaQrkCk9fs1G6Kqs9tkopmVJ1Vglv265upcjFt1OxTQA7fdr3p0Clq1+xVpbQ2IzaChsUAFABqItCmDiBRfkx2z6kpTUddhrFFjkV6paTWpaTx8TQa9QLPIr0WyzT8Cd/gNeosciuRLEetS2ipPWg1kBeqV+djxlJNUJ2O9AK6zReqVS8htsDhzbaDKgCQpKQAfuGpGBavJogDl11VAiKKkFRqUsBsbb7dNbvHlWsbihPbp9yXISmMVe02o+62Ek0I8/26goFsWkpgbZCVKsqvmGylxSDXkKeGimqF5Kqr1vYW2toIBUmu9KHfprW5dxYl1zUgofwIDUebLeeCuC3CnqT49eukcWrlWnkh1USYdoafSw6hoLShaFAkeSh8dbOFHI1lXFpqtCcQZQIccFAH5SDSn+rqYahW+IniFc1Nor+Ab/Aa0U5Jovn2m/7A/YNZWlSoi6Wpm4oUgoB5DifA68Flw5aIewMFs+PtOpTDbQXHFuOOJSnkSs1UTT9+pefELVsIYClj7q5fjsPIlWCPFQEoaUuTMomnNQHpTUj8AFVa9HKRqls1xxdxSX5XGhNXdNys6G58dP5iysgqKq1PQig8Ka9zJNSlsstHaFDLOHXb1bXTAt77CSKNtobWEhZNVEq6H7tFRPY5DyTcwW6qW7JuY7F9lm/ktKQ4tblxWFKHKgHrA39JG3w0PcjwU2Klja0tcmsR3cxO2PtWxlhuS+7VEacwr09AN0kA6W3FvyGqsDchGBQLtk52h1pDEqOZrraPyVIPFuprwKh5pruR10vA0opHTVCibROYW4UzlgFwK9yOpHJCgd0geWl07C3ZaxSedcaLVLuUhaIralKcStLjft0PjTgDWn3a1gBOikYCXlLv3AwJm0yZDD3KO9IaUVQ0fi5qO1K9NO4JDE3RA3EFTqUv13w2449OYchPGOooCkKUrkeX2eejYbz1NCl89oK1BRLxPvU5j4MTJLP8xFdWG1XJpBK60H4kEeP+rqOeza/UbouC+9JvF2yrfczuFZ7stMmxqdlPOVC3C2poKWpPEAJVQgJTvvqWCAMXri7jeEHsmzLuLKtrFvlLmW+zReDwaUAFOcfwe4QOXEV/Do+G2Z0QMl1JT2KDx/IpV7vdpgXqUI9rDyEuLYAZIQep8qk9TrSeINaaKCCQySCqfiP22wcYpb729b2be0hrnLuEuWpToSkE7I5UNT+HbSmN79QOqsD4WcdShFkFktca0IkW9bzMiZz+WQtW4aHRSVdRy8BqJhkL/N0QRYSaNQEm4xcmpClRkP9C7VSVUVXxO240V/dIZN3BRvtZGurQqz43CyFqvycF+S40gFoe0VhBOyiBTy1X8hkrNp8zx9oRkNnI/oUe8Py6Cq3m3XZLcv5AclNLcKFF07Dkiu4HiPPUFjc8nVheKe9M7d749KFCHO8cseQyZK5YDUh90lbyjQ8lfhSPHVkbM9kdagoW+a0auCTDuBh8vGZxCXS7EWo+0QT6a+em9ncNkjFN+qWPoynHqhwrnWhWqvganfRhaCFgPKtuE5Auw3plx51Xy754SKknjUdeuoJIqtUcuvm8FoLgd9yd5yNKs0cX5KGAiI284DxUdkca76r91GWHZFW00hHlOirXejIb5j9kelXKMizz1JUkMtkLcU+rc8jU7mtfs0RZMLlm4Mo3OizpkOvPuuSHnFuOPLUta1HclRqa6bxt4rUPPiuU1FfUfM9emsBgqpOZ8Udu1PZm+5xPYlzrfNbsAUlTz6BwCkDfdSuifPU7YgRUqEzOOgWhMLOu1vamxmw2bhInstlDzzNFr5U3SFfw7jqNaGWhoshmleq+v8AiPun6V81/Kcn9J9v5f5z2XOHuefKlKU8dSaLHqO3WLhG5HXbcfcNLmbJu/Qpj+zXbbH7jj107jdxLrMs+B2y5Js9uhWtLarpfLr7SX1woSnqtMpZaWhciQ4FBoLbo24taU6OtwS6g3+5Ksg4AVdt7Nym5xyZ21VFKce7MYt7UZIPLIMhv8qavlskLdgTrawpW25SwkfAaaiCMkBzz9QH8Uh+ZlaCWRj6yfyIH3K7RcksEqDKVI+n/DI8ZlBWH/1fJShTaTxKv/oyD18NLb22jYatcT9n6J/jLyeRtHtA91fzVK7jdx+38Pt9cFv9gcQmJSUD5Jy55SG1AmleTd6Qv9itL4ga7pvNQNCTw93u2CPw/S/gYUkeF5zX/wC+LW7qjqhQAei64/ejtoQS59MmCAjof1jM/wCvIjrFT4rPpt8FO27vfg8Iqfh/S9g/FfpU4i7ZgTvt/FkB1J5vH8FFxY3Ro/FfJ71ds33VKk/TBhKXnFHko3XMNz//ALBrLORNKn7kO9hHQff+qtGPZl29yaaiHA+mbBTJXUtJF4zKu32ZDo91m4NLuR0936IT5jzhgaKn3/qrdcLtbbI24V/SphzjSd1Fq7Zivp8P5gqNCGMnqfuRYeW7tH3/AKqBY7w4O298nJ+mbEGVObLbNzy8Hy6Kv2tHMc1pNdvcsxyeo/jxFD71KMZ12tjXq1H/AIccHbddeSQsXXLuYJ6Ef7+I2+I1BE8ubWuqnubVsTh5dPr/AFTy27ujhkeDb4i+0uNNp9tKUtIn38pAptTlcyf2nUTo9Ua2QBqlx3RxNtZbT2nx317FQn33/wCSevCJZqqHlvcLFm0lb3ZnGH21ct1XHIhtT/Uu6dZ4arUvI0SO533M7btXxwH6bMImKIqp5y75glR38m8gSP3aMaw+P4JdK9rXbfiou09wcAuCw1H+mbBUV8f1nM//AL4dZIcOv4IcODnUDR9/6ovQJOHFhmU79OuGe0kA8BecxIFfIKyEjUT2V1r+CkfOYNGj8f1TCYJkONy7eqNbuyOMwI3D89li6ZPxPh0N6OhH0anVmDIxXONluOY3I4W/s9jUZ2g5FFwyPkD993OsthD1mRxYrtF+oe94sn5m24HZ2AlQCmnLjkLoNfEBy6LH7tbm2Wr5OKKmO/WxeUBs3Xt5a1Np/GqNLnBVPMe6+qv36jda0WfU0R1x76xMGuntpnWFVtWugV7qnlJB+KvcNNYNuQsslB3KOtl7q9vMobT8s7a5PIALQHlct+m3Ouh3sp0UgeOhXfc8WwrI2wHcet01B/8AFdkhO/8AsvjURjaRqFOJXeKE+V9o8QbtrzVv7f2aSsgltp1+5FBND19uYk0+/UQfw2H4qTly3P4fokmyTszIt8x6fA7A42882pS/faumSthX2JbvCAfspouK9kal8mPa41AVWxbulcrPcZNmuPZOxx/kHOLiWp1+Kwnzo/c3K6bsvGONOZ+79EB8pI3XiPv/AFRdmdyMVu1tHLtzZnFblUdyTd08T8eM5J0wbHzFWvP3foh3voDzaK/Wom233EpFrdWe1lgCaq5IEu8kH7zcCf36he1w05H7v0WsTmuaTQff+qDdoynBY2Syw12Yxxtfv8S+m4X9SiSaVoq6FP7BqMMP+Y/d+i1a4cvhH3/qjc87jkiOp5rtlYUBAqqsu+U38KouY0PK2hrX8Ewj3QwudwwyZcjDufaXGlMiiA47NyAg+dKXUD92tWsO9VhzgTQquZngvaxdsXNt/ZLEri4EkkKuOSIFR8W7wg63ofE/coTG12w/H9Uqcbu1i+A332VfT5iUNLTntl1u65WSUg+Hu3taa/dqYNLh8R+79EC6XgfhH3/qtMOzvfnEcotER9jDLNEjupCAESrmviRtxPuzVnbUQYfH8EZFJyFafijBkFuw/JoTzi8Bss5ZSebbsi5JrQebcxG2t2g+J+79FFcWzJhq0E/X+qSW+2CFZcipZOzuPso93mh5u75U1Qg1rxavaUfdTW3Mg05H7v0VYmtHRSVZEPtf/wB5Eyw99XMTmR4GSdsbTb2F8Q1Pjy70tFCfH3rg4f26lLCR8R+79Edb5B0T6SMAHvP5lN5i3dCwZBGQ5GxuCDxBIS7M6H7X9DvjPifu/RWGG6bLqNlc0ZFBVRYxqJQ+Puy//wAPqPgfH8FPyXSi8xJPqGMRfhV2WP2/4jXuJ8fwWa+xfapzdKjF4RHh+fL/APtjXuJ8fwXqryRLjqVRWN29Ff8A48zb/wDSNe4nx/Bequn5mBSirBBoetHZn/2xrFD4/gvVUReZNjTHCncbhObfhU9OA/8AVkjWzQfH8FhxFNkDb/dsaajuLe7f2d0J5Ec5Fz/pEwHUzozT4j936LRrgDsh5jWc460++yO29miofVRC0ybuoqNf9ecqmoQwk7/gpBJRFZjMbQthX/0i21LSBxX+fcQAry/835aIaw/5j936KIkHooT+YbK4XHEYBaCFbAmTdKmn/wCe6gvGkAak/YgJXtofKPv/AFUbAm43NWpDvbqzJ9R5D5q7da/GdpQxxa7RKHtjdX+mPtd+qIEedY4kZIRhNpbTtRKZNyPj8ZZ1KQXopjWtoAwfaf1Te4vJjOxWVN25lgFCaJQt40FP9ZxWpQ0gaqwx7bK1Kdbr/wCWQfvX/wDNa1UvRfPut+MVH7V//Na9ReoF8qeaSFL+Vbr47r/+a1kLVC3Pc0tVjtM+VLtrb/tNqLbKVPVWoD8P5biTvrcg7KKWQMaSs7L5mmPZPkD8FHbKy3S5qXRz3ZN5BHuUNDwuKfw13oPs1vw4tLklNw2U04iv1/qrVaO2GOfOqcl9ssfQ022XnWmpl/5VHh6rqR/6ulcuTZXiDqpY7QE1LB9p/VF9bPa+3WZoS8TsENwte2ll6ROSPSKlIUqXUfbXWYDIXaBHMjhZWoCSC/552xtOSzV2vtriky2MqUJNwbn32hdNahJTcghVKCpAppuxjzv+STTSwxvo1o+/9Ux/anH+3Ga2iPd0ducdM1Th94xpt1UWx58nLgpW+l19KY/ammPhjm/lH3/qrBmFtxqwuSI9v7d2WU2ySHXHJV2SabCgInA1+/SX5toNAB96YSwtbsgwjM7Hb7mtEntVZW0cgEOfqF55JCehoq4kEfYNTEtcK0H3/qgRKI3aj8VZ4/e+y4/KU9de2UBuI5RsvwpFxcWhI6V5zTU/7OsxOiG4p9qmF4GmoGqoOaZ9iGczESLN2fgXNtgBTkyfKvTKyQdgEsXJoj79Z+ajGiinlL+g+9AG+ZzYos5tq5dj8aU/X8kruGSFQ4nx/wB8anY5m7UK145ULR9/6qOyjuR2+MNDzvZHEXPlaFCFzsgQQsjc/l3dJOp4S4uXpXR0pxH3/qqP/mx23SlhLXYnEllS0uOrM/JeKFA1BNbxU7jRXFxUTpmAfCPv/VE+99zO2N3xhyUvsXj798k+h5K7hfjGNaVKS3dEqHL4HbxrqCF72lTySsLfhH3oeYjdO3c+U2+Pp+xIpb5IfcbueUEJIr/4l7UOo8tb3ly6Nld1BCxmpDR9/wCqlcrzLEQ/BYa7EY3cCogOcrplBCOXQem9J3r01FbzgM5nRbPeXGgaPtP6pxO3XZi25hjrF4n9q8WtMp1LSoUAzcmcU2AAShXK89RTw1yzuHvyOylfHGwOcfHl+RCuuJ7fD2CR2h+njVNvJ7W4NdLUx+vdvLMuO1HSy8207PbqkChAKZYNK+e+uZZDvKa3gdcG2ZTX+aX/ANRWVuMicfT5mvub/wB1SGPYt26x22/I2LALXCiNKJbYDktZFfJS31K/frn1z+4cc7D6lnHyqKD1J6faJQjWYv0zQPP2N/7qiJnantFe5AmPdr7D8+tZLkpJmNrqd6ktSEE/t02wv7iPBoy1jbTwfMfxkKglxQBrzP2N/RDnuJ9O2G35yJNtfbPGX5kNNHXZsy+NthKRseEW5M8lCnjU66Xhv3EfatpPExtT0Lz/ANZzkrvcRHM2vIk+4fkAs2e9isVtU16yXf6fsSukm2oK2VLnZSw26ASOSA1emzTbxOu2duZmC/YHMIBNNB/FUrI2LoCKt018f1SeSO4vbZoqSr6ZMHCmyQUqu+Y12/8Augrq4sjkBoTp9STerGfhb+P6qDd7o9s0KNfpkwbl/wDtjMx//wBDrcxupTkfu/RSNlB/lH3/AKopYN9Vlhwl9ldt7A4hFaaIKENXTKnCPin5i+Op2+zQc1sHmjiVoH8D5Wj7T+q+O4v1R4x3FlsG6/Tzh8yBDJMVmTdspSvmd1LX8re2Ekk+YJA8dbRQemKNJ+5SOuOW4H3/AKoVPd1O2aBX/hiwUjx/3xmfj/8AdDqQtI6n7v0WWPaeg+/9UxXY7Fe2XdV1yTefpyxKxWdkFa5kG9ZU080lO/uFUy8ymh02q2rWWxOAqXhYM4JpQU95/VNleMgwnFMFuyOzcVd5gWCQ1ByWyXBbcmZb/myUR5SXkNtpkxise2VhCFIWUpUn1oUqMyOeaNIW0fFurfrr0SSTsUfYnSL/AJCtmAw4v3mYw9KlFR5cQkbHXuPUkKVzaCoRj/zKX/KNf0Fv+WPZ+R5+96vc/wDE6fu1tzC9yHHksnk8XFBIpsPUfuGhIxomD+qZK8pWj6a+zCWSpIPcHuCtYTtubdiQJPxokD7tExOIf9iCuAC0V9qH9pm/LzGGVyHUl38JStVB41ND4amla6tQhIuIGqONouT/AMt7KJj62VEBaA4oppWtKHwJFToOQnqm1swUqFzd6MhQ1isWzxOT8i4lKnEJFVISgVNfLWYmndbTOG1UnYC6rKkkV2FdbOFVqaLyCFmtOQ1pRbcgp62X+dbFNlIC2kqqpCkjcffqXiQovTbWoVmnZLbrw4zyiCO5TdYA/q1lj+JqobmNxFR0VmxC/Rcdu0S8tyipcUFSW+leW39GiJr9xYWgKOytwXh79KJqsb75LmtutOhmYkiiUOIC6D4HrUaXxzv6hGXMPP4QrPZc+7c5RIcgXqxtR5wWQhaEckkD+Kh/qOjAXPYaBJZLltrI0ONF/bp2jxDKnkT8euAhPxzzZTyKRt40VsN/LQ0EXEa7phe5Fk1Gg6qnX/AO7VvUly1y257EfZASSo8R8RohvA7lQuLzoEKpWS92rVN9uXDXzQrddFFOtvTI6LDLh/KlDXwXk53GyR+SiPe3FICFj00UkEHUb29UQLg1oVTcns0i7vruUdKkIUkAgGvXeutGvBNAVrPGfiXzhVtmR57TbgISTTcEH9+tnVQjHu5Vom0ixlrgIQDQcBsfCmtNVJd0cKos9r1KaZktb/g6jp+3Q10zyj3p1h5QQfciQxARMuRfePBpxQG+1SNegeWhGTxcl9ZNaWXkIbYAUCg+keaTQanbKRuhJ4wdlCWWzMq9xh5NF8evh01I+XUKJsRG68JURNvPFscwTvqdtCNVDKwg6KdtqUpZD4UtpxvoptRSoH7a11DJCDspIiK6lWaP3H7hY3xVZMonJSjdLTq+afs4r1B8sCiHuorrbvrF7i2IoavMCFe2Ugc9i2s/Go2175EIc3Yad0WrJ9aeBzmEoySxS7KpY/NdSgPI6eaTXQktm7oEZFfADVc9+7q9mcohSLlCl2y4+22VBTbiGpSPipKgk6E+Te0o0XsZFCQhLi07F81kTVQJSXY0dSmmC2UlVabcqHw+OmUF46AcT1Qsti241CtsPFH7RFfZ+YRJY5KU2qtFUP36ObcseN9UuksXRbBLwmCtrKJKw2ePzHp22JJ2+7z17mECGgOom4tlrgQsfckTpHBTTRflBfRIArtX92h5CSdE1aAG6pcXXWb3epMlLPsxVrPyjB29PQdfHx0XG3ypdIQ92hRHttjbTDbTw5CpBSdwduh1BJop43cUs/eHsNMvgm3K2sKKk8nGghNKGnjraAmiBnj5ahKrheYZD2pvyYc5p9uL7nF+Idkmh3Un46mAUTJCzRasdrO79oyi1xxDlpeStsAlRAUk06Kr0OsFHRymiKUNqLOuH5jbbyAoEVofjoctHLdZPm1IX1mnbO13yA6UsJIUjlxPWvUU1OCQgLyyZOKnQqrYhi93xpgiNt7QNVHlQjwGpN1HZxui8oRQxO93G7S3YcltX5XVX/ZrBATWJ1TRFViOpjoSSdQqVd6fc4nemvLy8FBSl9Nx+86wvL19pVa0pXz31heUFfWiIxJ3qNtbsWHIP3WGw9Fd91utOQ6V0VTRQ7IZWeO0h55KGwFJWfbUU/Hw1CweZYqihGabkQ3SuiCE8SkDqfPUwW3RUV24txHVxiN2iQK/HUF3qAl0nVS9hcS+6VlIAWen2+OldGkFCMAr7Vc5SB8uCo/gpuPt1o2Tip3u1FE4uI/+TjmlAW0U/wDRGpg7kKp1EatBVyV11qpwvgpqdeXl8PBKWlk9KHXgtaFKD9QSYTWN3CS7JUy5EUl5spPSn4q7+I1vuQgL/wCBZaW/uCm2ZS1cmmFJV7oDa6E/uG/QaY+nWMg9Qq5AeMgPgUzWR/UzCg46wuMy2q6LQG1ymzQ1I/1gfvB1Wm4IGbmnr7/iz2pMc07pXvMH/mLhdnXEBZ4R/wC6aAPhxQAKnodWiO3awpBcX73a+Kabsj9NjmfYu7kl8hLhsyHVC3sOAirdElLvE/2gTQnUckzWnRG2liZ28uqtF9xy79hprke13Z4wShx9x1ghkhvYUXU05Anr46VX0JlFaJhA91sdAvSJmDeRQ/nJUxcy3ONe9JlhQ95Lqah4OGtKnagppILFjNSUaLnmqTLvUePMcmvQAmHSsdTpIUU+FfMnWGjWgWrnt3IUEjMLJe7xa7W/7bED3ayV8kqoSoCpr01FNbOBqh3Ste4UCam4WXF7Nj0i5xmGoxcapEU2UlbiuIANd6nx0smZxdumRYxjK1Sj3/C/1WWZjDTsj3eXzEhwHiinx+zeujbeTg0BAiLkeRS85VgbL06Q006HGYo/NVvUk9OnmNN4LkkqB0FXUCFV2sSLZ7jaj7baqKHpNaDTSKSoQ8kIbuo+PPuTza4dtJUlwcEJUd6fDUj2tbqhg5ztArhh8O82hDzc1L7furqhDChX/vDy0qvnNeAAVM0vjGo3U22+3KvBhXFLyGnXUkupPJQUrpXzPwGtpGtjt6+AU0TnOeKDqtxO0E144VjMebHfclpitM/OOthCnEoTRKiKeWvmLP3EUmUNW9V1mxjcLUGqM13ZEiMqOBwbCPUr46B7qjbPaujpxFNPetrR3B/LqhG685BfWn3KNI3CVfDw1wX0+WhGqtTIvVbXqpa2X+IsKUhhHJRqPjTx0daXcljpxBCFuLB3UrxOUIRIS044kpUd2uhoeumFlmLmN/OTzt8P0/ithjvLoNUMu9HZGzd1LEXYbiIFyUUrantISHDxFOClkbJPiBrs3aecktn/ADETqxup/wA2nRIb2yFwDG8ahYQfUV2cPbDM3LT+ox57rrSX3kNKqWis0o4d+JV1Arr6l7azDshDzdtTdczyGMFvKWx6k9Es8u0rQslSeNR4nr+3VhjnjlNGkEoKSxnjbyc0gLhNvUU0SU0PnqR7Q3UoNpLnUGpXx7NCBUKP/Tx17gXNq3ULY+U0crXheE3bLrzHagxPcjNKC3XVIK0UCum3XQTpWNHInQLQOLjwZq7wWjmP9ou4S8dVFx+C+i3I4omKBLPuqVQelob8U6pOZ79w+JNJngO8PFWOy7UuJteJ1R67e/THmOPYX3lNufZOQ5Bi0SLb3HamrgyCzy1JqdhRMdQr5nVPb+72NmMpiFREwPNOtZGRD75AnbO0HR0Dv5jT7i7/ALKTnvD9NffrF4TOQXqGu7QF+pxu2lUhxsDc82wDTbx1Z8R+4WLvaA0BOnuSzI9vTwtJYCQAVUf5tZ/yL9r2F/M/q3yXs8R7vuUpTpWtdtX/AIx+l6tRw8eirvGThxpqs40uFtZINR0/o0NEU7cKpv4NvYvP069mGpD3y7P8/wCf+6qtNv0/E9G2zObj7h+aSZWf0GtPv/JFPAe23bWU8wbk0JISPUta6VFd/HUk9vJuErts9bcg15TOfyl2ksNokS02OL8tGaK3JBWnYAddzoQ27uqfQ5q3k0YUIIeD2q/45es4k2VDUC6PfKWBCqEJYSSOfh1I661D+J4+CYOjD2B46pAc8sbdtv8AcGG0e22lwltIG2/lqUjqlwk4uIXzi+JxbkHHp4UlpO6V1ommonBTtcXIsS+x8WXbo0y1yC4twAqb2qmvnQ6DfdFpoU1Zj+QqChfe+3lzsspMagddrVISKmnlTRHqB2oQEsDmHjuqvPtdwt9UvxFpO38J8dbiVmyi9B7dSvmBdpMBwpjEocXtVXh57DW4DSvGRwCKOItyPdYcSoqkOrCguu9a6aWzWhoVOy81SSei0AwywqnYhJWpI/Uy16ADQg0662ubcNFR1S7E5QXrtPiadVwY9IyPG7PcHLm+sKCiGyup9OlLW6qxSzSteKKVtmQRJ1mk3a6QmJKkEmqmxVQ/Zon1KrZ8zhMqzeMcwPJbW1dJlvbjKWqoUEgV31q5tWrZt3R+qgbx2Ltl1gRVWOeYxcHJIQsD7NidQsh6pi+6Dm0CE907SZxjz/KIoTeB9K1ihoPiK6l4qFjlL2GP3OHvJaxO4XEND8wRm/dIA8htocsbyqSphzc0gCqLnbqXdGRKFwhSrfJpRUaUlbCgR8FBOtpjFxGtUdiC5tQRREdV7cQ2hts0dJqQVcv2V1oyMO2TG6uOIV8tXzi4bUiSOYKSUk/HUT91iFnMVUeZiW7gltqgIqenWutw2uqjkdQ0XeyIs1S0vI4mqqV+Gp2u6KIjSq+orLT7xYQoAEEFNaVI8NbqAbrsudpSWEcVDkpPqUOop4a1rqjC2oQ7ueOLdUV7ADoRvrZ0lAhHW/Iqo3K3qaYQ2RyQokK2prLTyWJm8AhrlWKPsxf1CFGK0FslQbrXbrSn9Ws8GuUDi4aoLY/3ByLEr2HLXcnbKlxIqgqUUFQPUg7V1FNaNIqt7bJlruKajH/qYyuQ0iBMeivuOIHvXAHjXbwA2roBsLm7Jv8ANNfuibZ8+sr6ESH5TS3nfW6VKFeXXRcHtS+eNvKoTA2y9MZPjYjrvLT0B4H5mrgR7YB6KNdkgDUrm+fRYMoDaFC9lcaRcnnILhMRpSkxnjty4mlfv66JY1AFw5aIo2+Y61EaBUT/ABVGoJGqZrkYMU+XuURxuU2FtrFCk761h2WsbuQQE72fTtaMrjSZdviJTJIKmnKVIVTqKHW3KiHfEa6LPptvPOx2QOuKZcVbfcCFKKVBpdNuvgRrINStASzVPP2R71sZg+206eDhAHXx8QQdaFnmRDJeSfaE+zKZbCVBXNAqBQ6kpRTgVXneZEG22qU56QooJOtmbrchoGipfbW4RpM+U624kk7feTrzkPbO86NnuNk06fv1CjF9rI4enc+WvLy8klQ36V1heXuCabknau+sLyirwlJimor6SdSMWHbISXBFYz3E7moP2UOij8KiAVBt0YlboAooEkagbutuKJEGO2mCtPGqylW4+zUoNVjogre2aTXytPKizRWtLlnkS2TqumwywlS0tukcduHx0gYdSEC00NUQo8v3kcXSVJJAOt+ClY+rk7eJCsKNx/D7aCP/AERohoo1PofgCuZTv11qpmr4KT5a8tl8OpBbUD4A62WxSn9/sNkZJjc+DGWW3VqDoUkEiiNzzpvTW7BrVLL6MubosppeEzoF+kGfGUWre4UPNIPqWlYoQlXQUCq18tHxyckghtzyR5xrsvil7xCJcX2ZV0fmbqKVcPZKVkcOI6keZ1qXcXJkbBrm7pX8g7TT7ZmUmzxZCFsIdL7CHNz7TJ5KJHlQU89EtdySqWy4up0Wz3anMsYk4RBlR324y4EdDFwjObe0tCOJSoeIqKinhpfcMoaqyWU8bI6dVnp9SF87g9zsmudpsFvZh4y1KbQxPaBU9IQlAUfcUoji3XcgdaDWrPPold1zld5VO9qsKtEJlEe4XBlRkRWjJC6IHuJqFktmleVQQdDXFp5SUdZ06qF7xY9EjxUmE6UH2z7Q3AK96enqBQar7HUkoprsAjyqG7J4xjs2Kp65fJt3QSEuS0y1ISVs02KC5QU8SNGXDlHZtaAaoidxZVrZZeRar3HmvNLSm3sMPBQQhJAUvinoPt0rdGC6pRd5I3iAFyO3a2/oDjz6nUvvte0hhIVUE+BI2I16gc/TZe0awDqlguT0hibPekqbTHlrKW0nYqTXatPEacQQ9UtEha+qBGe3CK5NW4ElIabKOIAoTvSm+m0ESHuJKqiY1eGoExqQpoOUIKUkjr0pXW8zKhCRP4lEi5Z8lEqCzBg/JuSFgSnAsKJB8BQbffoH5UFpqiXTg7omdtG7LLzvFZV3T8jZUzk/OSJPrUVK6LFagcCBvpZmQ8Wrgzfiae+iZ40sMja7VH4rcW3PW62WaG5GlGTHQylUZ2ooUkClPhr5b7nyIsC58g8/5rqtqz1GgN2VOyTPvk4D1XVJKQfWPH79c0nzV9kgIyaN9m6smOwglk0CFRzODkNtLkeUhcyOSh1tJ9Qp4KGg/wC2PtpKOGhVlZinW0mo0VaYyqTbHgsKNEmgT5DRz8e2UUTGXGskYro5eo0+Ei6NKQVHZ+o3SoDSttq6N/pn6koitSyTir/g+UJeCIUhwONvHiPIeX7dWLt7IusLgQu/1b3D6j/FI8zjS0+o3ouW/wD09dnbvfJORXfGLfcL9cFJddkykBwlQGxoT4fv19YYiWNtqGxvppqFTG8Q/m5ldUF8h7R9tLdkc6Pc8Isd9QhKVxOcZtPtJp+EUG+ud5P9w24a7MbQ5yu0GMtcjbgltEnHc76V+3OVy59zsludwqcAtZMNSTEJ/hHtEcaeeirP95XNcC6ImvSoUF1+2tldR0DuLkmVn+mfLbb3BtFoyrGJl1xWY9SXc7b6/wDDnYuoKRtxJrQjXQJv3KsprEzNPCTeh006rnVz2Q6xn9OnJvitJOz/ANIxwuazcEXEvwYMgLtySko5MKAKSoeKiOoOuM9wfvXPcWr4om0oackzsu2IIZg5wTwRrJb4LA4MAqGyiKVUetKba+frzJXF3IXyvLifE/T9FbmUj0aFdrR8hHtuQLChyRb21Otjcik2NTp8aatHbM0cdnfPNS4W4r/+at6fkgLt0jpYq/5z/wBR644t2t05txp5CSlaSgpX03235eejMJ3Q6KXhKOIPWui3nsnU8Qgx/wAOnaj+af5o/lC3f3vz/wAr/wDi3zvL++9qvDlT4a6F/wDuBcfJ+j6vl5b16JN/aovW5cfuX+VNuyPPVUlk7JCqb0orcfu19ZiQCipZsZHahNUzEVG+nfs42pASRn2fEJPkYGKf6NNLPV5p7PzVW7hYY2NB9v5K34tAfkuQmWlJ9x78QCqcfKtD5adlnFtarld0DLJwaNSaBWHN7Fe59yx3BLc8t57I3G2ktBa6e2FeokAmlAT9uhLxw4VATrt/FTR3Aa86H7PsTh5jj+NYf2ztuLLmFN1tqWksQaDkKjdXxT5HSSGIvq5y65cn0Wtib00WVXdqIP5kLTKCpx9RqBv1IpqRgq2pKUSt/qaKKuT36RBg25irTxAefcPT09B9+tWUJ1U0zvSboFMWzP7tbYSuMjk6RRIBpT9+onWbXmpC3gyDmtXMxlMu43NuZPUp4g1Cx4nXnWxYKBbMvw59XIlpyrGZURTEyK269x9Sykbbeelpt5A8GqdtvIHRkOArRAi4QodwvC3LexxbccolIG3XT22hBbruqpfXjBWmyYzCMQbhMsTJbQC0pBQk6bW8XEarlOayxlcWMKPWJ5WbZPTEEgJQ76FJNPDoNES8XMIoleIfJa3LXs0DtD+SMCFQcstEmMeAcAOw9Nf6dIONHrshaAA466If5Ji8i1Yu5HhpNSqlE7+OskAbIJ7S51QqxIiyI+NwYxqSojmPjUawHGi1+X5PBI6K2h1+O7aGEk1NOXUV1nlRTtj+L2KddubyshaZWtRZ9sflq3TUeYOsclMxruKLXb3u5CwmZMYm4zHu0UnmHkH2nkk7EV6HQU8PIkpnZXfBvEo/WvvF2Oy1n2r3BTaXVnjxmx0qSD4+tIP7dAm2INQmkd3G48dl8z+xXZ3O1omY3cmmJPL3ELt8oA7/APwzoiN749itboRkalQt37NXKwREw4NyRNbQClj308XDXbcp2/drQzGuqIiADfIapfLxhGa2e6mVJx+Q5ER1ej0dTT7t9GC4ZxQzonvdWlFFIyG1wHlMzD8o+s+pDqeKgU7HYjXmEuFQt6Bujl+Vf7VDlMOplI/OUFVqNER16oORzWuVoevkCQlKEPpKlbqII3rrzm66KSOeqhbjLaR6Q4Ekio+zUVCdCjNAKql31aF25QQPWQanx1M0U2QlyAQuzCIMm/20QVte8404pBATvQ7f0a1uZRGdELbAyt1S09/e1TuMsPz0xi0lCwsVBT1O+pGTB7UHPacH1CWWG++whJCvWkE1BO33DW3CqmbUNrVWODfpUZ1Li5KxRQopSug/0a0dFRbNm8SjniWbwy42xKlFIJFQ2v0r+1FaHWrdFIQxwqmnsOZWZmKzykIHP8ANOmiGSV0UD2NbqiInMbaITftPgmnI0I6aw9pKhMlNkVcC7k2dI9pchAJIHE08vjrWKM0Ucdy1hoUzFlnwLjF+YDbb7ZpUnidvhqGTylMYSH6hKD9R0TFLpbZkdiIly4JQqkZCKkmp6Hz1hjtUHfuDNgsvLTfr525yQTLc4WlMro9FJVxUmtdx4HRLW1S+K4WtHYzvFCy2yxpCpf5iEf4iOVetsnwO++sOGqbQSBwRWzec1NtUj5eQUpWg1KTWm2sx7rEp47IB9t8suVjvsqG46l1hSuSF78gB5jU4a07hCRTcXJm0ZfMmV+VBSodQev3agLW+CKbK49V7RsyuMSQlE9oobVsl3cjWjwOinYXdUTLbeotyQFNuJqoA7Hz1GpgVPbEbaxReUNeF0jKHkk6kYtX7ITS1kMPKSKp5UNfI6KpULRqj8JiQZV0cYfe9lRJolRArv5nQMsnpoyJoO6JeRW2NChp9t2iiRslQFQdj01tA4kqO4h4jRLPmL7cD31qqUgmiia/HfTCRnJiRTO4gpeHe7SLbNcbaZWqh4kBPXfSn+3Fx0SV1yQVe7X3AvFxSiRDjqU2nipSFVG1RX92jG48NZ5t163uHOf7Fqz2+vEeZZbe/ySkrjtlYJ6HjuNL5GcDRXG3JcwIg/PM9QtKvs1D1RNKL7blNOn0np11leXuePn116qyqVlkeIuG8FgUcBStRFDQihAP2a9yNKKOQDiVlddYr17zW/SbCpss/qBjCK6rihSApLYWig2CeFNSxOLUm9Ml1AvW72TuDhsy4PWTJBaYklKVusMbstKBCSQFggcga1prcvqvPic3Yq/Yr2CvcyC3frjdFzLjyclxHnEqW46tYrxdcNNidzQdOmpYpiD7FmO3c9uqGOUdscrjXMMWufcMamPOuqmM26Q6huUVAEqKSfw7kD463kPNQPs3NPl0VqwzKsbDEIXda7ff22PlZNtmFSvmJDCeLSklY3KqCvmdRgCPVGQvEQ9qFufN5CxNxpUWQ3a/1GUXbwwltAcW2lNEjrVviaj060uJCGFayxFpq11KqRD4ucFq3B5VymyF8GfdKiloJqCVrVUn7a6p3mMhIUzWONAD71Cy8TmwECRLQ3FZWCIp5pKVkigCT8NGOJesSRFg02VStzPy0xyWqMp2JKPtr9tBNCk0CfHx1FK1tKHdRtaXkKZyK+GYwmLa4K2g2Q2ltaVcq1oVmhpU6HgjLXqScuqqXMwK7XVMqS6r3nVp5OkrCUN0FSAKUr56bifjRRNhLhUocJ7VpulzaEsBTfIe7uT4/CnSujHXvFvlNEO6Ch1Rme+mXFWIpkpDyFxG/dbfCvS4QAT02IJOlpyUg3JRHyMZGhQuyrtFbLNIYVHj8XSEuuuuqCgU7bJHka6nt8gZQQg7i1axwG68lW1qDHQ6xycDQ3CBWg/cNTO8/xHRHW7ABQaFWq1/Un3ct1lexWwOfP29hfswHpTQcfb/1Wyan7AQdUHuLsbC5Mme4IFNSTon1rn7pr228BJPsRWtGRd3IuH3G6dxJylJkj3rdHWlIdSgj8KuIH3ba4Vl7LCm/EONaOLdCQSQdB4kr6M/b20mLfUuz9vRL7ir3d27X43/F27gi3qnIFzcp+Utor9QAV5DVtvLCxZbenKyp4mlAd6eIR/cF26SakTtAdk+dwjKlQkPNu+sJSHada08fjrjcLwx9CFNDNyZQDVVJm6T4Ly4jUpQYcTR5s+J89MHW7JByI1Wr4da01V+xnJpEBwOF0I4kcfEkp8dK7u0qQW7jVLLyIStLXDdMrjHdLFbq+yH3lPT46EpuSBQhCa7rofD7Ndj7FzjeAbcA8wN/zCod9iJ21bGdDsEGMq7x4LIk5deEw0O22xrcjxrgDw9wNkA0p8TtonMY7FZK4c92p+nsV0xXbN8yOKriCRUhQBk4Dltigxmbsq3T7ytBhBawApR3KR8Pt1VGYy1xUpumO8vQHWlN99d96qS9tb2J55NNAin2x7UxcflvXK43F+fIUOHBa+TQSNxQaXXuZgyLySBQdfYPuVSyF9IW8K1FdkVb9cIURj24aUtpGygOm3lrnedyUN0RBbto0b06oaxt5JXVfqhlAkypEx92RK5wgDxQTx4kaUTMa1gDR5lYJ4GxgAN1UwzlFntNhzWTEeCjDtLbr6irlublBa/pc1Z+3LCWa2v2uG9u0D/8zbn8kvlsZHTQF+xkIH/lyH8koOUd5Zy5ym4LhZbrTlWnj1r8NOLDtlgZV+qtTbGPjQhfP+eF2/Rvk/nfz/w8uR6U89bf8LR+rWmm9EF/b4/UposG2JAZix6JTuw0VV67o19qGoK5hYlvpajomCedbV2K7LJe2adz3Pgv/wCwMUpp3jyRU+781z3ueATPDa03UnZMmi41cPcYjNTVMJ9SzuOm2mDrknRVGLDRxnnuRsojCu4l0R3Qcy1hYkyIZVHtrDg5ITy6cRtSm+m9pbi5YQs3Fx8m5r6dU4PerIXrj2keyP0DJfSVvpTvwGxB8qaU3UXo8mhW61l+b4v8VnnCuC38htl6vzRkxmVBTyaVr+zVefccW8etU6GKcXc9KUR6uN67UX4NNhktvFA5pLYWkbb9dRMlcCpJrVhFCFWHe3+DXUqVb5sdJVu2kK9o0Phv462ZduB1QosGAUVYuPaKVFVW3SVqQo+gBQWP3aIbe13BQcuM1q2ipM7t/lEVSilkvp8RWiv2Eambcs3KEdYyjYKxYDi8hV0C7hFU37BqEqG32jTiyYHeYbLnvcl6YGFgOqYeU+1CjLXVKEgUSDQdNM9AFzqJhlfRLte79dJl3V+jlxxTa6j26kkg/DQUj/NULomPsI44h6m6Z7snfr1Nh3F27NqjrhIPoIIqaeNdBTEJ3DI8v1NWj7UeLDf416tsxp8IUhhSvxCtaahJTCMhm64nbbGuKG1tBKkNK9KRsK6iIKNhaPiXdLsCTLgPII/LBB3/AKNakUC2ZDXkdFGrgPKvwCm6pp+KmtOSmZFpRdKrMCuXVNCoU38te1KJjt2gVO6jnYcSPE4inJPUHofu1q6qidbt5VVTkXafarg1Ltcx63vMp5e8wtSFDy3B1uwN6oHJsLm0aVGo+pzuRYb2lprIX5iI1Bxl0eQoeINd/wB+lc0jSdAVYsRYSMi5VBR+xr60VSlR4mR4kxLSrilyZCX7a+u/pNdadEYHnl5kEvqi7j2C+26BPxu3PQ5Cn0uldAHU7fhIT4aKtZCCPBBZCgaSEtGLXHLcreaRFRJebC+PuGvp0zMoAqk0cMkhrui+8nMbEWkuNuvrSACSCOvmdR/MMKN9LgNdCvGXlF6UtAkJcbKQKpAPh8dea9pO6hdI52gXr/NjrzftqPIjqFg6IaW+K0m9QBMV2Avcb5t4SnG0lSiRWnWug74Bx0W1keI1Xd9U0WHc8WnPpWkBDal1FOoGwGsWwOy1u5DXxWSLU9SAQoer8KiQd9NGjjugRKTvsulC1yAopCh5UrrY0Kjc9p2cPvXzDdnRpqSyDUq9SleGsFrVhrnV0KY/G4GQXKEhxKFOpbSC2anrTy1EG66Lz5jsV23TJb9irAMkrKQCAlSdq+XLfRDRVBy3PHoV99ss9mXzImzIWlAYcHJqvEmnlTUoDQCk916rpW0NAVqn2w7hY1NnxMelhxEya2Ay2qnEqSKUG9KnSm8Baa9FcsaaAAnVH289nbRfogfjoAdpso7pJPhTwOgGz1TaezbIkY75fSnLfjvXa2RFLnRvWsNp9KkeIoNbsu9aJXPjaCoSbxLPn/ayYLxamn0NNCklihFU9eKk6NZJUIaKN0e6YTGvqOiXe3O2+4cYc1aQmQ2rrWlD+/UnKin5tdoUVu3wYuspyWh1DqlpBQtJ8Ca6ma9DGHVNRjMMJktjryG5P2aiKIiZRFGbj8SVECXGhz6DWjkaCCqjb7Fc7TOSYrpXGJP5ZPQV6awtaGqLUYO+0kuJIJSCdYWy4bokOMlJGt26LDhUIHZdcYlojyitwNJ+2tCTTpqR0mmiiGiHWOz3pssSW+SkAkg9KitK00HI3kjoyGjVFHjM9kqefUUjdIUdtEQsLUNI9zt0Ocot7d0eVEWUkLAr9+2ipJKNQT7f1DRfeOdhbJcWhIeQhTgIqoCo+GgRdOapGYpg+KhRtx3sxZIbDrRQgFWw2OtfnHlENxsTdgizabO/ZWREYfJZSKJFegptTQ0klSimQ8RRToVOCCPmVjbzpqMGpUnCq7MbemInuNuyFOJJBoo11kuooy0hFdqnAFW9Qd9eWFXcgtX6nEdaJ4oKSCfH7tepqtHioSdXftxZ8ausu4NRCyv5gPwyyqhPuKqtBBrWqvVrdxQzYeJqh93XtWWXaxSkWbHVpVNjrTNlFaVeyArcJBpupO41pyUNxU7JseyiYxwWwwlOfMJhQmmkuLNVEpQAak7k11mpIU1lXgAUPO7dud+bCreh5ya6oJbDQA2SK0KhujUzH0FFtJo5I1lfbeRe5Ts+5JuCpkUe22lz3E8HAoqSpCUgKJJNOXXbU4od0u9Ivcq/HwDuiu+M229RnH7c2WhCLiQp0qeCaqKvxVRXfUT6P0WrYSD5kVo3bC42mbEeYbkyZjiBHehKQU+lawklBNBWu5J0M6zaAj2MDCKdUSsk7cXtNrQLjaW5EWzoLkJBWeXMihW4KUISOgGoY4mtcKhSSAnRUHDrbjrck2C6uRmrnGJkyYg3I9wkioHQnrQ6rOYEgkq0aKaB8TfKd0Lu70a043IU+ytTS1H3IiEAAEA/hNTX4117HB76VK0vHRtJpqg4x3Wl/MRrezbC4y4U/OMCoS6KDxA89O5YtEr+ZDRsaK+Xe7tIht3CMWmXHwPbapu0KEqKyadToQAk0oo7icEaGiHV2zDJ3beyyxeJCmoygW2krHEcdwnj4ivnohkEbncXaIQSHkBqaq42PtL3hzuyN35FsMpl8co8ZauC1IrsE12+Ol0+TtLV5ankOInmAIX6/due4OMQXWbxj0gtNprRgBahUePHqND/APENsdnU96nfiLlg+GvuV37I9rFJuT+Q3qJVqOfcjtlNA2unQggV1xD91e9o7gNtLV3+lTY+7810Psft4wH1pm6naqYxnDXO5V2XEbHu2y2OpPseDpSd608BpX+2naz7yUXEg8jTrvqf0XTMtmW4u241o91dunvVZ7/3q4YVj0yVZYcew2Swo9l+REZC3JDtAClKEAnata6+gsz27bRhkjqUP4Lk9hn7q4kkoakFKf8AS/3DvOeXnuBHkyJUy1wG2nmHpYofcWTySB4bU2OuDfuZh7WwML4QByJ28P8AFXztLKzzylsgKPl0aU5LU6EU4+P/AGaokDgG0XSZ20CjGrs3EUgPL9kOupbQpXmo0AGimWbp3BrdSVX76T02F1F4z3L9Y2b1Lg2iQp0+6YUpSvYKipA5o5EbpruNdJte2JrFjZHCp0+xV6xykb36uFQdK+KU/KpGTR8RmYzFhy0G+TW3nmqc6Aq5r/MA6FQGmds6KAn1AB113oNl3LDTMuo2zchVoRf7Zx5MS5460/d4j7tsbaZfS+ripvcFRIWa1+I1Q8/IHxPo00NSKfglnceTZLG5oAr4rUiHeYse0MFCklK2woOJP4hTY18jriJnnDHQDQcvr9y4hLaGSdBvJcpQp1fOQWm0E7V6/DTaxsCBoFbrHHiNlSg3eM3lrU43DcLKFGhKVeHnTVmtsU0ULhVG+hGRV2qpdtzEzLL3ls0W4tyJ8XC48sR+f5iQcksjfIpr09euidv4vjbXUhaeJjA2/wDnRH8kmv7mI3FsxpFfUP8AspB+aVmQjMI7oXd32CzINYxSo1CT/a8ttHNNo4UjBqN1YP7fKBXkDXwqpf5gfL+38w17/wCLhzRXpTpobh5q0NFF/bnV9qzKbhh6FGUHklQYRzSOooBT+nX0md1xO3HGL6kd7ikp7BdmQrqM8z//APl+KabWZ3+pUPNmsg+tVcsvC2y3IqS68WyaAEqFBvpi2PmkrjQKawTHUx4ESdc1uWxxThdU8QN/EUrT7NWHFu9JhqleTx5moQd0y+WOysswZvHYCktCSlHvPqBBUPH4Enxpqt5C85vcParRiIDAxoPghHbey1wuDDkeDLDkyOKe3Suw6nz1XJWmtVeLe/YW8SqLeu3l9x2YTcbYoNJSSX0UVuOh2314LEjmv2VfjW6SFuLYfU1Q7JrqWoQnoFWu3P36K426ZKl0pQBRG39GsAAmi0dBIDUIv4vepD6lpu4Qtviae7x8Ogroe4icHABbC69EcnjQLhTIhmXdrg00hppKihCU0oOI3p9+rvjIC2EEr5y7ouPmr93HYlCXJchk3dTlvhKJWlRT6fEV8NSSSI7GY5sFHuG6L/Y/CGrbJfuN8ZS6+43yjoUAeNd/26Xvl6K2ttSTzO2yI14H8uxrs6y0lpMlRVVvoa6BkkKNjgCrmLXz5Kw3GQtziXFGgr563YeS3nHFXGyX55GPJlIXzC1E1r031M5izG4k0V/iZK05Et5dUCtVACToR7taJmyMtouu43WO1cYpbHJSweVD4a0RbWrweu/J95KBsEnfy21oXIkN0VTcmB1CgdypdP36y01KheNFA3pLTRUkAlakHRTWpLO/kaIG3uEyqXJdEctjjQGnVXjpG9uquFhcgQUVi7b2pE67MJdaC2uQC0qpQGu22tiKBbSmtD7ExmcdtIVzszklLCdkgoISCKp28N9bwISYBw12QP7cTZVryNy0W6AkvQXKvpSBxVXxJPTU8r6NWtpG9zqRJwocFy5rS3MgtvhYopIArXqRpTJkI2aHdWaPB3coDvTrXr9AvK5doWrq2XG4AY2JIA/ZqBuYiBUru1Ll41ZxQdvXalyG4tDbJUobFKhTp92mkF5HIq/dYqWA0KoLlmyPFX/mbWhTNOgG3U/HR0cldSk8kNNAh53CynL75b3LbcVPe1TiUJ3qCOu2pmXDa6dFBJayEUHVAqJgsmWkBiI6+pRoQlClbnyoNZmzDGaHZb2vbtzM4U1Ph4q92ztXefmExhaJBdcQFBHBQ28zUaEkz0AT2Hs69P8A4X0+xe07B/0wqZlMGPJbBVxWkg/9ep4Mi2VocNilORwslq8teKOHT6le8RydywBmPPaHs1ADp39Pwp0+/RrbgJE+OiNq7JivcCAptK2kvuIIKSRUk9OupmzhQutw5BO9/TxkmOSjecUkKStBqlCKn+jw1KXIaSycRvsqJLyrunYblFlPxX4863OpWxIYCure9TQjUElHAgqSH1GuB8FoP2o+vadFt8K15tZnH5DQCFzkKHJYoAPD9x/bpQ+34lWSHIClCnOt31DdusutTb36iIinUAqZeSQR8CRtoR2hTOORsjUOMiunbTKG37cJEB1+SCAUlBVv9mjonaBBzxtqQEk3dX6cnWVu33GULaX/AHnFHQg/YN66I5JVNbkaqC7VdznsHlqs2TRjFe/u2pC+h4neupWuWGO47p+sGz62XdUeVGkJcQUipTuP6dRsfUohoTMwL1ClRmyXQQR6T8dSOUtKLoEhrnWqVcRRJPlrVeXUzNQ7slW3TbXl5fE6gZUodR0+O3XWwWeiSPuw/eZN6+TjN1ZDgKj571T47a87ZRBvI0RFwyzPNN292SsIedTu2keGxNRrZjKqR7CAiZkDSY9tUtA9SU7Cm/TW7Vo5BViS6/M5KIIIFfuPjrW4aSFo00cmOwJaGozfIAoUap+AVpYWnVHctkVkON+tbWw+GvBb8lFS7x8s8lDi6UFSdb8K6rHJVO99x7XZ6qlSUNgdVq26ddZEaw6TiKqZ7cZ5Zssnyv0+Y277BSk8Vee+tHNWBMCmQZWhTTY5Dcba1WF9uJ5oISakim2sheQ8u+J/qExuQ4Ar2FcmuYrv02p8NtbKNSxxe3vRFx3WGzyFFjjWu3TfWahecAV8WjGW7UgtRUpjspJKUoASnf4DWpWWNDdQuz+XYz7vuykJU4g/luKSNvDbXq0WSzkapW++8mx4SYN/ddMd75lEdhSKmq1KKvV9oFNSscgrkemKq54jIx/KZFple269Kkxg7ISUKBQVbbnwI8Rrx0Usb2yBEjJMXU1CW9BSDITRbaimqqIII66wJfFb8fuXSmTbZUFKJCWkvOs8XuQAooda8takgqVj2uBBSyZH2uOQ5JGXi0dtMxLy3b3cYqAqjJVQLV059OgOhpzG9vAjVCvs2E1CHvc/6ZBInNKOUJlP3B9TVtiiK6oqojk6CeRKEoFPUR8NDWuP4OQ0tsa76Kn2z6erHYrJNTnV4/lieri1aIcdtmYZLdDyUlAWFgoPUHw1tcwvrRu6NhtGFvmQ5vnZ7HXI64ttz1VpfLCVR4t4tq46HnDWqVvJWUtkbcaimlc7pYRVaOxEc5oF69rfp2ydWYQ4GeQYqLE8z8zFlMSmnm5Q5en21pNT8dLMrfOEPNu6Ox2FDXVd0Wo1gxWDYbfHt0RsMx46AlpFOiRsNUFzC/zynfZW71eAAYNAuW84zap0eSH0IKihQSojoSNVfLxMbE/i414n8EZbXzwQSNihBgWPWe8ZTIxma43GiIYceLI9BfKVBPGo+2uucft524zuHJMZMfKByP1U0Vnz+QltLRs8Q/guXOsjg9ku3XcXMMax9d1lRPcj2i2xKOKLiTwBKh0CSCpROvsrEYi3xTGQQNAbr+Oq5lk8pLkWmWQ6iizOjd5c3u+Eycvjst5Te8nnuW9u0uJKmba0gFSqo3J6VJpudLLuV99cOif8LU2tbIWlo2aP4nfgpz6acczOPPznI79hz+PIuQDD7jUZbUZ5bRqlxAKd+QOuOfvFjXRC3cBVqunaORie/i7RyL2Tqba90FZZKUkmhoennrk1gCadV1IygtVXi2u04/bUZTlTr1zQlQk2yACSlJG6FKA6nbTMXc804itaNcN3JSyA3b+J+DqunB/qHw/OMnkY/d4rluW4j2beH0cYy1DcpKVdCabEa7Hj73JWTGi/PJppQ0/FJ852VAwc7Y0O6tMvArLl13vV7j3KNaLFjcbndJgV+Uj26qWUgHyGq1JbTZu+kbAQGj602tL7+0WjGOJJchHbbp9Ovc+9XCyQs2cbvVtjmS1eJDbbUZSEq48Q4Ak7nTO37TmtIHkvI41Ps+xBX92+40ArsmpmXNdksVti/NJdbbjIaYdQqqXEpTQKTv0I318+i1Ety/8A0j+KmsrdlaHdAS93SXKkPBDilBRqDWoGrZa27WNGifcBxoEI85ziw4dHgv5PcjEZuDqY/wCWmqwFbFwJqDQatOBw0mSn9OIaDcqtZzMw41nF25QsOC3DCcZ+ojvLgeUryWDcO31uTDS6r3VNrGb4tIUgqHVBaacBFKga79joIY4zaFo8o1+0LlN3NKJGXbTpy/Frj+FVQ7Hf80+oO6J9i5R8Xt0ZlCkxWq8Ut0opRVsST4arzsPEbotYwFx8en1LsVvlP7ZjReTGocPyTc/5BYX/ACR8p+qt/rHD3P5m91Xu+7xpTr0rqr/8PZz+5009H3afZ/FI/wDjy0p6ix3sku2ymokd6rLrbSEE7AE8ddqLdVz7HTRehQ+COmVuxLd2F7QIK+Las8z6hr/+QYodN7HQqhdwNZ6nk2Ul2CxuZ3Izldisb7CwxGVIkpkGifbGyiAN9vHR88nEVCRW0XJ4BRa7xYkziVgbucmdGMZMz5VLDCkq/MqEcU0JNKDx0UzJH0qIu9iDXNoop/LmrBarKtEVUluR7TTQCSaClCT5U0jc/k8nxTBvwhMT2Il2q6XO7SHYtD7aT7hBBSTTxrtoGc0KZ2Taohd7rJZI2B3e5KaTzYaUppziCsVHUKG+h+ZTNuizMs1wtjinQt0INa+rp/TojgsMuOW6v8f5N4t+0ttYUR01o9pGymc9oC5s2bdttpaejSPYC6hdKbp+GjLIHkKpH3GP92dTeioF4yQItUO2wD7ji2h7y0nqadTq1CUBlFxewxbpJ3PcOuiq2J5VZsdvXzF6o6hro2d966ALxSgVuZjiSHFH6N32wthta2HEpeWKBsEppttoZHOt6gD2ruxbP7JmEiZAus1CGj/dKUsUNfgToZvxI5sAAVrvOJwHbP7FquzKkKUT6T0r0rouMNBQNzayvXNbMotOKxo1muvFxolKC6PM7En4axO8dERYWLmGr0RJdrYuDsGXbHgIY9XFJqPOo0CW8irDKBwUq9a32nUXJ9wKS0gBDfTWHmgooYm1UOuY8VSnigjl6E/ZqBpKKrwC8lMlKY7q/Rx9RJ+J1MC8/ChXMMjqhRD74m3hpgJ9xISeSU710SPIKuKRZCMyTceJKlJOP2mYlTa2S08BUlX79KZuB1Dkfb/NRxU4FW/tpgTkq9oZisKTH5pLsoJqEgHSu9yTLZupVtwGIucjICRRo0P4pxl9tmvlVRVzlKiOp/MbKU7bfw+WqlN3v6dWhX6Ds60Dv6gqOo8UtOb9npGJLu2T4w8DKUOamCN1cR0FB1OlEneUlyeNNF0btftnFxygBlPp7lXu0ndlp24iFd0hFwqQ62vb1A0NK+WkmRfdOcXNNWdF0vKduxmD+hsOngn4s+QY9NhN+4UBa0A0JA0tiyBrw6hclvLC6ik8u1V6SMVsmSx3mWQ2XFA8CD6v26d4zOmIpPkIA8UlCrkL6erNKbcXfbs8hCllTKEBA4/6vq1Z7rvCeDdUO57fhMnk1Vbd7GYFZ5Er5ttM9DuzapASoj7KDSK/70lkFK9FbMPh4YBo2pKlLVhmBWdjja7LG9KwCpttP3701VJcxLLU9FZo2vYSGigUuu3YouRwLcVuVxpxCUig+PTQv9xciWm4aOQBoqHln0/4xnz0eYtTaXY5JbLKggk+SqdRqxYTOSw+wJTkvlrocbtpSe96ew0jt7GVd4iTKtSNnwRu1U0/ZrpuE7l+Y8kh0/NUDuDtOMx+rbfCDWiWaPcHba4JNtnFhQNSjwIHnTV3ik8vJq5ZPbEEyv0eOiL2K/UYLOG7fk0ZKmj6VSU/hA+O50XC8kIP1OJonA7at9sO54bKVRVSZKatJWB6q+AOobkkiqZW0fNXLNPouxbJWVy7R/ui4cTweYFEK/20030m9dzHaIuXHhwqN0uk76Zu5GJLciMj5yCnZqSxWtPiKalFyXbqBlpKzZCq9ds+4OJXFm8xRMkNoX+elAVVIrU0pQ6lZKEJOyTkap0e2eV/qtibiXrmp5CQhfvpptQbGu+p/XACJii8qFHdjtNbsple5bGQzIdUSkpFKmvgdY+ZCjktuSH9nwPuD2+bMi2OurbaNfZIJBA6impjJzURjcESsa753OE8i2XY/JSa0PKqBU+ArrLpaLeLwKO9n7nyLixyQ4hYO5cKj+07609UotsLSKq6Qs4W2ApTqVJpVXHf9tde9UrX0gpy29x4kx4RHlqbKqhK6ddbic0ovcOihMnbtLrDs5QZSsmvuqIBTv4Hz1guLlM1rW6od2LubjkSW7FeuLXvxyUJQpYURQ9ag6IjYgJHt5K/LzO2XuA4hmS2orBAVyHholrVC+UFDZc1EZx32yFKUo8FDfr4bazKyrVA12qJeJ3W5KQ2ijjaQognfjT9ulgHCoR8bahMFj8t5MakleyvwqPjrLVKNFHXVhUh73EVLIPUb/u1MFo81KWzurjsmTHfcZWHylJLbQrWtdtSRuoaoeWEuCjfpkTcYGXXmDLT7bzrTb0VIHp4pJSob+O/TUExqtbdvArS+CiUplhakg0HRJ0GjlYGQoIHIUOvLy9OPLr18NeXl8mldvv15eX8Cd668vLjmPBptaVEJ22J6a9yostDifLulX7wdwO2+Gpj3TO7rEbbQpKocB3i64pVdihk1JJNBUCo1JHHXUoO5McWrtSqng/dzO+5VrnTu0/aS4R4xfcZhZXe3G4Vvd4Ir7nAguqAV6dk6zQBaNna4f0wimrKPqHtlpnzL72wst9NvbQExLNdCZL4p6y2h1pKSBvtyGtvK4hZc66b7kvF3+rTtzFulhtPcjGsq7eKuSgplqZBIQ86lzhw90VQUg0rvr1zEGxlx6AlSQztc9rT8RIA96PN676YliZQzZrc2/GyFhLpcQeClDiEinEGgAOuc33djbeX0w00XRcd2ebuPmXCqV97Ku4F5vc5WVdwZl3x1h9ItePwQiEgxweSWpUhgB100NFHl08NO7HMMfHzA1Kgl7WMMhBOiWT6he/NpyXMrJhpwQ3uU2yYWM49CVyW3uAVl3Zzms+PLpre3tbm9dUfChb29s8U3037lE/s92f705fKmW+/wLh267cpYZUpNykqmypDgqpUdlMj3QlA/iJ+46s8NrHEykiqMtx6z+UeyeJVrxKyW6LYI0CM7Bgn/CsgDilavxLR14lR3PEAay63gesh7mrgMn5Rot2q5TrcpRcLaUyHHAhShTkEOFQVQ0NDoC6wNndN4ObU9D4KaO8nYfLt1Qwldxe7+B8pObWFjOcX+YbbVkmLhXzcWOvYvS4C6qKUn8SmiaeWuSdyftRM4PktZKGhIHiegVls81EKNk3Kn7Dl9mmZJa7ta5aZMWfVDMuKoLI9zb8Sa0UCKEdQeuuFdptve2cy0TsPMHia11r1Hjr+fgujzWvzuOPFw40qjba+ycNgS1LyG4foF1QpUmyvlLjanXTyWuqxUFVdx019iw3ZmiD5B5iFx57WRPLI+hVQbtn069lvn2rVYre1c1hcuazFj/MvrUKqUtfEKCft21C+5ii8ztk5ssde3jgxnVCCb9dvbeNMMBvGrlIiDZQAaSOPhVCljw6aQzdx2sr+Dtgr9b/tRfGMTMOpXBfbt2t+pK0ujts9EgZ7Fj/OrtEhXsuORkH8xKm09VDVYzPa1nkWVsqeuNff1otrV+U7cmEOQB9M9fwWbX1BjuXYLtFRb5smPa4rYje0lJ4xn26UUU03FdVXtvHW1nM6K6Zxma6p9qv0l1FdWrjbSAEjRKN2+smcy80am3a8OT5L8pL/ADSokJ3JKgOidj0Guj90ZO2daDgdgqr2zjr9l0fmpKgnT6VTd5BMvsPt7cMdxqesXB1xxm6e6o1fbd/EFCo38BrluKufSvxM/RhHTZdRubZktuY3USlwcDz0stRrVYXoTDaSwoNAILgry9SupFddKuu5rEg8iASNev5Km22JjsHVjPUp+MMvF3Zx+w2O9XFyVOtERthZUokppsEnfeg231xLKW8Tp5JYm0a41TGvN1VeJ8yJDj/NTnkMsJSTzWoJFabCp0phjc93FgqVJcyR27eTis1O6l+yrvRfbszj78GRbsVdcVAgoP8AiS0BQkKBqQabDX0P2lh48PaiRwPJwBd9a4T3RfuyzjGDsTT6ijb9Fs2RfonfXt9fJzqscunb9Db9sJqlqS7lWPRUqSPAgvHXQJ4opbdsreoIP3H8lS8VPLBdthf/AC1I/D80K+3Tly7bdwL1jIBCYEx+DIbV1LaSQD+zVCycxtniYdCPxX0H23bNyeMki60ITke3mn8p/M+xJ+T+e5fMe3t7NK/spq4/3IfJev1XEv7NJ8/8p/y6LI2MYrrEVD6AwtDSeLqBQj07EnUprVHWzm+l4aI45VFS59PHZdKnvcQc/wA/q4rxBgYoK/u00tG1J+pU7Lvo7Rena9z+WcrgP2a4ORZTzCmnJUZxSHOCwOSapI66Pkjq3VJ7eSrlK91rgh6TDgCdIlNqnJWIjjqihCyRVVDXrqIUAojLonk1MHa4UZy1W9t9pCwhlHELAPh1B0E4HmU08vEJrPpltFpkycgRKi1ClD2iQADt4V66DkBrqmNi4NJp4IhfUNj1nt/bLI5hc/JajLV7PEp3A6bVGsOjaAmNeWyxvQ9i7xPFosqUOoXt/Rrb1gpG455FQpKM3D9xHyF1KFAj0KqfH7de9ZvVQusJ+oXhn02f+iBhUxToSDQpVUDbRcUzANEDfW8rhQjZAiHeZrCVRwvcinI7mhHnoj1OQpVVxtn6byeO6jpqVFJWo1KuquusjRSljmilNFFgoqKpBrTeldb8VBQqxcVMxA6ypTTgIIWglJFfs1GxlXKR0bqKat2c5Fb21JYucpFVeLhV+46irVZDHE7r3kZxeJe8t331J39wipr8dZLD0RPMjQ0TA9su6V3SwzDWnk2k8RzcoAPPfprLatNaLYu8uqLNwzyXPkxmW3UKAJ4JQoEKH3H4aHnaTqpLaUVoFfYGQxSww1OAb5IBKCKfv8det3VGqnu3gBQUjJ0XPIo2OQmz70hSUNLV4cjtt9+s3Nw2JpdtRZxsBupmRt3J19ybntx2VYx+6sXe8volPS294rlClJV12PlrmOd7peAeJGi7LiO07e3rJI3kR40RnvmF4bIWhkxI7a1gALCUg6pQ7plboHVT6PFQys1iCslksdjxxluNDbbPuitQBWv3aEyOYlnA16LeK2EbSI28QFz3a7v/AKvbLNbkh2Rc3UsNNDrVRpUnwp10js4nzTNiGpeaJjBbtbC+aTZor9ivmW41iuEw4S8xeemvy0jlHjNl0pKh1KR4DXY7PsiNlsHlx5fUqdH3VK4l0WgBolbu3YvtJ3EvKsgwi+Gx3CEr/HCMfbVzP/itK3rt11Wcham2e6E8uI66U8aq84vvO6iZRw50RZxb6doca2KeuHceQ97Z3b5tg/AbEHQ0Hb0Evn579AgMn39IZOAgbXxNf1RgtWH4rg0eO/dsm/TkODkw5LdCAUjxKl0Gm8XaTGDkwk++iqd73A+8dRrB9PrXFOv2M5Ap9ix5NHnzIw5JZadSsfuOkORtBODqahFWUM0QBkYKIAZzmAiKj26VKTGkOK4qPLcAdT46pl1A5nlqd10XDYn1AXhtQhDmffaLii2LVaUpkNsIHzspW/qI2AoN9MbOye4UYf4qw43tP5oufLVtNRSiVK8d88mevMifDlJabWfShXLp9yhTTuLt+Mtq8nl7FaGWVpAz0yAUXe3P1D3JtaY8uWfmVK35qPE/7J0tvcVLbAmMkgpZf9s2l62rRt4J2LHe8f7j2F6LefalvuNE+2qhCiRShB2PXUGPyfofETULl+VxUlhLQN8hNDVZM/ULgs7tVma1MUVYb4tx+K2DT26dUgeWvoDs/MR39vT+YLhX7gYU2dwLmOvpHdLbOlsTkhKWgXFK5cuW4GrpG0ALl8jg81R57E3m8W+7ttwpRiONqBbAJ4nfxFdC3DQU1sbh2xotU8a+onL8TjRWbvbGr5C4AFSVqS703pUEE6WOjCbes6qMVl+oft3lIaRLU5YplaLZmNkJqP8A4gBGh3QlStm9qIzKMOyRKSpcOQHBVpxJQUrr413rrUMcFlzmO96oeUYJZYyUvW1ltt0k/wB0kAK+NBqRrQ7QlR0psh5NsEyC2ZQiF5LSamg9Q8ajUbm02W7dVVU9xLGy85b7g6ws1oWXaJUmu29dEwOoopnsCDfcrH8ayEJnWz20y0r5VboKDzrolxIUIY1+xQfhQcntjzggz1rZTuGkk/u+GteayYiOqvNsumcsBJdQ5IYHRCgan7xr3P2LXi7wRDxCZkt2vASuL8ohvpQEmtPMkakiHIrLjQUVxz7HZz1nLsyY8FJBo0hRCSRv0G2jvSCCe4rPPJrFeGL3Jcgl9tCVVKkFQJJr1pqRoAS2UOrVTmM9xL/i9YEovKSTuV1Kd/Ku+pWOUHqOTPdrs4hXm4xmLgeIlOAV6ivxrqR56KSN5LgtAbVZojVtS80kLSRyKkjwppTcNo5Po6AKWYmthIabcQsDYJruNYY1RvfrRdheUUEcCPs1uVrrVVuZaW5iS4s05V5hW4prBqiGGu6reCxLLY81ltq4cpoQW3+hStCug8qio1G5DkeZPBalMGO2WqUAHE1PTrocogBStUb1Vx8eutarC5XJKEVCSFKANfgde5Be0XkzI5mh8dZXl2A+GvLyoHce/Rsaxm7XyYCWLfGW+viCr8ArQAVJJ8B4nWzaV1UcrnNb5d0n/Z3tMrJbtJ78d8rPGmXGY1ywXFZjYcRaoXLkh5aF7e84KE7eka9PcBoohcfj5JpKv1TXM9y7K5JYg2dKOKRVLbPQJ6GgFNtLIr0TGgVhfihFHypQqUn5XKXCfVDZeW4jZxaE14p6nz0xazhrVCiN2jTu5KxfO4XZ3NXHsSyyPAyBJcIftVxhLeKXUq3pVOxB8jqOXINpxITFvat1IPUAHippjDuzWXSbMmNEDDmPp9uFGgPuRihCeqSlRAUPu0tucXaTAO4iqIF5f46jSTRBXvV2mvOMWlvK+2uRvQ2ba8XHLRMSl6O8ipq28FHl6ugUOmoLm0ZbRtDWihTG1ybrsl3I1HRIr9G2MXLOvqGvHc3OIyY7GKyHfbt8hQW2zKUVo9pHxT+Ias9myOO1HpuJJ9yomWE93fcpWgAaafitRe7ffW3Y5EVFjymGZTaCVsuOpaQE0JCiVUruNt9Az3jWHzap9Z4t8rg2NuiRfIfrCtVmjqlLdEkkp5OukNIcUfxIQtVAqngU6AOQLjRgCsMXaMoaXSnh76KVxj6rMMySVEnQ8vtbT6w22i0znFRni4o0KBzok8fOu+iG3FwwcjQN603SOaCOKTg4mniBp94TYYf3EjX+S82yhyI+yAEoqlYUD1IUgnYny0RaXjJq0P1lC3FkYjyI8vQqh9zbRO7Uomd6u11shuTLapuXmWDSKNwJzDINZUYJKUsPpFSs/wAdP7WhrvCWF9I174wXD+amqh/ut3asIY48T0Kcft33WtveTAsay/HEOpj5FFK32XAD8sQKLCqHqCDSmjZ4WMdxA2oorKb1ow7rU/iuK/dv8em2SbZ4EhyFElpUbwG1cZMrkarBcAKtzoGazjkbQqw2WVmtXAt6JB+9nZGzKtL1twLFUQZjTnurucnmVkoFdlq3I+A1TsngY3E8G6+K7B2p3pM3SR+iV/6Y15FZ/qVxm0POBq6xZDzdybZPoDPtK51T4AUFd9D4u0da3QYzqNT1/RW/vq7t73Cuc6hd0PVaS/UvhmN5iy3HfhsCXLguOq9oFHJaD+LbxOmedx1u8h7gOfj1K4Z2tfSRDi7VtdzXRJri/Ze2Y4mHcH7SwPmFhTLoTVaABQk11yzuZ0oa1jRoTSuv2rtGPfE4cman29F19we0a8ltB/lECPlbr6PkX6BKEpSqqi6B1FND9v4aXl5i5zfArOVzQhiIdQFCzLrBnnay3W1WTOQrlEnrES4TICeDkdbmyXANyQPHVhvOy4AS9rnaa0VAiz8pkGxBPWqG+OXNuwzX0zphkS5DxTzcO5BOxNdVe/tnTto1tAFd4JQ5oPVDb6pM3lrxOFbrRMrGefT+pKZV6gkf2VDyOnn7fYuMXhfMNhoqb37cyx23lr9SUftXldhwm8vZDc5ocEaM8iNEaCgt9xY2Srw2+Ou2ZC3c9oYwAjxXF8e8sk9WRxB8E5f0CpN+7id9LklpTEeRgCZJbTXghRy/HXwmv9oe2defEIrYR1K3tpDLfiSmmqpoMi/95c/vrNHGrffFNSG0CoDYUUpNfiUmuqj3TaGK2a7Ujqutfttmx8xNbaUoae9EP/iNzL9f/wAvv0pn5T3OFPfHu8eNK148a03pqT14f7T6nI0oq38jN/xDx1+Lks0fmZB4BNTxSE036eGrqGA0VO9VwbQJm7ygPfTb2YLznFSc8z7ikeP+AxXbTOzaCTT2fmq1lHnT6/yVN7bPcc0ht8VJIr+Lwro5zSQR1S6DylpJVh7ibZchjiRSS2Vn79tB8Sjrl7ebRVHS6LvzKrMu2JK0NNN+43WnKgB3roUvo4pl6Lz0Wln095fa8ut7wjWJFk/S4yGpPJKRzd4gKO25AI2OhHuDnalNbSM00X39TzKU9oMqeJSQISwhLfjt1pU6gkaHCjTVO7CIudqFh6Angn0kAjrpfSi6Db2zAF1x4zKgqhoo0od6/u1G8+1ECzDnatUgIzchC2XStxIGwUqoP2V1gTlpqCp/7FFKQCuc41bnPUlCUq8v+g1M29f1QU/Z0TnbLnewyG+kEN1qOutv7k5qGk7DjkUb/l5HWqoSRU7AA62/u2m6Ed+2jXneiuMHtbGnMGN81wUoD0lXHUTcvQ6lTO/a6g+JcznYe5lahGlpVQ7DkknUzc+xLJP2wlZtVR0jsblLXqZShZHUkV2r4U1OMyx+tQEvl/b64j/lKvuE9rMjhyEokMelSvV+Iba3GSaeqUz9oXTK+R1EVJHbi5QpDcxEQ1TU1B/o1IbtpG6WnAXMR0jKkeElUpqM5EcCkIArx8fu1FHM0HdD3uPmDdWFdnbu0Mq79Yu3cmn0RXd0qIITzABTVR20sz73G2PHx/VN+x4CzIAvGgad/eE7/fjN5Xbhy0TEJKozg4qINaGm3lrhk9tJdTmOuvgV9T9qWUN8yT1SAB1SuSvqNduU1qpdaCVD1E9PuGpZ+1ZacqEUVutsZYAFgcCUzWLdxGrnHivtzPmnQgKJSa0BHx0nkhdGeNNt1X8lghESaUauF3upDs+VW28uuhL1ukhTilnZIAI0VivUbM2RrT5TWqxN2802jmPNGvFAmoxuBk/ea+MXhx1Vux6YUrE9wBThbAH90kigKh0r4a6da5W5nIZy0XC83YwYuJzWmrq7K+x/pKx2Dl68xx6/y4yhHU1eYi1pWxISDyqaUKSnzGn8mPN2eD3DiPtVbh7rmt9Bp7FfHZ2GYpbo9rkw4jbj6h7aXSCpZ5fi338NtFw9v2tsKsGqV3WZuLmTm47oMd/02bLY9tgXJlqRaVtFDLNR6lGlT1H9OvXdwIBRoqrT29Brzckwe7a23BZRyzDr65jb0RClS4TjhWy4ihqkpJNPt1WDd20zSHNDSuh2WPne8DUhK3eO4VyyG9XCXcnzIQ64oRQ0o0ATtUHyNK6qF/jGsfyaQa6rvuLsWQWjQ1vm6qNhYbdO4CpjlivsGNcGzVuBJeSFLUB+Hio7/dp/hMV6kdXD61z7vLvc43+lCRzOlBurv2+7XY7lzdxwXLoP8udwIvIw3QeLb4ANFMq25bjoa6evx/EUbquY237g3Uk1JdB7UvmWYze+3OTSbBd23G3oyz8s8dg4jwUDpZd2lG0cF1fAdwtmDXNcCfBMT2Z7hymJ0aNIfUn2iKnxKTQV69RrnObxjY3CQDTqrXlbKK9ti4DX80wn1Cdq7Z3KwP8AmKO4VXG2sKdivV2SKVWCB5jVg7OzTcbMHN1Z4rgvcOLGRt32UjaFY9zoTkB9SCoVbX7aj0IIPSmvo2zkbcM5RnkPYvlHKWrrWXgRQ1I+xGPtSH2rsy604fUoGoNR10LOQHUUlo8kgLQiGozbcyh9AJ4AVI67ddDnjRPh0quZi1fLOc0tJoVV26H4HWgKyW02VxtkyREVyZU5EWk1BZUpKf3akIBCgLuJRFx7MLw4+027OW8W18Uh6hqPidByxcRUI2CTmaJlceyOx3Rj5O5tphyiAlDiqcV1Hn4aF5VUzhRKl9R/bC0yFJvlrShie2eZkNVSVgU2VTZWiLdzQ6hKFubeoqEDbNCeNncU46fcCCVpUSUmmmlw0cKqG1bR1FWE3kQpYSAKJXv9x8NLY69UykoNQmBwm+Wie20l91tKjspKuNa/fo2KFrkDLc0TA2ODZU8XmVNlfmCKn7tHRwhqDdPyKjs4TGftbiR6ggVqN9/KmsykNFV6lUseL43b73eZrLjIKfePMLG379BQyFzlkwjqpvuL2UsYski6MpbQ6hsqHEDqOmmdKIKeIAVCAHZu3MO5A/GVKC3IEhSUN0326ayKkoGHWvitTMYuCI1njxXFcqJG+h526pxC4gaqLjQ3ZF5UsBSWSup4mgG+hnaLcNJKKbsduNHSobbfhO+omkkoggIO5pfpduZcVFc9sAEkA7DRBbooS6iAPb683m+ZtcI0uWC4ykSYYrtssBVSP3aHeVEypKeq19wU2KIy3dX0lCSEIfB6jw5Dz0M5wCmL6aFX625eq+sF21MreZVul47J+7z0suMvFbkNqCSiYrd8grRSESbdFPBE2OQgjZY3rr1pl4Jaioqt3Wrh0VzjtNUBSmilb6YNlY4VBUJY4dF1hRA9QoR11s1wOy1IooO82+3XJh1i6sIlQkcXHIy/wqKTyG3TYjWr30bVeEfqEBLH3hztTJZs0GLIuEqRyS3aoKAp5aUjZG34B0FdVbIXMknliq4+AV9wuIjiaHzODR4lRmPXD/LTt3IzfuHEZt01LReTbYyeTzTKjRmMST6nPAkaasDMfD6kg46dUvtbOXN3vowatqRUe9LjdPrJv0uUION2qPBauLntLiPgLLaSQAfTuFEHeuq8/ux730a3TofFdgtP2pjt4/VkdUin1KvPd1mm/ctzFrZVenxV29tJSHGw5+Ig0Pq3poj58SDzChKYf8NuYAeVGj71Xso71u49/LGJWqEWIyeUu7ySoIkLJNEIbc6jc1JJ3PXUU+RfGAG6qO27QivA8vFaJxe2eRRO52DyFSgqbCkuqgynFUBKk0/M8uQ5b01aMcfn4B6mi4f3FbDEXrmxjqNPqSQ49Ny3C+8V8ijtleWbQq7uQr7Nt0Vx1p9LCD8rNHFNKuA0VTy0wtbf5dpB2SOa6Esg8Shb3mXf8vze53/IIE624vYIynIkKS2tptx9O6SqqRXkohNNVHJtlc80BXXu1mWsUHNzhz8ELMA7D5L3Hn3i9S7Yu7z4THuLeZYElqE2QSGosSoB4geO5PTW9tA5410WmTu7SB3K65OPQdPxUnnP05N2PF7JmEiRAy3Ar5IEZ29JjrhSLdIJ4e2/H6pVyHEKB2PXXroy20LnNdy20Wltl7G8c23lhaxrvhdQfevPE+53+S14tlhuF2kuQpqEt2i9S1hTbahUJZdI6prQA+Go+Uk9uJIgWkake5a3VhBaXgsrgBof8JPgdKojd3PqEvvcDs/kGKMx3MeusaY1DyCelxJD7DnLh7STuQ4Aa6aYK8+ZdxBq4dFUu8cC7HtqG/0zs7otC/pnn4A12Iw+Dg1/Q2bHBQzdVpXwd94pq8h9BPpqutNObyrXku0VNxrWhoDdVb1ZBbokmbLiz3VtdYrjlQS5/EBTwGhQ7kNE5MNdF5SZLt5jLkL4zHHKc0EkEDrtX7dStjDuinic6LYoLdscGsMfvrdL/Eirj3C121wvp9shIXKISVcqbkhJ0C+0Ec3IDVPr7OSyY/0nH2Kc71ZC6e4VqgWyQlUSzse3dabj11VxPxA1x3u3ur0b5sYcKD4vtTTt/HcrMEjUqbYbt93YiORXESIiEVWEKTRJHkPidWR1nFeQxy6EVBTKLIS2IMZ0J0HvQrznvDi+FS122IwqZeFJSlMVhJKxXoonoBoK5zcdk4sibWnVGwYuW8HOZxSyxMlyzuLLvzF9DKISB70ZhQJKU1/iB66mxuRN69zy4U8EHkbJluQGKku4FiF7mLubtzkIejKUzNLFShSwKDbw0FPLbFxY061RXzNxE0VaQgPn3Z/KcXtC73cZDd0xhx5xuM4ak+2s7Byv26c+g+2Iexuh6hWHFXdplHCCehPgg1YcKw5iWxKRiUa/uKc/MivS1sIFfKlR+3TSDuSSE0k2Vf7h/aprQZbY8hUmg6exaBdtM5uuCdve9MvH+ybFpbs+DxpEddueS/8ANrVk9hjlkrbqr+7fW5v4IOrFa3kV4CQ4dPp9tFynJY66xxHKJw3ofE/4VSPdm8hu7uWZqqfAXEXkUgyHozyVJUhZdLu3IAmlaar3fF6BbCNhGuhV5/abBSSXTriRpGqs/wCr4v8A54e77rNfY4e3VPH3+NKV89Vf5af+wVod1dOFt/xJw5Dl4fWlAjwKJYKhutKDUeIKa66u2XUBcbhtWmMlHrK4rzf06dnPbSBxzzPyPsMDFP8ARpzZxuJNPZ+apWWLWuA9/wCSrXZn9Nkdx7FHyN9UC2ulQelpr6VAAgE9aGmt7z1WsPHeiEsWxeo2u1URe9iMRi51BZxl9c1yRJRVZJV+Xy266VWD5fNyVgzUdtxZw+JGOXeLZamra1cHw25JbQlhoip3T0Ot66qFjnNaapmOwV2fRFvRt/L21qSQ61QEA6UXpcB5fFWjAPjAq7Zef1PX+7K7X3SOt5YZdCUrSpPE05bio8DpfE+WquTprfiPTGqysTKQUJ2UANtHuamMNy2qmoC0LVRA5E+ehZRRNIpQ7ZT7DdBQp3IpoZxonlu3YrsQkJSFU22BGsByZRR8lINKUCaA8PADy1E92qYxW7aBSkMJdXxOwOwJ89CvHLZGtgYNSrZDSWuJRUgD+Hz0O5jkQwsfor1A9v2wrmkE9a6idXoscW11XmuW6hS1JdrQ0pXYDUPORq1khjcRQVXdFu8xnipqUoEgnrrIuX7Lwx8DtS1WGPll4KODr4dR04qSDrPzEjf5lo/DWr/5F8KvKxITJ+XaU6PMED79YGQlaULN2rZzN1aF6wcyaiXSPc3bW2Z8JYXHkNr40IO3UU0WMg6YcHJVH2hbQygsbQ1XP347lys4xyCJbfsuMKBqFAhVAetNIIccBdF6t2KhFpbzAJKI8mQLg2U1c9QogVJO/lq23NtbxxalVe0v5xdg9Kpte2+bysbYdTJtUlxp5sBt/wBpfoJG46dNc4ydtC4n0yKn2rrEnC/jb5gKb69UUrN+lTLe7d7rZ7ldnTKS4lhmM4rkjlyKa06U21YO04rGKIiUiv1LkX7lz5QhsVm4EDoOqe+09/Mdm4vBZsFpvWOrt6EMriGOpugSKbkAeApq0Nnxsb6hw+5cfdjMrK2ssVT9PYqjkv1cZWxbpdgw3BL/AHaWsD3G1tKZbeHiS4qmx+Gj/wDiCxjJoQlj+3MhM/Vgb+STfuPf/qF7lXM5R+iysWbtjX+Ftil8nfRvxATtSvTQbu8LTnSuiaw9hXz2E8hspXtrmXcjNMduUfP3Jdmudn5t2x15tYCimoB3HjoHN5q3nirCdVY+0MVfWM5E9C1LRlGWdyL9PmWS6zp78aO+tHsstLQhxNfTXikVGq9CIgPM4VPjRdssGRcvLT3r6xWxTn77Ats1h23tLVR555JR6PEJ5UBrrSOJskoaTVWW+ywsrVzq6gI15DY/pdsq1x5d8nDKWAlL1ytvNSY7viSpvatdjq/WNs2GKg8F8idyZmXIXjnt6FWWx275+DHmQL2chlWpQkY5k7Z5PUR6kpcV5gdQdSvh8tQl1vN47omd58Kgd2e17eUtx0pzCyxx7q2wKuLQN+nn46TXnHTkr12tfSQzCp0KQHDbi9bLpHUoKbebdDLzZ2KTyooEfA6p2Xtg9rmr6Xwdw18RB1qFrt2bnWq+4oYt0eStpSOJQrp08QdUbHO9EOafErk/d8MsN1yjCWn6hvpXtN7jTcjxFLUaalCllpsUbfNCdwNgfjrpXa/d8kLxG46bLm+f7Yt83AaN4ygLOnGbtcMMvQZmsn24rvtOIKeJQpJoQQemuzNc25YJG9VwKS2fYTuhkFC00Tr413RtlyjxmGCPmCAFpJ6DQj20KPE7XhHWxxH7gy0+hPJpZ2JrTfWiJEjeKtjlvcZZWPYVUD00Gtg6iGeKiq8LGwkSlF5PtkHavmdQzv8AKp7YUKM1taZda4pdTUAVH2eWlYdqmhZUKl9w2lmClpb6y1QjgSSBQfHU7PjCgkBA1QoYtDT9peSyd1BQAHjt009laXMFPBAQStDiED5GPzY8oqfZUUhR9XwrpeyM1R0hBaVKspbjBCkr9tY3SQQCNHReVLJW8kce392uMpaGkzErSkUCDuT9+pXSFRMiFdUUbhBVLbQ08taUubLAURUHQkr3EURzI2r+s4/bbIyic0gJXStAemo4I3A1Xpy1oQ/zPLXp1qk2mMCt1QKQmmnjDVIJ3uGiUGyWTJcGzMZCGnFwJTyTLRvx+J1K4cRVLmse11QtNcFvEK92eHIacC+SUqUEmtOm2gZHck8tyXjVTYySJAubkUuALqOCfHY6GdsphJR1EQplxdkRmykAhSRuOlKa1Zuijslz7tzUxrVKWlIUotGia/v0RuEBNWmiW7tVe342UJkKiqeEukcpB9XqWAkjx21DO5sYqVHaFz3UWl1m7RRbw1ClXpTzoSoPKZUo0VtsFb6oF93K6arGtp0Vm+SbUEo4W2xRLNEbiQGPYjsp4ttpGw+zVTu2zj+oUfGWNFAuG5XJ+ByVwBQPwk9a6qd7l7ixrIExt7ZsygmO4bLbjjcr2mlNmij7qKj7ia6Ax/7gXYlo4HippcHy2UmO42MuJSk3uM0+SAWluorufOuux9t9zx3rdTqUgvsU+Kui9L/ew5ZZzsBk3WW7GcEKHHWhKnVgEJAUo0HqpudXSNgmbQeKSOl9DVZG4R9a9xw7OMut/evFXLW/He9i2ymoCpExBQspLLimgQU035J200bh4GN5DdLpO6ronhxNAir3Eyi897bOu4Wm9yrJiLkcS7dapscIEpaEng86ldFpSfDy+3S3L4oXMZjqrd2tnjYTtlaEk1xTcMQutjayexqsU56E/ORJ5hTMpFSUOtODYj4H1a5Nd2DLdxYDQjZfWOG7hgydrycaUorKMlyxqXabherB/LVjuzIlMXdTfF5+OTwqwhR2rQmqhqwYHHGQc5Dtqued194tt3mGJSEyw9rsxdt0pnKLhPlzVmM4FSy2+HQaFNEEePw1Yxj4nuXOh3HeipDyAU6cDJs47OdvrHAsHbqXmDbEZtb0aA42iWUhfAvOB38aimhNDXbTa1tvQPEbBUrLzOuKku5OHVe8tX1C5LAN8vncax9lsaeZSti2oYTNvBQoVClOLPtBdTTiAft0fPk4LZnIivRViPHXN8fKeNFx4xbslhIcTlvdEd5cWmrSZ1kvtlitqbcT+D2XGCkp+wjVWyeei3DVc8XjLqMU9Qq82BeO2m5XGHi0NOBi5oHuR1NEMO8age2rcJVudVmPMCYEVon77d7yPVNaKkZ/j2NS8KPa2BaiqAqWmbKTwJbW4HPdqkIPqPM8j8dIcjmXWkZAPLl+SbWtu2WRmlOJ0SyTfpRv2W3yzsfIRpeMWttclUR5CUF2QtXobWSahCfxHRmKzj5IC2nxCn2qzZG8gkvmXUuvpj8NVR8k+kHu/cMiuEONZ2E2p58SU3l2ew2FOoSpKEtMp34pBAHI+Gr12rbRW1XuOpVH/cXuh2XiEULaAK89jvp67+YRdHRIdGMQm3z7sdUiM/Hltg0qsAKUmvXbT7INjdHXlqucYtk0Tg0hNRnM2PZrlZm21JYcW023dW0ghovjYvIB6JV8dVqGYNfxBV3Fu90fIhEeytoQEKec5OrSC04giihStU/dqww/DVJpXuaaIhYxFQzNl3F8t1Qj1yuIBLaKqAUdA3b2wQvleehW9uTMRGUjd/yKC9dMiyCWrg1JushPvAHiRz4igPhQa+Q8uZLy+kLdakn6q6fcu0YpghhY1UmRIluvNw7PlrsGyy6qkxWSApRX19XUfcdNLLP3tpbOh1psnU8Fs8cnNFRqqpdotottw95xRflLRwiLePNatvEnc10PFPPcN1PvSea7cXcW6Be+F3i32m+COhkSHlp5XQ0qEp6hB8vs1YcPdvtp2vcaMdp/FKMlCdC01I1RAuWKWyQ4nIe3z7AuY5LlWRRT7UldSSCDsFV8dWuaxaZhJGd0ZFlo7lghkFCOvuQP7lJ7o90LXOwteNSsYjMNh0LW1+Q643uUBY2ofMastk6Z7Q1+yjElvZzB8btVn4LnPxCbOtlwiJROZWW3UOA0BHig+I1JcWHrEK72udZ6VK1qma7G5vdo+G9/ltSpTaY2Aw5DSW+R4qVmGNskpB2/C4R9ldDi1MbJuBoeI60/nYs37rC6ksg9op6x5e70Jvzoq+9dJwgS79Etbt4vTaeTCENHkSNxUpFdVktE04ZNJRpOpJ/VF5vK2mLti2zZQkGlEkv6tkH85/qXs/78+d9/5Tjt73L8PSvw117+32v9v4c/JSi+Z/7vdf3X19edVZrfES9DinY0jsn/ANXRApzFU2t4axM9u6O+QWyVO7C9oI0VhTyv56z08UV2HyGLat+LcKuHsH5rmHcn9KVw6Bxp7qBCVuz3LHJUG+ybc4mIw6CXAfGtNG3cZaCUhs5+ZBB6q3yoci95fbr6IKvkAEKUrxp1rX4aRPJbqArIYvVc01RhmXLErq40qSQ89bk+hSTUN02qd/u0tfKAU7kiOx1R07E9ycGtUe5xHro1DU84ngFqSOVNqaCmNdkzsaRinSisn1J3u1XTtpKVb5yJSHQniUnatfhocOLVYLF1TosxiphKUdP/AEdbOVst7dh6KUhKIWChygPhTQ8oqncELWjQKztufgKjvTfw0KRqmtvMAQ1dlQpKeCwmn79akUTy3eApBBUlIA9X9tXh92h3CpTKMVFV5XWQYFscmNo9x1tJWkAkEkfZre3h9R9K0SPP5OS0gL2VrVUSy9xr6p5KHbe4lP8ADVPhpzNYQhmhFVzbHd/3rnlpjLvqRMhXPKLw0oR4/wAslSKgq9JFem+k744QdGhXe0u8nct5VI+oL+w8ivNleMa8Ry40Du5v/Trd9m2X4KBFQ5e6t3H1K0VutuWW24uIYiEKfT6S2DWhOldxjnxAknRWPE9x218S1p8w6K+wkLdTuggJNFEHSV7QXKytlAC6nUuISfT0NDU9K62PkHsUTpdQR9albJgmUZDLYbgWpxSHVel5wH26Hbc/fqE3zI9SoJ5WB5fyoAPvTC236Uvm7eHc1l8460hSWGT7YBPmeulUmcMb61Vfk7jjJdHGK139qIOCfTT2uxl9Mtm3NS5KXC428+fcUKeFSNKp84+QfESlF1kHNNY20KOCrPhNvo25aIqeQoApIpQaUvuy46oRtxfTbPNF9xMixKG26huCxFYZPAq4AJr4U0N80SdNFrJj7uQ6uJK6YmS4xKWGEsMjmreiQAdZM9TuVHLi7mMVXVJv9kiKd9uOypaE0SqgBI8NSC4dSi0jsJ5ADUqtyM3xxiOXJ7MdDyq8WxQnQjz/ADFMIcLdvdRhKhI+eYhLX8o5GjqLxqpFKmleupGZV0egJRc2Bu2CtSp5NkwO5IC/k4SVOj1LCAk7eei/n3nVxQAuL63OhKrN57P4Jl8X5SO2Glx1FaZDRKVg0oTUaY2eYdG7ykrFzl7h7OE9S09EHrR9MSMDdvcy0W+NfoklS3ERpiObm4NRz8anVoHdM4jNCTok1riMS9+rQ0u66/qhriUKLheZyo8+GvGLVdioTLetFGUOHotsnYU6Gmn2L7nbKykp4+9b3fYDJDztiD7kecOl2W1S8ht8W5IuNrmoKobZotAUtJK0g+QOtrrIQSuoKFRM7VvbQNcWlZnZdFdZz/JHGWgw3+or9ptAoKHeoGlV64ObXou59qwSNjY4rQHs1AvT2JuvMx1PLUiqKVBO2uc+lzkfx2qk/ddxCLoBxRfxOLmr8J+PeoRTGp6Eq8R8RrGPZM54kcdlUsm+xbNyiIqsqvqWxOfjPcG6SfkOEC4uJdYcAoOR3UDr6J7UyzZrfiTsR+C+fv3Jw0jZhPEzlUE1+tQPa+M4q6RHuKkVoFIPTr46st0wbhczs5vUaARQjda+duY9qNniNve3zCU9Ps0GAU0aQRRFVrH7RKCzRKgBQ/frf0yRVSAUG+iHWS4szGU+qGfbVx/L6aHlj5Cikjk1oEI5WUz8dmxmXeRSslLhr5ap2YyBs9V1ftftluShqQCVG5pm5m2pRY/NcQiqkjfyro7FZQXTQeqQ9yYM49xadlQMayuUmMoOtEtqVUAjpXV/ibWMLl08hheSCumRfYc8KaNQs1SdvHWjowBoFPb35foSgvl1wkW1wqZJSjqnWjYyVLJMR1VWsPdG82W4JeZe9oA+oEEjW3oOUMdyQ7VHu399JbyGFv1WpNAB4V1G6IdUSbnqF3Xnvkt2EqOllQWohIp8dbRxmuuyEmuidyiBZwmXbGLsW/cccaCltkeYr+7RUe6ifrHU7ohWe2WXKLUuJIjttOKSQnkNyT5HUsxPFSQN5tFVRlt3nt5NkojKUYLnIBoEmm+xHlpVyNUd6XDUKFxnL38kzaP77igUrotFabDWzx5dELEecqf+EzHXbWiklNUAnfx1DD7U5mYG7ITZri7d9Q5HCSqoIpTW80/pivQIMwF+it3bH6d7JaZES7yo6npJUh1tBOwrRQJA8jrnma7kdPPwi0ATq0xLLcc3FOnFiNxWUoTT0AD400MAwNq7dSySciou6SXAOPvFpA/hR1I+3VZzGQdGziHboiCIHWiFeVi3qtkyZcDLVHjoUtRV7hCQkVJony1Q8pO+SLz1P09ifWLgxwAokHmX+wtZHKlzUzZtoU6pTUERX1uqRWgoCKGvnobHY6O5Zr5VZHONOQCs6e5GItJEOP2w5wFr/OU9FrKUCCQUVI4766F2njYrU0AB9qruUMkuo0qujDs5ciuru1pwnI0h5fy3BtweyhKlkGra3FUINDsNdVx97xNAqjd2ArRMc9guNXdqPKutihzJSm0+686yhSzyHKijTrv10/bdFw0Sd1qGnUKgdzuxsLN49tNjvkvDp1vY+TW7DAW29EUfU2WlUSFD+BQ6ainfU6b0RVtRgoRohF3kwGzKk4JZJ8AXONb/AGY1udeFV82gAFKI6k9TrjncMUjbxtDv+q7T23ct+UcQNqfgr/3T+niB3UxyxtxL2cZvllimLGnhoPsqZcG6FtGlSDuDXXQsVakQA9VzzK3vK4dXVVXtX9H3brtncLdfJLjuVZJbkFLFxloDbLbiju+hgVHL4k7acQwhupSWe4MjePRMNmv65Ex99/GIsaRemVAQ2ZSuDCvcHFXNXwBr08NSTyHXiUJBBTQbFK9k99tsGda05XJbybKIzXOVbS+XI7bijX20R6USEnx6nVavJR/MKp9aWha3y6BUfJO6yHHgH8YRY20AfKuNlLIXx/iKa8lb6q2TyLWigYn1lYPOtVxQ8hul8qqE4+pRSVMstVXWh6bmvXy1WmxSTHy6VTd0MTBVwqULYffS7RMvGNZLCl4vCQ+WZU8NFxaN9l+rcA+OmEPbxk1dqOo8UIciGOFNKJilZZdoMf3cWvCrwXGSpppx1Dbb3iODoqB940OY3QuLGeUBZkPzGu6DMX6sZqMqkYdPZkWnKIqQ4LXOQQXaAq5tOoJS4KDqnVlgNy2FsjCTRK2yWpkMcrQCjIj6kWpVrYmTobsZnnxuFyjuB1tIA6lJFQTo2TKSTxB1CP4aIm3xsDJKlworxIlYd3JwuXIsN6au/Flao7qlf4qO4P4ChVFU8ANA2Zl9YOoUfezQsi4tPUKC7V5d+pNqx+4tPNXKyUbUt1JAKeiRXpUUod9XeC/DyIxoqfc2haeZNQmEuV9TasZuzLKUqlS2SGjXcJUKGn7dUf8AcfJfLYmQMNHnQFG4Gy9S5DiNEnmZ2BmfZ02pj0rf/Mr/AK3Xfx18x4y8McvqHouuRxlo02QutPb6Vb0/M3CVVtpWwBI6afXGZbL5WDdZkeVBXuyfOTn78VOKejJLNtjn8JIFOf2jRdrdcGCHodSfyS24ad1S7BZ7lj9vv88urkXCYoAczUguHqT8NM7y5juZI2Uo0fkgomlvIqu47IzWzZA3LhTls29CS48gKKi6o7kJTp83JMhi8ho6unsCVxxOlfrsii/3I7rfJTYcW0LfVIbPy8l8/gqCAAn99dM7Xu1sYpI8FMJcEx45DdAvDfp+vdwkybhlctVwenPqkqQ8gEoUok0TXon4aAzXfTXeWLSikxmOlgryJonG7bdnbJasZ7sxY8VlH6likaM8kjeichsz2/wq0NV217lmmgu3OJ8sQP8A/ehb+aYXUpZLbgf/ABD/ALKVSdlwmFaUIRGiM8SClQSkdD131SLrKvmNS4om4ndIKONQgv8A8Olm/wA3/wCbf0iL+mfK/MezwHt/M868uPnq0f8AGs39p+W5nlWntpRVD+yw/O+pwGyyfs1w9piKlSqflISNwKUSNfU3AmjlXbJ5LGj/ACpx7G84exvbd5hSA6jLs+U2tZFARAxfoTtqz4QsdLq4dPzXMu7mSuEjw07k/VohPeL1cZVoMCTM96EytLrTfJNOVQdjTeurndQAsJ0XNrV72uABKK9nsGQ3aLb7y2pDNnYjJL8OoC+IFSRUbaU3VtHwpRXbEzyScXE7IQd0J03FbnFatsBJYvsdRW4RRdetTqmzW1JD71bX3QdsCqljNr/W5Me2fKOIfBCvcHpJJ3JG2tXRtaNVlsz36NBTM5PY37J2lmomJe9ttIU0txalbjpsToeWIDVP8bMW7lJv800vjudBFpV1t7qnVS9ukhCirkKDp56icE4jvB4qysyWilfuGriv7s7U1C6PqmkM7dCpNl1KwCeNKUAqPHQzmlOre4r4qwRXUKSpvmBx6bbagdGa1TmCYjfZerSUqWlp3g40qoKFfHWhq3UIt1vFcNLXjSimbdb7S057ZioSpRASQAT9wpqOSZ7hSqis8NaxA+mwV9oRf7Z9p7vmd8ENh026EAFSJYFKJ8UpB89Jb2+LvhNE3nuRZx1DQAj9nn0tSLHjkm5W64PX52iUR7Z7YU4oqNNlJoRStdBW2Vkik5cqtHRVuPI2t9IWyCmlEpbXbN7C8nk/qMZVunKSlbkV0UICwSCfLpqyS5NtzGaAjTqh+3+2obW4fMHe0bqyvSlx1JCVjj/ER4nbppE8GqvTS2lEwXY7tzcs7vsSe5FBs0FzlIU8PQtSfAaXXNzUlo6JHm8gyxhJJ1O1E5OW3GyYY9EZjsMxzGoFBNADT4aq93dO5UO26rOLt58gxxcSQUNe6ne62WnHWZCnypax+W0gVKj92stgFw3yjU+Kd4LtZ4mJISbw/qYvjVwcUYpTCV/AXPUPu6aYf2Qbgj7/AMf4K+OwNlJ5Rp71zXTv7dL/AD46pCnYsJnZSkepVPsB1C/BF+5+yqMtMHaQsIA6qFu3eeZcG27bHU78jENfdrxU4fAkf1an/sPJvHTRTQY+1a4nqu+y97/knWxJW+tTewdFKbee+hX4J4OlPvWZ8fazeUELyvnfe7yZinYCyGCmig6rf7QB00Rb4M0BdutI8XaQtoafUhrO7n5FMS405cVNIJJBVuqhNfxaZx4JlPMPtWzZrWM6BW/He7cWxRW5Kg/cbmAQ44spSj9u5/doWfAM+JtPv0Wbr5a4boQAinjH1AWp+M8xfFrhSH1VQpNVtip23HT79L7jCPDTsUnuMPHJQsI9yMlv7wM2hbD0O5MzEOpHNtpaTxTTqaaRejNDUBtUqn7aZcAgtojRjvepUuJDle409DU4EO7ivWnTW8c8kVC8dVUch2cGOIFa00RWuNq7f9xYS2bnGjurdQOSQE138ajcaYtuWSeV33KsRz5DFP8AITRAPL+wEzG47t1wKeXW0VWu3qVy5DyB8NTawHmwkjwVxxfevzBbFctp7dEsP6LEuF6k2++W5MG6NOBbiVj1KO29dq62nvHzx8QeJqukxTtjiD4dQmZxrufh3bGxJizpzaXAkJDDYLiyT5JFdb4vt67mNWUP2/ouZZ+wffXHMmiteI/UDYsomPsspWwwjYNvIDajX4E6nzuEucVFzdQj2V/MBJ39u1bVhq4K75v2qxDurZHhIisvl5uqXClPIKI2IOmXb95J5XRmg6g+KrN29wa6GZteizqgdqHsA7lzsRnOoeabT8xAeTtVpZomo8xrs1pc+tGFwPMWAtr57aU6q+9yMvv/AG3tUaRa1+6n3EApHlpjFHyOhCQZKd1s3krf2a7337Or/a8aUwY0ieaGQqtEpG5UBvrNyDE3VaYu8kuXhoWksXs/ElwkPzLtJffdQCs1SE1+A0qdMCKhwV3+ULKAtNUpXfLt8xj8plyO+H0DkVBVKgfcdKsnihex1FFfO3c5Jj28K6oD45bYF8afjLA91pZSsfZ01D2/Zxwn0+qL7nfJdMMj9lbnsSjRre4plhKV9AkeBGujRgcQPBcKvWkl33IYsWOSzJcKkKJNfTTbr561ezRB2THMOqEncWO+iTxA4oFASempbdlUdLUbodqsXvROZ9oOHcH+jRYYATVQ7iqsmM2lxMmM26kKBVQgb6Xzs8yLjc3iiRc8bZVRaWlJCuPJYHjXW0jQ1tVFJGCmuxWJFYxiI09QlMenTc+n/q1HHrqt3sIj4rni3CLCbDsN0JCD6RWh2O+2szPFKLEBdpTorU60xkNpIlFKnFIJSpX2dNLHN1TRrqjVKPMfXh+YpkxUKUlLwBKB4V+Opgw8UG7ySVCcTGO7yJ1vaaKwlQA5gkA11CBxTITCQIqYTkMK/ZHCgqeSVrPIDkDWnhpLmZXst3OajLQMc+hTj2txhqrZIStAAB+zXIMfesL3F29U2uI3ObTou65ySwz7oV6QCVU1NnMgYYPUbsoraLm6iqDUh2c575cCIyd613OqdatlvqSFw4/h704fGGDjTVeNxvMIpMJsF5StlJ2NARvXTPIZCxgjDDq76ltBayA8ihtlUDEI1mkzX4vzU5KC80wymrilJ3okI36+FNJJL62FACdfBNbeeflQ/Clheg3a9ZB790shxqO83zRbHOJdeSUEAqIHp89dI7ci4RAb/wAVLeAPNRsirg2LRLHb0xUe44lt9b4ekKKzzXsdzvSnhq92DA5laKsX4IfpRFhBcLKfalpNKAJA6fDTNsldAEn4Fx2X52RIbKR8wSBuokfu1G+54guIIAU0Fu2R3FupSmd5syhHKLO2lwuuWd1LigjwNRXXH+4Mux99HxqRrX2arsWAxMjLJ4pvT8E0ljubN0tMKfGd5NyWUqSag7kDXUsRdevbjiaUHVcry9m+3uHc2nVdxcXUku+nYHaumglHiEqMJPRfEkfNMOMLKVBxJQpdACB5p8iPPW7iKVXg1zeiVuJ9Prdivl3ukC+P3B6dKVJku3f/ABLhCwaoDuygAT4ar1zA8vqNk9trpvDiN0OZvYmTHmzr/cozmV3NLilRogc4R0AfhCUkVTttvpHNZnlVwCcxXdBpougPw4cH5K/4RNgrCKKfgJSosEE8VNraNdq+PXQbeEP8pW0vOTqEC8sxuw5Tk9kvc2TIlXGzvNm25IirLrjaSAY81moQ6kp2NRXWseWLJQCCGnfZDy2Jc3kCNEc8mw/HsfuMa84s1JZss+KHJkNtQWwHFD1hCKemm9N9K87cRgmRm3XxTnBRE6OSJfU7Dt9qXh+f29hbj1kuza5Sg2ptYhv7LR7iTXYjbyr5asPat4ZGmLTUVFUh7usGMImANK9FHM3S03xk2mVLnYrIuhSq33uA+UNSQrenNP8AEB/CQeXUeWiRcBmjgNCfxUUVo6WgBIFBqdtlasewLLcZfZu2NZE2ZtfXk6UuvTnEIIPtqUp1TSNxUq4A+GjWX8QZoNVluFl9QVNR9dE1GAdw72iYuLkEOJGu0vgX3mgEiSpFKrCeoUQakapHdWXubGL5qLYdOqsdrYQSOETzqjTf8lYukTlFfKDxS07GUN0keIPkdcr7m7tky8bY9QNKg+z3abpxj8WLVpGla6IcTrsx7rbXtl1xIFancDptqnxW7qVrorDGxwYAVFXCWmSn2SPQ0ipR5n46Ihj46+K1Efiq07GDymVPelEdJSltI9O+/wB+jmv4g06oW4aqbOQlMGUy4CPfk/l/Gg20ziNXgjoEvLaNPtX8strjyTHmtgBbX+HdR4IWDuaa9dXDmVafeh4IAN0ZLbboiwG1hPBsceCaVofHVanmcNQn8cQDVJoiJiyC3HolQAos+Pw0OZC9tSs1KveMuBmx9x0rCfcGPMqJ2qf99Wsf0nTrEDlbXvh6Df8A9RAll+2s1v8A/UP+ykVAamvcypxXEDYNg6TuiFNEYYl1/qCaceZ/B8K06U/bqL0ShvS/q0qK0X+fKI+wRDS2ApVGxTp4AGp+3X29K0ljgOgXNMUfUlZ4EhavyMUtifpx7Vt26Glqcb1krrewJU4/DsfuGhB6hKdcfd3Jdw8HNeQBLI0+0ARkf9Yru1t2hjby5ljnaKehCR73Omr/ANUJIMqk3G1PPWu42EBDBIQ97K0UqdtwmmutYnu65kgBcTsuY9x/thiIpSYmivuCslg77TLLE/TDZ/eilgR1pCh0HkCK1205/wCIJpGqsN7IhjNGqFzHuBEzuVAflwhERBbSltBSkniDWlQK6Gdlg7fdbns2X+UaL5s14tsG/Rp8WW20j0gppuKaHGRANSss7NvK0jGpRs7qdxbDP7ZyLc3NZlSFBKQ0kivInYbeGvNvBKUTN2lNjhzmScxosZ/jToeqR1/6DWhmCKtLVkhoCrNGx9lYVweKQU7fHUD5BVWCLCupVq/rVlcWpTZf9ST+Gvh0rrUyiiOjxcrCCFMNY3cEcfad3NDQKH3ddQukCZRW1w1TbNhvoUClIUSf6Ps1C7XVHRunjXeLRfQoKVEKiDUKTXw+B1CWVqmEN5I4hpTHdvcOxxmPDu9/fCnJFChpRoEq8a6r19cekd1b7G2c9tQnLx23RYEImxucHCCUKbpT9uq9OHSDQpbeyOceMo0RPxbNH4Ljsa8rQ+tv0t8ulR5V8dKJYXw61VcyOHbK0GH60s31JdrLy8X+58N5brckNol25COXBpIV+ZUeWnOLuXHUlG4m/jcBbt+JqTu0NyrxdoFsjuBbk95tpsBXQLIFTX7dP75wbByCs0snpR1WumIxLT2owSAy2lKHnGKvbVJX/EdtUS+vKVod1zq7jky14WDYFIB9QHdZ+ddA1CKlrcWXAeRqEEkeHmRrfH435l3M7U/MLsGDxbcdajkKk6JVLjlN8u5InyVvtg1bSs1CaCgA1bbKwZFpRHfOOZXg2ihVOJCQCmqlHoPPRZiZTbVaGagUvb8eya6oJttklyGfBaEGn3E01gDhpSiElvgzQmiImM9gO6uTt/MwLItqOVAUeJSd/GlNStt6ioOqr913LDbE8naImwfpD7lS5zcB0NRitPNTqk7V8q8tbtsnFBzd82TGV/Nel++jzufZYL0thLM8N7hpA9Rp8anUjrNzW0AQdt+4FlK7j+aDjvZDucvmVYxIJQKnY+dPEagpJXzFOT3DZyCtVDudoO4iXSwcYlpX1Pp2/bqdpaN1C7LW7tnKs3HGskxtSmrpZ5UMitS4g8aj4+GoPQB3TWzyLSKRmqik3CQ0QpJUkjxSabajktYSKBMWZKdpqiNjHcO52iMuGpKnmVkFsFRHA+Y0gvsOyUHRN4bxtxTmNU2fbPu8ppDSZDpSV+kOFXQ/EaqdzYvtH06JTmu3hcDkAm+w3uZGC2m5UxqY3KPFKOQNCdaxXPpO8xXL8t248hxYKFqCf1TY1ItFnVndh4tPIoXuAoSlYNN/gdWrEY+K6nD5fhp9+iZdsZ18ULoXbhZ147k0q6zZCL1KLzqjVCln4+H2a7bjYI7OIGNq0vbuaR9Woo4rflN3xDMcq3pyWjb4b00g76uoHY11Rqn+AsJy0l60z7W5JJTjym1q5L9qoPj5eOuG4ieSJoPQlU/ufHtFxy9qAF/w3Lbt3TXkkaxz7gw81wcmNtFaAR0Ffh0127t++D4qOXDu/caPnA5mlQoPvH26zbI7XHhwMXuMl1K0kBDCjSh8dhq1W97DHuub5jDTzRgBUHDezXdrHbhHvEPF7vb3YdXETAkILdB1G4JPw0Nmsm18PkRPZOBntsgDLqwkURel92O7LH+BmZddGHW/S63yDagRsahIGuI3PcU8F1xJ8pX2jZ9n42a2EnAVI8Au6ff5dwsKpdznvzZhb9T0halrJpU7qJ12DCX4daVcuG5zExWl8abKi9tHVruk9wpUlJfNFHx0HYP43KaZ4tNpp4I+vpUppYS2XKkkAf0avcj+DariZhDnkHxVccihcV9a4imXkpUd6GtPs0ujuy91FObNrRUJSM8lodmrafZUpPu04jc7adWzkkuB5qKuRY8H2kgxXRVPoSRo6uqhe3jorNaoRZU1KabUhoHbl120uuBUrYGjVeJF1ULc42W1JWk+kqFAda3EZ4LEDubqFWq2Zuly3pjOKWlxtBSQK7FO2lsMpfoFYxbDjUqMhzko9wiUpbpVyCFfE61fG+qWh7amiIUPKV/JoYQujyARwGiWM8UJLecdFV12hmZJ+blJSpS1VorRgjHFA/MEuVrtFvhNKCEx/bR/4iT46Ce2hTa1kJRPxNxeO323XuGXFoiOpU40AKlPj1+GlWRtfmISwdU0jcQ8EJzI2dWmeWJ1rnplMqp7qEn1IVSpC0+B18m98XEvb151oSr3YsZdR0G6IMa/W+6xw2t1I5p6E+emWO7vtMnB6JNTT8kI+xlt3VohtfpEyye8iK6VxTUpKdzv4aqOSy0+MDo4NQ7X8lYMfE2f4xqh6q8yAwX5T6orJPoQn+8cUdqfDVHlvJ5uXquNaae/9E9fbRt0AXTjd8cuN+gRnkJbgMPAupIqVOHZA89judM8NePdewNlOhdT6fWhslZCOAub4Kpd0e42JWfK8vCkvSLtiM2NBukFpPLi2/GQ/HWnx4qSog+NRr6kfI3HUk/lIH4JR2zaPypMA3CFEj6lWYC341sxlNxWwQp1JkhHttkV9xw8dhog9zhjw1nUK1j9uw5pMzuLR1Vzvnd7P8dxtGVSsCt7tod9pTSmJ5Uv2naUc2QQQK1Pw0aM1KRVJ29qY97/AExLr9PardLvXdC9Wr3bXj9nbVNaSuM+JqykocFeSR7fx0Pd3l5cMLToCtbLHY20lqDWhS5XvtD3bvkxcxUW1SXlV90tvqUQr4kgapI7YuCXuBqXEfVRdAh7hsGMDXO4/miRg03vTgtpFquWAN3llldIrkeagEpO/wDENhTVqwwvMe3g/VVPN2uOyL+TJPp9qs977vZnYLfIuN27RTmYkVpT0h1qaysJCBUkgb0pp2c3NH/4X0+xI4ez7ad9BN9PtVasX1N2e82FnJX8DyKHaH0lTNxbZTIYWEqKSQtJG1QdbxZ/mKubx9imuOweMhZHJU+H0KlrB9S/ZrKZnyEfIFwridvkrgw4ydjShJFAa/u0U3MRv0S657MyNs3kI6N8UaoohXBCJtuktvMPJ5JW0v3EEfcTXW3Ns2qr5t5YXUkVOymdZ7K27cZS2WER21LfWTROw3KgdtRG0YTRbG6cxtVkRkney+5r9SFvwvCmWJNhuDrcSaj2SUJINVupKQKbHr56nue34pI69UpjzrzOGDbqntuU+34ZeWrCzOE+OGUiZHdP90o9QK1T92uYZhsVk/i47rplhazTxh7EoH1hZLbLfiT7NjCHpT7cZKWEtfgUZSFEAUoSaU+/TrtqJz7oObtxSvud722YaRrUKrWOFYckx2BOuaI7dlukRiTIltoKm4bzgSH+SNilKXFH/YO+2ob25cLh49qIs7Z/yrHSfBTRSt+wnuX21ZbyGyX53IMPp/fRUCY+0hQqklIUkOoFeh38jpxjmhxHLZL7y4uI2n0fhVjx+NOyuy3HPYzFzYdsaAqMzcGUxUvvsoKnFtNpUtSEmnRR6anz3yd5B8sQhsZFcVM8p2RFhZ6/Os7L6U1U8lp1Kkb7OJqRX4a+eZsQ2OYt8Kj7F0i3lEjR7gqjE7kRBdXG5xfUlB4NrCap5VO1dMJMI/0gWURglDFeJmZ2BtDJVMS29JTzS0Qa8QaHSqPGTknTQLQzCq6o2T2qW6lLLw9hKaEgUFfv1o+wlYNRqopHgqpX64xFMsLikPUlqCU6Y2kDwTy00Qb21Uxj4UI5TRKS4Q8vwCd9C3h833LZlvUK7WtwKke6hwpWkkc6+kgHfSudtG0KcBoYxTM6WF7JcLR6c+u/UaGijp0qomt5FWfFron+Xu5pfSVmPjLBKh1I/XrSP6SNWHEwf7ve06wt/wBvCgMjD/Wtv/qH/ZSIVG6Kkr5j0AnZNd/2aXi34CiZtaAvD9Ayz9b/AFz9ag/y78rT9Oofe92ta8ulNF/NWXynpcT63Ku3Tbf76KtfL3Hz/P8Al2WKdlt6ZLtoaYbBffVHDQ81LpUft19ZX8wht3l/gVTu2YPVntx7QtvO3uKy2u3/AGfbuwQ98nfckK2DUp9cKxgD7ig65P21cQ3NxG0DQyy/c2H9V2Tu26dbvuSzpDAP/anRZumJYddXimZYIzpOxXx/067GyziiqG9VwKXMzzalUq5di+1U8lb2ORuazU0abPX7RrPy4W0eVnCqr/0mdpbjzc/SWWFrPp4J4f8AsEa1daAo6HPTsVevP0adtIttmTWQtksNlaVocWONBXxJ0DPjxQlPMf3TMJmg9SFllmtujNsTo0Z3m1HmrYZWTupCHCkGvxA0DjmmF7qeK6V3bG2fFB/U0Q5hrejucOfHfrp5K6q5HYzmF2qvdtuym1pWtRokUIHl56XSR1V2sb4OVyt/y019MkHiR0J0MdDRWeOTlRXi520/ItSYiz7iQDVOhP50aDQaKBtl+nMPfLrdUfAV6/s1vK3UrVruiuov1xitJUlwFsipUaE6HpRFtZVR96vUu8NMMiUUBANW0+lJPmBoOWJ1DQ0Vywr+bS0GhTC/T53vcw6/xrHlkV69WWSfbZJ9S0k/w1V1Gk8hjtnGR+vtQ/cWFffQcIW8Xjqjb3EzuJk98VMx23GxWmPx9mPX8xak9VK41G+qNmsm27fSPRqz29gZrO3Mdw7k49fZ4JgcEzKJnGKOWyQ0mW40yWpMZdKFVKGtfA69ibwxvDHb1VGzmIdj7rmNASkpv3aNjAs1gz5s5uCJE9U2LHbdHFKPcrxoqhoK7a6HA9s1q5oRrLt0x9QbUoif9RfcafbMVsT1pk8m5IEdK6VG6a1r9gOqRHjvVnLXE0BTrtexbFI+Rw9qzpn3eTcX3H5b6n3VGpWo1+7V0gtDGA0bBWqe/D9Fbe2mGuZ9lUWyqkCJFPqkOfxEeQqKaLdzArRIr3IfLjktGcQ+nHALG838xCE10UKHHRyqa+Z31qIOiod73LNIEXpd+7WdrGXG7wq3wOSQW2VcSo/AJ610xt8dpUqj3+ekLgKobH6qcWgplvY3jrkq3sgrU6S20Dx8QFEddM44S3RIZ79zgSShrI+ve3iZyi4XLd9mqSpLjR3H2EaYQ2xdukdxkKbL+xfr9tzyHRNwie22gUK+TVP6dE/JP6bIRmSJVqx766+0klXC92+TZAlIC1vshQV/s8K1GonY+Tqt/wC9Mj+N3EeKOuFfUN2OzyUGLTkNtcmrolEZzi25U+SVUOvSWjgNlmLMvcf6co+3+KK17wfDstiezItkSa1Ib2e4pV18dCut4yKFMbTOXcLeTSkq7x/RbaX48i8YUsQHWApxyKKFKwBU7U0ouca2M8mBdQ7b7+dKRFcb9Pcs5nsVvsCTKYXCddMNakPOoSSmqTQ0oPhpHN6upeNl2uzmiIa5rhQrthzHojamyVJUTQp3H29dKLl3qihVpt3kjylG3CMqejmOkLPJogoA61+OqpkbIN84KHubYTNdz6pis3ziTesAm2i4qIjrjqqpQCjTjTavjvsdN8EHeq1c5nwsNqZJvYVnRjdtZuN0cS2+VkvlBptUJJ/qGuk9wZAWsLSUN2Z8tezOI6Jze3+CtyX2iywEpRQrUE64nkci+7fxJV7yd6yyjLQm+i3G3Y1ZjHTIbbks0JbJHKg1JYyR2zgHLl9xBNezVA3TKYN317TsWWIi43FECclsB5lxlZPIbK6JP7ddYxXcNoyIAkbLlme7OyzrgmNpIVgk/UD2dClFN1S7T+ywv93p0W/uawZ/MEti7Fy7t2qvXb6mO1TEZ5uOZMpwpIShEdXWnmRoCfvCwcCwHVM7X9usrzD3CgWembZNHyfKrjeI0QxWJayW2DSoTXYmnidc5yEhnuPUHwr6EweOdaWIiedQouZdG0WtTTyD6RTrrp3b452y4T3w/wCXuiVbe3UWJs+FJCnaKIHWuntlFxeqLfZEzMoi9cJLUWgWT8FeGrqxwLFRZPLJ71y++3MhKUihSoKCleQA0M2ldFO6Sg1Se53EZavVEqS2fer6h+/fTi2njYKOcEmmHJ9QFHJ5NhJXLaCUpqTsBTRnrs/lcFG5h5VIV+xwR5iY7ZWh2hBTx8a/HS+5Lx5q6Kdga/SivV2sMJaHgviSQOKAOm2g5JjRSRW4qoOfivyVsTIQjgXEb0HnvoON2qZTvPFBqDKuIdfSk8UIdUCo+QOjmDkVWnvPIlW9Eu5tyWk8KtlNeY+Opn0CieDIrrHmPuNJ/KKF9D1P9etmuCzHE5ql4MyQyUhVSiu+2sSEEIxjiNEesTnQDDSqex7ra0gF5NV8ftGldxUCo6p5blvEKk3HOLfgeX+7FkiTEuSuE9pCtuNahSQdgoapXefZzM9jzCdz9qbY7L/JT1TN2XJo97hszIshL8dYCgtBopPjQjqPv18V9w9jZLCuPrxHj/mGo+vw/D2rpltdW902rCKq9C5xYtu+YkSEvrcHoQTy1HiLu2trcvfrKCaD6bKP5dz5KAUAQRzK7fJrXeVrS8G00isfwhaj6RTWbaSS9lJdvWv1DoFabSPgyi+cbvJbRHmNulb6FB5a9qlQNSCNQTxmKUEaUIp9Wy2vLYvhIQe7ydve5DX1MKzS2W52f2w7l2WG3k0qKpP+FdiMFKH3EkbcVACo319kvuYLvGROqKlg/Bc67Wmns8oWgeUFAmE3EsGY3uFcF8lXBn2Gi4Kpc4qIp96dtUCB4iuC0r6Tykclxatkb7EZ+5GTt2b6Zn4KXlPScekC0I9VCW3ASwN/JBA+7V/bCJ4AFxY3cVrk/Ul6FLNO+pfKMvwi14nIujuNJsKUMql28qRJlpaTxbDiwapFOoH26EuYLtzaDSia4nI4z1nSjepUXgF6yKRCv1wtmX32E+0pL7impjwTISn1K6qNVD9+gIpJ2Hg46n8k2vbyO7q+mg0CuuO/UV3wszSLgvIV3sS1qi2+2zWkrQGU7hauNFcx511JJmvRBa46hJxgGy+anxIuO/Ulll0w6Tid9sDd5yC+ByEbs0PbSW3+tWxtUD476WT90xuYaKIdvOt3ghGKxXyL2t+nWLLlxVtG0RZTTEJ4JSVvuur9lPEbUPLTrFX7Z7NkjdzX7iQk1/HML0noKfgFnL2r7g9qLTmfcWb3UlOPR51pMi3KbbUpwyVOFS0NFA2cIpxoNNhiPXjMh3U173tLakQu2CY5qZJwzH7d3a7K5NLveJylcbg04takRnkAhTUhgnjQHZXTffSSeJ9gS4Kx4ue07gaGPIBS99+/qBzXungb1rskRyzX0PpRdYsKq0zY6xx/KBqeRPUas+AzEbq+poVWe+v25uLa1+ZgBNPDwRS+k7s5P7WYs53S7hxPlsnejrt1jhSU/nMtLIUgulXVXQ/ZorN5f+g4M2XPsBhXc2vm0cSv7dJc255ZdIN6S4m9IdVJfc3DbqlepJaVWhSeoHlrheYuHSec+JXecaxkcYaEOu8bFounbi6T7ufavFsS05b+ZFfeblNhBNeo/wCvVj7TvS67/wCaVWe8oAbKv/KC8MWS5g+SKsd+abk47kxW7AlhPJgPSm+T7G/T3ArmB4jkKa3zTHSu9Vu7Sa+6uh/VC4edkTRG7+cAKaabz3s1cnbnj05dy7WTXVB+DKbXJag132TUq9qp+NPKmn+LyzbiMMdokuXwsthKTHqw6/Wrrc+72SZPbWcVxi02uOm8oKWr7BebkR1JVUJAS3QtlSgR6gDp5Pjomt5tOqWW99LKfTI0X9suNTrdaW2FJSfk+bKm6+qraiCB5+OuCZO5Z829v/KK6hYY0tgDvYEOsjkMWhfCbEVDiSln/ElJKEGvUqHTTOyY6YVaakdFBcSFgAUtDXYZbDZRJYlfl+02+lQJA67HroaUTsdqCOtFDH5lGz2QiRHiWh9TfM+pQNRXx1PC6rS6QKGSLVWWJAddgpaad96RFeqtY3CiqldAyTAPqRQEIiOAO0UTMyDM45XGiQWlQ0GiVEHmT5k6Ijs7R3mc41TiCGgor9actbiw203RlxhSEAuLSCQD8dKLjHF7z6ZBUxaApmPkLFxbU608XI4PJG3+nQz7IxGhGqiIorbi2RMuY/3fbQeZYxOKvjTzySyI/wDltP8AE2RFvdE9Yh/toj+ST5I1lth/8w/7KVVa34tccsaWYcsMyW21OtJGwBSK0P26r01/HZHzCorROXtDY91Uf1G9fJfp/r9/5j2OP+vXj+yumPoQ8+fSlVBQenyWU2LNSJFysMaM2pb61Rw0lA9XLalPs19M5R7G2spk2AVA7LZS6gd7QtwO0zl/OB4C1kZUmaxkGUiMk7c2m4lj4Ejz3OufdqW1u90b4NhJJX/SLYq/gr3+4EwZc3IHWGH/AK0yKTPv+6tam1UrQFWuwBoauDuANCCuxJUpXJSf9lJFft15ZI9qk4yQ6QtLnEVpxp4jWobU7r2oVf7qXYWXAr/OSvj7UJ5Va+IQd9QTGgITHGMrO3qsDLtMVLRzVVZeeU859qyVf16V2oBeV1jOXH+5tiroq6ttPIr48gT0+Pw0b08yoL7YukAburxjuG5JeXmGoUFwNSBVLq0qAAroK6vYYmnXVXbFdt3UpBpQIiXXt7kuIRmJs5klhVKqQCaeJJ0qhvWTndXCTCzQM9y67PkNEFh880K3r4Aa2e2hqFrEC0UKjb21DbWJ7b4bA3KgNSQ85iQ0IaedtuS95oFJqnMvQIvsupIWBVQ3rqOWNzDQjVHWd2yaLm0g9F8PQHTBRcECnFXFSx0A+I0DdVcwjZWnBgipBVs7cMLuWQtF0haLehT3Poa9B+wmuqrnphHbGMAEeOtVb7Odz6lxqmWj8TyKiVc9k8vj9mucPU0nsVtw67Lxa5/NR31ttvqCXUJqBQnfWjpXcg4dEly9i29jII1AUz9RPbRzOcdgZ1YZTsm9W1shuIgqX7qFU5IAHQ+Or3h70COgNQVQLCQQvdbSCgrv1S/QMmj53hDvb/JnhAyC1p9qMHU8V1aoUGh6Hz0W+B8bvUZrU11VxtDGHu4nQ6JU75bZlhnvwJQUHWHSkmmyk+Ch8Dq02UrXMo7QpffsfA6o1BRE7WTLqm4fN2V8RLlEdaUh5RolSQSSk/bpoPTLAFXczcukiAotPZvciVA7eTL29F53eBFKwhuh9ZTtv476jjt+TlzbIvdEwrKXNs2mXq+S7xebgu4XSQupYJPFuu4CU1okfDVjgt6tXNL67cX1JVUbvtwmtKjKcDDKzQtt7Vr5nx0S2KiXfNSOG+imYFmMeiFOJAdNapO428dTg0WASV3yLQ98uttX90s7HzHnrXk6ui2a3iQfFUDM7HGbXb27Y6qqx/iqg0CqbaOtXnl5vBLMtbh9A0V9/wDBcNoxS5NyG5MSQpiUweTb7KihaT5hQodTyyNd0CXQYx41Ap9ZT1dgPqky3tlcmLJn01y+448oNIuS1cn4wJp6+tU/HSu4t2kVAVhs5ZWN4OOi1hh3y0907CgY7d0i2z2vz5bKgqiSNwCD49NLQ+jvMBorFaSiJwfvRBq0fTtFtGYzWvlUy8ZmMHkp4VUHD9uhL6Blw06U06K6wd3SsaKHZLt3I+mSO7eLw7YeLaGqupaSPwgb8dtULIWUrXUaF1Xt3u/+m3m7dC7Cu2j0W5ITclBlKF0UVig2OkFxjZnkVVzm7gi9N1DUro79mFb7W1aLLLSZS2FLkNoNaJAoOnnp3iLB8FwzmKBVqa8dc2E56hpSzfTlh8u+vXObIT6WHiip6hZUd9/hoz9wLlzI2saAq7+15+XhlmfvXZaV4rboGNW5Uh5SQ4E/ftrlUEJb5nbqw5SeS9loELb/AHD9Vur8sEFqvEV6/ZqWZ8btaAlWawtRBEBTVRp4mimfQUGtQSDqJlC0uJIA6BEgU36r2AJFSsknxqf36yx8btg4rUmh2XOtJ3JIJ80k11s90baBrPN9a3B8FGojrQ8V/wAFd9GQ82jk8ingpSeQpXVd19hoFoMjiCKVVrsPaRD4F83fuazjNqpDtfOLilIIPELAArX7gNWMkRSUdoFy0O5x1Cc609n8pyyM1NRHbgRHBVtUkEKUPPgNx9+pLjNMjFG6pc20MjqlX2B9Oz6WmmZd54N/+89lvjUHqATpDJ3E/UACp23RhsW+Kuls+nftlb/zJWOxLhJP95JmIDqlHz9VRqt32XmcdX0PsRMVtEzYVXjfPpw7XX1ttt7EbcpLRKke217e52r6CK6XxZG8qSyQmntUxjhdo5oCV7LvphfxO/ImYPDcetEk8lWivJTLgO/tqJ3SRTbw1ccD3WS707itaJZd41gHKJWqy9gsyvA5z4zNpbcpT3TycA8+Ka0P26uMmRDmVaBT2pfHZvB1Vqu30xXaZbExWsgbQ6hIA5MbVI+B0vN+9p0ARrrfmKFK1kn0s9ysOW4/FgN5JGUtSi5EADgKjX1NqPTRLcsYxV4H1JNLjHV0V1wj6ZcxvbKJ96LdrZVQojKBU4PtA20nu+62g0aPxR1phRSpKLY+l6Q2ykJuaeXIVIbpQft1HH3SeoH3ot2Ib4/go69fTreIEZ16JKDzbKeQQpNFKIG/TTK17ljeeLxRCz4c8at1QYDE21Kdih52M6wopWEekg+f2asDZo5G8mmqAbGWHia1S1584f1l73nV81rBbeV/arv01kV5VB+pZmbQ8j0Ta9oot0RY250lakspjKUlZSQFAA0rqn96RwPxknqAE0O6tHaIe+7EdTQq92O+u3aI+hwAKjr4mlSBt9mvha5sDEeTQadSu6XNpHC4U8F7zLdFuKEJlUkIQrkEE1TyIpuPs1FFM6I+XRah4Oyr0CKLbMfQn8tmv5aB030bLJ6rAeqOLQ6OivOf5jd7D2KyjIEu0Vj7BRFeSKr9vkAU/vofhrpHaGXuZrcQV0Y4MHuP6Vp7lR54I7e/r10J+5JfdFQrhEteRFppu4vsNPyF1ApzTUjfoKnV0yFvJC8kNrxI16ruWIvA6ENc4UoqL3qN+ufa2Fe7fOSLM5c0R8hhNuAoW82mrKvH1BOr329cPljAcKFch71s4I5iYTyb1P8AggZiWMWS9QWZL6noDzYHvuUq24snatOm2g8/lprRpDQs4TDW1zFU+X3fxRKuTDUGLExjG3yiRMeSZDzCa0QEiv7dVGC7uXVuH6cenQ1VsfBE2NsMYB8T1RitWOW+2iBbVNJcehRlD3KbqUsUUTXVCvb+Z8j3k7misLI42QtbTUK2HF4pu2NQILSY63XVPOv0BUmgry30rZfOcx5efAfaUuu5mt6Kpd64GUZDaX8dl5Y23ZLS+qc3BKQ0FqQ2SQpYPhXkBq49ndwSBsVu1tRU7k9SSfzSe+xEc0Tp3Hjp0p0WXM5LV6vs9L8xUFtSS3AfbqAHEkpCnOtajbX0bHK1kbaDXwXJIbWK9u3NlOlCB/pdEZOw/fN7s/kN1x/MYkm84XlKBb7rbUuUS2XVJT8622dlEJFD5/doW+tWXTeI3UFvJP2/e+lLoTtTZSHc+wtYF3Au1oYubaWmlNTrO+lYCww+kONHbxodVFthKalgpQ0+xfUOGzVre2oZO9uoGhPsXVf+8ueXqZjpvGTPTbba1JLMRr0ggJ9RcCdlKCeldWGGxlubZzHNAPsXB++cUMZdtnieDG7kaDpQhGvAO79gzDIbvamY0h8qgMm3zZaKOJfYc5lddykUPH7Nc07l7ddZeZ9aLbA58XgAj1puvbvl2/dyDD5EOMsx35zkT5iMlRJK1yWgpCV09O51ntu4jim9UDUClEz7mJmthH0JqqE8iRFtMzB7up9bUBiPEZnuirrZbB+RmBXmAKV8SFDR0hkbO6QAFrzt4IK1Y19qIv5mjfqiL257t2hK3MWzWMbZcLOylF3gP1VBmNLASmXFc/D66VKSR8NQT4WSB3qQOJB6eC1t8rVvoTjruUe7FN7P9ubRcbnY34iTdHhLdbZKFrU6vZCUhKRtU6bWb7hsVZN/BRyRWxkpFrVezkR6+4Qq52mOiLdZzK5cNt01TzW4pQC/tB1xLJXDG5LzijSTyp7SV0rHvJiaw7EUSjS+4CX35+P3xDdpv8NftTIUlIdjOKT1HLwrq6xYNzeMsVXMOxGjgk2WMcExj/FTljfRLZQqNbYqG009UUpWk/Gmg7thYfM4/Wl0QDtlI3ezvhl2VaHmmrqW/wAqK4KIcPkB4agtrltQ2QEs8fBSOtCRUHVR/b6TfokeVFvVoegyG3DRxSuSFgnqDqbMRwPcHRPBFFvZQv4uLgajb2r+3jvFjtqvX6QuMHUNmkuQNyg+WvW3bVxND6gPuCxLlo4XtYdyNfYq7f8AvLiEwtWmCpxEuWUpbcKTwTU9CdG2fbN2ysj6UCjky7C7iEYLdNgWnH0vynWkI9rmtaiAK0rtqtzRPmno0HdNnkNYC40X97X3pV2t/ex9tk/prmGxDGl09Cz/ADVYU0B+/Vvt7X0bO5BPm9IVH/8AVjSW8801sRsZDT/ypVc2Fy41okfpLntPqbKS4K1p/FTy1QY4mTzhsn1e/oibx79goD5ZH6V+IfMe9z5ePLr/AE6Ko/1+FPZRY9U+lTSqyu7YPojZficlQHBt5hR2rtRI/p19J9zwl2MkroTt7VVf28aJb6NvgtnMDyJ6+2HB5ny6mIsHI8ujIURTkEw7AQr7CVq1WOwrFlvbMbUEmRzv/ZYPyCdfuW1zL2YDb0ov+tJ/FF35tT5oFJCf4hQV10/UuoFxwNAAHULmKJSZQWpYU0RQJG1a62ot6hW6G0020mgFep9VP3a81YJQS+pO4R4na7I+QCaxHEjem6hTS6+fxH1qxdvW5luBosRnAkoLANDyG/iBTQkAp5uivWaAJEddfBXXt/ZrWq6szL5+ZAadAQnYgmviDqG/ufJoVYuz8A26POQUPtTrxspsqGExIUeO2iM2BHLYTUp8OmufXrpJHEFdntse2FtQKAaKwR5lpu9pkNXFlE9AQT7B8Kagx8xbIBXYqDJW9W67FJTdohavM8MxVR4YeUIySCAEjxqfDV4gla5m+q51ft9OXTZQ98tz9xtz0Zhwha0UqFb/AOnTLGPb',40,'2024-11-27 17:02:24','2024-11-27 17:02:24'),(39,'HẠ LONG- YÊN TỬ  – HÀ NỘI – HỒ CHÍ MINH  (Ăn sáng, trưa)','4','<p>Sáng: Dùng buffet sáng tại khách sạn.&nbsp;</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn khởi hành đi&nbsp; tham quan núi Yên Tử - ngọn núi cao 1068 m so với mực nước biển, một thắng cảnh thiên nhiên còn lưu giữ hệ thống các di tích lịch sử văn hóa gắn với sự ra đời, hình thành và phát triển của thiền phái Trúc Lâm Yên Tử, được mệnh danh là “đất tổ Phật giáo Việt Nam”.</span></p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Yen-Tu/dinh-nui-yen-tu-du-lich-viet.jpg\" alt=\"núi Yên Tử\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Núi Yên Tử</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Quý khách lên núi bằng cáp treo (chi phí cáp treo tự túc), tham quan chùa Hoa Yên, Bảo Tháp, Trúc Lâm Tam Tổ, Hàng Tùng 700 tuổi…xuống núi tham quan Thiền Viện Trúc Lâm với quả cầu Như Ý nặng 6 tấn được xếp kỷ lục guiness Việt Nam.</span></p><p>Trưa: Dùng bữa trưa.&nbsp;</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn trở về Hà Nội.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Hướng dẫn viên tiễn đoàn ra sân bay Nội Bài đón chuyến bay về TP.HCM.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Kết thúc chương trình tham quan, chia tay và hẹn gặp lại.</span></p><p>Giờ bay có thể thay đổi theo quy định của hàng không. Du Lịch Việt sẽ thay đổi chương trình cho phù hợp với giờ bay mới nhưng sẽ không chịu trách nhiệm về các khoản chi phí phát sinh.</p>',40,'2024-11-27 17:03:33','2024-11-27 17:03:33'),(40,'TP.HCM – HÀ NỘI – CÁT CÁT – SAPA (Ăn trưa, chiều)','1','<p>Sáng: Quý khách có mặt tại ga quốc nội, sân bay Tân Sơn Nhất trước giờ bay ít nhất hai tiếng.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đại diện công ty HUFI Travel đón và hỗ trợ Quý Khách làm thủ tục đón chuyến bay đi Hà Nội. Đến sân bay Nội Bài, Hướng dẫn viên đón đoàn khởi hành đến Lào Cai trên con đường cao tốc dài nhất Việt Nam - mạch nối liền giữa Hà Nội và các tỉnh Tây Bắc.</span></p><p>Trưa: Dùng bữa trưa.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn tiếp tục đến thị trấn vùng cao Sapa, tận hưởng cảnh sắc núi rừng như tranh vẽ và khám phá cuộc sống của đồng bào dân tộc ít người miền Tây Bắc.</span></p><p><br></p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Sapa/thi-tran-sapa-mua-thu-du-lich-viet.jpg\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thị Trấn Sapa</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Thăm bản Cát Cát, tìm hiểu nghề dệt nhuộm của dân tộc H’Mông và trạm thủy điện Cát Cát thời Pháp – nơi có 3 dòng nước hợp nhau thành dòng suối Mường Hoa.</span><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Sapa/ban-cat-cat-du-lich-sapa-gia-re(1).jpg\"></p><p>Bản Cát Cát</p><p>Chiều: Dùng bữa chiều. Nghỉ đêm tại Sapa.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Quý khách có thể dạo phố đêm Sapa, tham dự đêm chợ Tình (nếu đi vào tối thứ 7).</span></p><div><br></div>',41,'2024-11-27 17:07:12','2024-11-27 17:07:12'),(41,'SAPA – FANSIPAN (Ăn sáng, trưa, chiều)','2','<p>Sáng: Dùng buffet sáng tại khách sạn.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn khởi hành tham quan chinh phục Fansipan, ngọn núi cao nhất Việt Nam (3.143 m) thuộc dãy núi Hoàng Liên Sơn, cách thị trấn Sa Pa khoảng 9 km về phía tây nam. Du khách chinh phục \"Nóc nhà Đông Dương\" với hệ thống cáp treo Fansipan Sa Pa dài 6,2km đạt 2 kỷ lục Guinness thế giới: Cáp treo ba dây có độ chênh giữa ga đi và ga đến lớn nhất thế giới: 1410m và Cáp treo ba dây dài nhất thế giới: 6292.5m. Từ tuyến cáp treo, du khách có thể cảm nhận được thiên nhiên hùng vĩ, chiêm ngưỡng khung cảnh thung lũng Mường Hoa và rừng quốc gia Hoàng Liên từ trên cao. Ngoài ra, du khách còn có thể đến hành hương tại Khu du lịch tâm linh – Chùa Trình, Chùa Hạ tại ga đến (chi phí cáp treo tự túc).</span><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Sapa/sapa-fansipan-du-lich-viet-2023(1).jpg\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đỉnh núi FASIPAN</p><p>Trưa: Dùng bữa trưa.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Quý khách tự do dạo phố, tham quan nhà thờ đá Sapa,&nbsp;</span></p><p>Chiều: Dùng bữa chiều. Nghỉ đêm tại Sapa.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn tự do dạo phố đêm Sapa, thưởng thức đặc sản vùng cao như: thịt lợn cắp nách nướng, trứng nướng, rượu táo mèo, giao lưu với người dân tộc vùng cao…</span></p><div><br></div>',41,'2024-11-27 17:08:10','2024-11-27 17:08:10'),(42,'LÀO CAI – HÀ NỘI – TP.HCM (Ăn sáng, trưa)','3','<p>&nbsp; &nbsp; &nbsp; Sáng: Dùng buffet sáng tại khách sạn.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Quý khách tự do nghỉ ngơi tại khách sạn.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn trở về Lào Cai, mua sắm đặc sản tại chợ Cốc Lếu.</span></p><p>Trưa: Dùng bữa trưa.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn khởi hành về Hà Nội.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Hướng dẫn viên tiễn đoàn ra sân bay Nội Bài đón chuyến bay về&nbsp; TP.HCM.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Kết thúc chương trình tham quan, chia tay và hẹn gặp lại.</span></p>',41,'2024-11-27 17:08:33','2024-11-27 17:08:33'),(43,'TP. HCM – MỸ THO – CẦN THƠ (Ăn sáng, trưa, chiều)','1','<p>06h30: Xe và Hướng dẫn viên Công ty đón quý khách tại điểm hẹn.</p><p>07h45: Đoàn dừng chân, dùng điểm tâm sáng tại Trung Lương Rest Stop và nghỉ ngơi.</p><p>Sau đó di chuyển đến Chùa Vĩnh Tràng – Một trong những ngôi chùa cổ nổi tiếng nhất Miền Tây. Năm 1984, Chùa Vĩnh Tràng đã được Bộ Văn hóa Thông tin (nay là Bộ Văn hóa Thể thao và Du lịch) xếp hạng di tích cấp Quốc gia.</p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/My-Tho/du-lich-my-tho-chua-vinh-trang-du-lich-viet.jpg\" naptha_cursor=\"region\"></p><p><br></p><p>09h00: Quý Khách đến bến tàu 30/4 TP.Mỹ Tho, thuyền lớn và HDV bản địa đón quý khách thưởng ngoạn sông nước miền Tây Nam bộ.&nbsp;</p><p>●&nbsp; &nbsp; &nbsp; Tham quan tứ linh miệt vườn - 4 cồn Long, Lân, Quy, Phụng.</p><p>●&nbsp; &nbsp; &nbsp; Tìm hiểu cách nuôi cá bè trên sông Tiền.</p><p>●&nbsp; &nbsp; &nbsp; Đoàn trải nghiệm thuyền chèo 3 lá len lỏi trong rạch dừa nước thiên nhiên.</p><p>●&nbsp; &nbsp; &nbsp; Tham quan trang trại nuôi ong mật, uống trà mật ong chanh miễn phí.</p><p>10h30: Đoàn trở ra thuyền lớn đến với tỉnh Bến Tre.</p><p>●&nbsp; &nbsp; &nbsp; Tham quan, tìm hiểu quy trình sản xuất kẹo dừa và làng nghề bánh tráng tại xã Tân Thạnh.&nbsp;</p><p>●&nbsp; &nbsp; &nbsp; Quý khách có trải nghiệm thú vị đi xe ngựa trên đường làng tham quan vườn trái cây, thưởng thức trái cây miễn phí và giao lưu đờn ca tài tử Nam bộ.</p><p>●&nbsp; &nbsp; &nbsp; Công ty mời quý khách mỗi người 1 trái dừa ba nhát đặc sản Bến Tre.&nbsp;</p><p>12h00: Quý khách dùng bữa trưa tại nhà hàng Bến sông quê, quý khách thưởng thức các món ăn Nam bộ đặc trưng và nghỉ ngơi.</p><p>14h00: HDV sẽ đưa đoàn về lại xe để khởi hành về TP.HCM.</p><p>17h00: Đoàn về đến TP.HCM.</p><p>Kết thúc hành trình tour. Chào tạm biệt và hẹn gặp lại.</p>',42,'2024-11-27 17:10:57','2024-11-27 17:10:57'),(44,'TP. HCM – LONG AN (Ăn sáng, trưa)','1','<p>05h00: Xe và hướng dẫn viên Du Lịch Việt đón quý khách đi tại điểm hẹn.</p><p>06h30: Xe ghé nhà hàng để quý khách dùng bữa sáng.Sau đó tiếp tục hành trình Thực đơn sáng: 1 phần tô ( hủ tiếu, phở, bánh canh, cơm sườn) + Trà đá.</p><p>07h45: Quý khách tiếp tục đến với Thiền viện Trúc Lâm Chánh Giác, được mệnh danh là “Tiểu Ấn Độ” giữa lòng Tiền Giang. Đến đây, du khách có thể tận hưởng cảm giác thư thái, yên bình.Đặc biệt ở đây có pho tượng Phật Thích Ca Mâu Ni được tạc bằng đá ngọc, dát vàng, cao 4,5m, nặng trên 30 tấn, do đích thân các nghệ nhân Myanmar chế tác.</p><p>09h00: Quý khách tiếp tục đến với Khu du lịch làng Nổi Tân Lập. Trải nghiệm con đường xuyên rừng bằng bê tông dài tận 5km, đứng trên đài quan sát phóng tầm mắt toàn cảnh rừng tràm bạt ngàn</p><p>12h00: Qúy khách dùng bữa trưa tại Làng Nổi Tân Lập với những món ăn đậm chất miền quê.</p><p>14h00: Xe đưa qúy khách tiếp tục hành trình đến Công viên kỳ quan, du khách sẽ khám phá nhiều mô hình phỏng theo các công trình nổi tiếng thế giới như : Tượng nữ thần tự do, Tháp Eiffel, Nhà hát Opera, Tháp nghiêng Pisa... Tha hồ cho các bạn check in với những tấm ảnh siêu ảo diệu.</p><p>18h00: Qúy khách đến TPHCM, xe đưa Quý khách trở về điểm đón ban đầu. Hướng dẫn viên thay mặt công ty nói lời chia tay và hẹn gặp lại quý khách trong các tour sau.</p>',43,'2024-11-27 17:16:08','2024-11-27 17:16:08'),(45,'TP. HCM – MỸ THO – CẦN THƠ (Ăn sáng, trưa, chiều)','1','<p>&nbsp;06h30: Xe và HDV đón quý khách tại điểm hẹn.</p><p>07h45: Đoàn dừng chân, dùng điểm tâm sáng tại Mekong/ Trung Lương Rest Stop.</p><p><br></p><p>Sau đó di chuyển đến Chùa Vĩnh Tràng – Một trong những ngôi chùa cổ nổi tiếng&nbsp; &nbsp;nhất Miền Tây. Năm 1984, Chùa Vĩnh Tràng đã được Bộ Văn hóa Thông tin (nay là Bộ Văn hóa Thể thao và Du lịch) xếp hạng di tích cấp Quốc gia.<img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Can-Tho/chua-vinh-trang-du-lich-viet.jpg\" alt=\"Chùa Vĩnh Tràng\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chùa Vĩnh Tràng</p><p><br></p><p>09h00: Quý Khách đến bến tàu 30/4 TP.Mỹ Tho, thuyền lớn và HDV bản địa đón quý khách thưởng ngoạn sông nước miền Tây Nam bộ.&nbsp;</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Tham quan tứ linh miệt vườn - 4 cồn Long, Lân, Quy, Phụng.</span></p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/My-Tho/cu-lao-thoi-son-du-lich-viet(1).jpg\" alt=\"Tham quan tứ linh miệt vườn\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tham quan tứ linh miệt vườn</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Tìm hiểu cách nuôi cá bè trên sông Tiền.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Đoàn trải nghiệm thuyền chèo 3 lá len lỏi trong rạch dừa nước thiên nhiên.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Tham quan trang trại nuôi ong mật, uống trà mật ong chanh miễn phí.</span></p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Can-Tho/tham-quan-trang-trai-nuoi-mat-ong-du-lich-viet.jpg\" alt=\"Tham quan trang trại nuôi mật ong\" naptha_cursor=\"text\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tham quan trang trại nuôi mật ong</p><p>10h30: Đoàn trở ra thuyền lớn đến với tỉnh Bến Tre.</p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Tham quan, tìm hiểu quy trình sản xuất kẹo dừa và làng nghề bánh tráng tại xã Tân Thạnh.&nbsp;</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Quý khách có trải nghiệm thú vị đi xe ngựa trên đường làng tham quan vườn trái cây, thưởng thức trái cây miễn phí và giao lưu đờn ca tài tử Nam bộ.</span></p><p><span style=\"white-space: normal;\"><span style=\"white-space:pre\">	</span>Công ty mời quý khách mỗi người 1 trái dừa ba nhát đặc sản Bến Tre.&nbsp;</span></p><p>11h30: Quý khách dùng bữa trưa, quý khách thưởng thức các món ăn Nam bộ đặc trưng và nghỉ ngơi.</p><p>Sau đó lên tàu trở về bến tàu Mỹ Tho. Trên đường nghe giới thiệu về Cồn Phụng - tìm hiểu di tích Ông Đạo Dừa và các công trình kiến trúc của ông trên cồn...</p><p><img src=\"https://dulichviet.com.vn/images/bandidau/NOI-DIA/Can-Tho/di-tich-dao-dua-con-phung-du-lich-viet(1).jpg\" alt=\"Cồn Phụng\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cồn Phụng</p><p>Sau đó, đoàn di chuyển đến Cần Thơ để nhận phòng khách sạn.</p><p>18h30: Đoàn ăn tối tại Du thuyền Ninh Kiều 5*. Quý khách tham quan tự do TP.Cần Thơ về đêm.&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><div><br></div>',44,'2024-11-28 00:21:55','2024-11-28 00:21:55'),(46,'Chợ Nổi – KDL Mỹ Khánh – TP.HCM (ăn sáng, trưa)','2','<p>&nbsp;05h30: Đoàn khởi hành tham quan Chợ nổi Cái Răng – một trải nghiệm thú vị ở miền Tây sông nước. Thuyền ghé Làng hủ tiếu truyền thống, quý khách thưởng thức món “pizza hủ tiếu”.</p><p>07h00: Quý khách trở về khách sạn để dùng buffet sáng và&nbsp; sắp xếp hành lý trả phòng.&nbsp;</p><p>08h00: Đoàn tham quan Làng du lịch Mỹ Khánh : tại đây, quý khách tìm hiểu về ngôi nhà cổ 3 gian truyền thống văn hoá miền Nam,quý khách&nbsp; xem chương trình đua chó, đua heo,tham quan vườn thú,vườn trái cây và tham gia các trò chơi tại Mỹ Khánh hoặc có thể thử câu cá sấu tại làng du lịch Mỹ Khánh.</p><p>11h30: Quý khách dùng bữa trưa tại nhà hàng với món đặc sản miền tây.&nbsp;</p><p>13h00: Đoàn tham quan: Thiền Viện trúc lâm Phương Nam quý khách viếng Thiền Viện lớn nhất miền Tây. Quý khách được chiêm ngưỡng công trình kiến túc phật giáo mang vẻ đẹp của thời Lý – Trần.</p><p>17h00: Về tới TP.HCM, xe và HDV tiễn quý khách. Kết thúc chuyến đi.</p><p>Chào tạm biệt và hẹn gặp lại.</p>',44,'2024-11-28 00:22:24','2024-11-28 00:22:24');
/*!40000 ALTER TABLE `chuongtrinhtour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `danhgia`
--

DROP TABLE IF EXISTS `danhgia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `danhgia` (
  `madanhgia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `noidung` varchar(255) NOT NULL,
  `diemdanhgia` int(10) unsigned NOT NULL,
  `makhachhang` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `matour` int(11) DEFAULT NULL,
  `tinhtrang` int(11) DEFAULT 0,
  PRIMARY KEY (`madanhgia`),
  KEY `danhgia_makhachhang_foreign` (`makhachhang`),
  CONSTRAINT `danhgia_makhachhang_foreign` FOREIGN KEY (`makhachhang`) REFERENCES `khachhang` (`makhachhang`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `danhgia`
--

LOCK TABLES `danhgia` WRITE;
/*!40000 ALTER TABLE `danhgia` DISABLE KEYS */;
/*!40000 ALTER TABLE `danhgia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diemdulich`
--

DROP TABLE IF EXISTS `diemdulich`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diemdulich` (
  `madiemdulich` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tendiemdulich` varchar(255) NOT NULL,
  `motadiemdulich` varchar(255) NOT NULL,
  PRIMARY KEY (`madiemdulich`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diemdulich`
--

LOCK TABLES `diemdulich` WRITE;
/*!40000 ALTER TABLE `diemdulich` DISABLE KEYS */;
INSERT INTO `diemdulich` VALUES (1,'Đà Nẵng','Thiên đường du lịch'),(2,'Đảo Phú Quốc','Thiên đường du lịch'),(3,'Lăng Bác','Lăng chủ tịch Hồ Chí Minh'),(4,'Điện Biên','Tham quan di tích lịch sử'),(5,'Phan Si Băng','Khám phá vùng rừng núi rộng lớn'),(6,'Mộc Châu','Khám phá núi non hùng vĩ'),(7,'Yên Bái','Khám phá các tỉnh miền núi'),(8,'Hạ Long','Khung cảnh non nước tráng lệ'),(9,'Hà Nội','Thủ đô nước Việt Nam'),(10,'Lào Cai','Các tỉnh miền núi'),(11,'Quảng Ninh','Kỳ quan thế giới'),(12,'Thái Nguyên','Các tỉnh miền núi'),(13,'Huế','Kinh thành kì vĩ'),(14,'Tiền Giang','Các tỉnh miền Tây sông nước');
/*!40000 ALTER TABLE `diemdulich` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_grid_ones`
--

DROP TABLE IF EXISTS `footer_grid_ones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_grid_ones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logo` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_grid_ones`
--

LOCK TABLES `footer_grid_ones` WRITE;
/*!40000 ALTER TABLE `footer_grid_ones` DISABLE KEYS */;
INSERT INTO `footer_grid_ones` VALUES (1,'frontend/images/uploads/logo/media_6731feb1977a0.png','0329 951 368','contact@hufitravel.com','140 Lê Trọng Tấn, Tây Thạnh, Tân Phú, TP. HCM','Copyright © 2024 by HUFI Travel. All Rights Reserved.','2023-04-25 08:22:10','2024-11-11 05:55:13');
/*!40000 ALTER TABLE `footer_grid_ones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_grid_threes`
--

DROP TABLE IF EXISTS `footer_grid_threes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_grid_threes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_grid_threes`
--

LOCK TABLES `footer_grid_threes` WRITE;
/*!40000 ALTER TABLE `footer_grid_threes` DISABLE KEYS */;
INSERT INTO `footer_grid_threes` VALUES (2,'Chính sách bảo mật','http://127.0.0.1:8000/',1,'2023-04-26 04:07:03','2024-11-11 06:00:14'),(3,'Điều khoản dịch vụ','http://127.0.0.1:8000/',1,'2023-05-07 02:40:39','2024-11-11 06:00:33'),(4,'Câu hỏi thường gặp','http://127.0.0.1:8000/',1,'2023-05-07 02:40:52','2024-11-11 06:00:58'),(5,'Phương thức thanh toán','http://127.0.0.1:8000/',1,'2023-05-07 02:41:05','2024-11-11 06:01:18'),(6,'Hợp đồng đặt tour','http://127.0.0.1:8000/',1,'2023-05-07 02:41:33','2024-11-11 06:01:30');
/*!40000 ALTER TABLE `footer_grid_threes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_grid_twos`
--

DROP TABLE IF EXISTS `footer_grid_twos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_grid_twos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_grid_twos`
--

LOCK TABLES `footer_grid_twos` WRITE;
/*!40000 ALTER TABLE `footer_grid_twos` DISABLE KEYS */;
INSERT INTO `footer_grid_twos` VALUES (2,'Trang Chủ','http://127.0.0.1:8000/',1,'2023-04-26 02:19:52','2024-11-11 05:56:05'),(3,'Giới Thiệu','http://127.0.0.1:8000/gioi-thieu',1,'2023-05-07 02:35:21','2024-11-11 05:57:31'),(4,'Dịch Vụ','http://127.0.0.1:8000/',1,'2023-05-07 02:36:23','2024-11-11 05:56:48'),(5,'Liên Hệ','http://127.0.0.1:8000/lien-he',1,'2023-05-07 02:37:54','2024-11-11 05:57:20'),(6,'Career','https://www.linkedin.com/',0,'2023-05-07 02:40:18','2024-11-11 05:57:51');
/*!40000 ALTER TABLE `footer_grid_twos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_socials`
--

DROP TABLE IF EXISTS `footer_socials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_socials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_socials`
--

LOCK TABLES `footer_socials` WRITE;
/*!40000 ALTER TABLE `footer_socials` DISABLE KEYS */;
INSERT INTO `footer_socials` VALUES (3,'fab fa-twitter','Twitter','https://www.skillshare.com/en/classes/Inspiration-To-Reality-Make-A-Vision-Board-For-Your-Goals/783727951',1,'2023-04-26 01:13:12','2024-10-06 01:48:42'),(4,'fab fa-facebook-f','Facebook','https://www.skillshare.com/en/classes/Inspiration-To-Reality-Make-A-Vision-Board-For-Your-Goals/783727951',1,'2023-04-26 01:21:42','2023-04-26 01:21:42'),(5,'fab fa-linkedin-in','linkedin','https://www.linkedin.com/',1,'2023-05-07 02:23:54','2023-05-07 02:23:54'),(6,'fab fa-instagram','instagram','https://www.linkedin.com/',1,'2023-05-07 02:24:19','2023-05-07 02:24:19');
/*!40000 ALTER TABLE `footer_socials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_titles`
--

DROP TABLE IF EXISTS `footer_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_titles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `footer_grid_two_title` varchar(255) DEFAULT NULL,
  `footer_grid_three_title` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_titles`
--

LOCK TABLES `footer_titles` WRITE;
/*!40000 ALTER TABLE `footer_titles` DISABLE KEYS */;
INSERT INTO `footer_titles` VALUES (1,'Liên hệ','Hỗ trợ khách hàng','2023-04-26 03:15:52','2023-04-26 04:11:00');
/*!40000 ALTER TABLE `footer_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hinhanhtour`
--

DROP TABLE IF EXISTS `hinhanhtour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hinhanhtour` (
  `mahinhanh` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenhinh` varchar(255) NOT NULL,
  `duongdan` varchar(255) NOT NULL,
  `matour` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mahinhanh`),
  KEY `hinhanhtour_matour_foreign` (`matour`),
  CONSTRAINT `hinhanhtour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hinhanhtour`
--

LOCK TABLES `hinhanhtour` WRITE;
/*!40000 ALTER TABLE `hinhanhtour` DISABLE KEYS */;
/*!40000 ALTER TABLE `hinhanhtour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoadon`
--

DROP TABLE IF EXISTS `hoadon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hoadon` (
  `mahoadon` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tongsotien` double(8,2) unsigned NOT NULL,
  `trangthaithanhtoan` varchar(255) NOT NULL,
  `phuongthucthanhtoan` varchar(255) NOT NULL,
  `masothue` varchar(255) DEFAULT NULL,
  `tendonvi` varchar(255) DEFAULT NULL,
  `diachidonvi` varchar(255) DEFAULT NULL,
  `nguoidaidien` varchar(255) DEFAULT NULL,
  `maphieuhuytour` int(10) unsigned DEFAULT NULL,
  `maphieudattour` int(10) unsigned NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mahoadon`),
  KEY `hoadon_maphieudattour_foreign` (`maphieudattour`),
  KEY `hoadon_maphieuhuytour_foreign` (`maphieuhuytour`),
  CONSTRAINT `hoadon_maphieudattour_foreign` FOREIGN KEY (`maphieudattour`) REFERENCES `phieudattour` (`maphieudattour`) ON DELETE CASCADE,
  CONSTRAINT `hoadon_maphieuhuytour_foreign` FOREIGN KEY (`maphieuhuytour`) REFERENCES `phieuhuytour` (`maphieuhuytour`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoadon`
--

LOCK TABLES `hoadon` WRITE;
/*!40000 ALTER TABLE `hoadon` DISABLE KEYS */;
INSERT INTO `hoadon` VALUES (25,800000.00,'Đang chờ thanh toán','Thanh toán trực tiếp',NULL,NULL,'Le Trong Tấn','Vo Hoan Kien',NULL,42,0,NULL,NULL);
/*!40000 ALTER TABLE `hoadon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khachhang`
--

DROP TABLE IF EXISTS `khachhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `khachhang` (
  `makhachhang` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hoten` varchar(255) NOT NULL,
  `cccd` varchar(15) DEFAULT NULL,
  `gioitinh` varchar(255) DEFAULT 'Nam',
  `ngaysinh` date DEFAULT NULL,
  `diachi` varchar(255) DEFAULT NULL,
  `sodienthoai` varchar(255) DEFAULT NULL,
  `hinhdaidien` varchar(255) DEFAULT NULL,
  `maloaikhachhang` int(10) unsigned DEFAULT NULL,
  `mataikhoan` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`makhachhang`),
  KEY `khachhang_maloaikhachhang_foreign` (`maloaikhachhang`),
  KEY `khachhang_mataikhoan_foreign` (`mataikhoan`),
  CONSTRAINT `khachhang_maloaikhachhang_foreign` FOREIGN KEY (`maloaikhachhang`) REFERENCES `loaikhachhang` (`maloaikhachhang`) ON DELETE CASCADE,
  CONSTRAINT `khachhang_mataikhoan_foreign` FOREIGN KEY (`mataikhoan`) REFERENCES `users` (`mataikhoan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khachhang`
--

LOCK TABLES `khachhang` WRITE;
/*!40000 ALTER TABLE `khachhang` DISABLE KEYS */;
INSERT INTO `khachhang` VALUES (2,'Võ Nhựt Hào',NULL,'Nam','0000-00-00','Bình Dương','0388533247','aaa',1,85),(3,'Võ Nhựt Hào',NULL,'Nam','0000-00-00','Bình Dương','0388533247','aaa',1,83),(5,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(6,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(7,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(8,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(9,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(10,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(11,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(12,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(13,'Hào',NULL,'Nam','1111-11-11','','','',1,NULL),(14,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(15,'Vương',NULL,'Nam','2003-09-18','','','',2,NULL),(16,'Kôn',NULL,'Nam','2003-09-18','','','',3,NULL),(17,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(18,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(19,'Vương',NULL,'Nam','2003-09-18','','','',2,NULL),(20,'Kiên',NULL,'Nam','2003-09-18','','','',3,NULL),(21,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(22,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(23,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(24,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(25,'Hào',NULL,'Nam','2003-07-18','','','',1,NULL),(26,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(27,'Hào',NULL,'Nam','2003-09-18','','','',1,NULL),(28,'Trần Trọng Vương',NULL,'Nam','2024-10-29','','','',1,NULL),(29,'Võ Hoàn Kien',NULL,'Nam','2024-10-29','','','',1,NULL),(30,'Trần Trọng Vương',NULL,'Nam','2024-10-28','','','',1,NULL),(31,'Võ Hoàn Kien',NULL,'Nam','2024-10-28','','','',1,NULL),(32,'Trần Trọng Vương',NULL,'Nam','2024-10-31','','','',1,NULL),(33,'Trần Trọng Vương',NULL,'Nam','2024-12-05','','','',1,NULL),(34,'Trần Trọng Vương',NULL,'Nam','2024-10-31','','','',1,NULL),(35,'Trần Trọng Vương',NULL,'Nam','2024-10-31','','','',1,NULL),(36,'Trần Trọng Vương',NULL,'Nam','2024-11-14','','','',1,NULL),(37,'Trần Trọng Vương',NULL,'Nam','2024-11-14','','','',1,NULL),(38,'Trần Trọng Vương',NULL,'Nam','2024-11-14','','','',1,NULL),(39,'Trần Trọng Vương',NULL,'Nam','2024-11-13','','','',1,NULL),(40,'Trần Trọng Vương',NULL,'Nam','2024-11-13','','','',1,NULL),(41,'Trần Trọng Vương',NULL,'Nam','2024-11-29','','','',1,NULL),(42,'Trần Trọng An',NULL,'Nam','2024-11-21','','','',1,NULL),(43,'Trần Trọng Vương',NULL,'Nam','2024-11-21','','','',1,NULL),(44,'Trần Văn Vu',NULL,'Nam','2024-11-21','','','',1,NULL),(45,'Trần Trọng Vương',NULL,'Nam','2024-11-21','','','',1,NULL),(46,'Trần Văn Vu',NULL,'Nam','2024-11-21','','','',1,NULL),(47,'Trần Trọng Vương',NULL,'Nam','2024-11-21','','','',1,NULL),(48,'Trần Văn Vu',NULL,'Nam','2024-11-21','','','',1,NULL),(49,'Trần Trọng Vương',NULL,'Nam','2024-11-21','','','',1,NULL),(50,'Trần Văn Vu',NULL,'Nam','2024-11-21','','','',1,NULL),(51,'Trần Trọng Vương',NULL,'Nam','2024-11-21','','','',1,NULL),(52,'Trần Văn Vu',NULL,'Nam','2024-11-21','','','',1,NULL),(53,'Võ Hoàn Kiên',NULL,'Nam','2003-03-21','','','',1,NULL),(54,'Võ Hoàn Na',NULL,'Nam','2024-11-07','','','',1,NULL),(78,'Võ Hoàn Kiên','051203008704',NULL,NULL,'Le Trong Tấn','0000000000',NULL,1,124),(79,'Trần Trọng Vương','213567895678','Nam','2003-07-14',NULL,'0321651815',NULL,1,NULL),(80,'Võ Hoàn Na','213567895678','Nam','2003-06-15',NULL,'0321651815',NULL,1,NULL),(81,'Vo Hoan Kien','200121589','Nam',NULL,'Le Trong Tấn','0965682178',NULL,1,125),(82,'Trần Trọng Vương','213567895678','Nam','2003-02-12',NULL,'0965682178',NULL,1,NULL);
/*!40000 ALTER TABLE `khachhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khachsan`
--

DROP TABLE IF EXISTS `khachsan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `khachsan` (
  `makhachsan` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenkhachsan` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `sodienthoai` varchar(255) NOT NULL,
  `chatluong` varchar(255) NOT NULL,
  `giakhachsan` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`makhachsan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khachsan`
--

LOCK TABLES `khachsan` WRITE;
/*!40000 ALTER TABLE `khachsan` DISABLE KEYS */;
INSERT INTO `khachsan` VALUES (2,'Khách sạn Á ÂU','112 Tân Kỳ Tân Quý','01256385526','3',123123.00,'2024-11-04 09:29:22','2024-11-20 16:33:35'),(3,'Khách sạn Tân Thời','145 Đinh Tiên Hoàng, TP Hồ Chí Minh','01256385526','4',60000.00,'2024-11-05 05:34:54','2024-11-05 05:34:54');
/*!40000 ALTER TABLE `khachsan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `khuyenmai`
--

DROP TABLE IF EXISTS `khuyenmai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `khuyenmai` (
  `makhuyenmai` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thoigianbatdau` date NOT NULL,
  `thoigianketthuc` date NOT NULL,
  `phantramgiam` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`makhuyenmai`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `khuyenmai`
--

LOCK TABLES `khuyenmai` WRITE;
/*!40000 ALTER TABLE `khuyenmai` DISABLE KEYS */;
INSERT INTO `khuyenmai` VALUES (1,'2024-11-01','2024-12-02',8.00,'2024-10-30 15:50:39','2024-10-30 15:50:39'),(2,'2024-10-04','2024-11-08',7.00,'2024-10-30 15:50:54','2024-10-30 15:50:54'),(3,'2024-10-17','2024-12-19',6.00,'2024-10-30 15:51:07','2024-10-30 15:51:07');
/*!40000 ALTER TABLE `khuyenmai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loaiblog`
--

DROP TABLE IF EXISTS `loaiblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loaiblog` (
  `maloaiblog` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenloaiblog` varchar(255) NOT NULL,
  PRIMARY KEY (`maloaiblog`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loaiblog`
--

LOCK TABLES `loaiblog` WRITE;
/*!40000 ALTER TABLE `loaiblog` DISABLE KEYS */;
INSERT INTO `loaiblog` VALUES (2,'Giới thiệu tour du lịch miền Bắc'),(3,'Giới thiệu tour du lịch miền Nam'),(4,'Những điều nên và không nên khi đi dã ngoại');
/*!40000 ALTER TABLE `loaiblog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loaikhachhang`
--

DROP TABLE IF EXISTS `loaikhachhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loaikhachhang` (
  `maloaikhachhang` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenloaikhachhang` varchar(255) NOT NULL,
  `mucapdunggia` int(11) NOT NULL,
  PRIMARY KEY (`maloaikhachhang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loaikhachhang`
--

LOCK TABLES `loaikhachhang` WRITE;
/*!40000 ALTER TABLE `loaikhachhang` DISABLE KEYS */;
INSERT INTO `loaikhachhang` VALUES (1,'Người lớn',0),(2,'Trẻ em',70),(3,'Trẻ em (dưới 5 tuổi)',100);
/*!40000 ALTER TABLE `loaikhachhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loaitour`
--

DROP TABLE IF EXISTS `loaitour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loaitour` (
  `maloaitour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenloai` varchar(255) NOT NULL,
  PRIMARY KEY (`maloaitour`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loaitour`
--

LOCK TABLES `loaitour` WRITE;
/*!40000 ALTER TABLE `loaitour` DISABLE KEYS */;
INSERT INTO `loaitour` VALUES (2,'MÙA ĐÔNG'),(3,'MÙA HÈ'),(5,'LỄ 2/9'),(7,'MÙA THU'),(8,'MÙA HÈ'),(9,'TẾT NGUYÊN ĐÁN'),(10,'MIỀN TÂY');
/*!40000 ALTER TABLE `loaitour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_reset_tokens_table',1),(2,'2019_08_19_000000_create_failed_jobs_table',1),(3,'2019_12_14_000001_create_personal_access_tokens_table',1),(4,'2024_10_01_000000_create_nhomquyen_table',1),(5,'2024_10_01_000001_create_users_table',1),(6,'2024_10_02_084917_create_loaikhachhang_table',1),(7,'2024_10_17_084918_create_khachhang_table',1),(8,'2024_10_17_085812_create_phongban_table',1),(9,'2024_10_17_085813_create_nhanvien_table',1),(10,'2024_10_17_090205_create_chucvu_table',1),(11,'2024_10_17_090312_create_phancongchucvu_table',1),(12,'2024_10_17_090613_create_loaiblog_table',1),(13,'2024_10_17_090701_create_blogtour_table',1),(14,'2024_10_17_091118_create_loaitour_table',1),(15,'2024_10_17_091250_create_khuyenmai_table',1),(16,'2024_10_17_091717_create_tour_table',1),(17,'2024_10_17_092130_create_hinhanhtour_table',1),(18,'2024_10_17_092352_create_diemdulich_table',1),(19,'2024_10_17_092505_create_chitiettour_table',1),(20,'2024_10_17_094554_create_chuongtrinhtour_table',1),(21,'2024_10_17_095016_create_phuongtien_table',1),(22,'2024_10_17_095200_create_phuongtien_tour_table',1),(23,'2024_10_17_095545_create_khachsan_table',1),(24,'2024_10_17_095733_create_khachsan_tour_table',1),(25,'2024_10_17_095928_create_phancongnhanvien_table',1),(26,'2024_10_17_100046_create_phieudattour_table',1),(27,'2024_10_17_100316_create_chitietphieudattour_table',1),(28,'2024_10_17_100318_create_phieuhuytour_table',1),(29,'2024_10_17_100319_create_hoadon_table',1),(30,'2024_10_17_101059_create_danhgia_table',1),(31,'2024_10_30_042302_create_quyen_table',1),(32,'2024_10_30_042507_create_quyen_nhomquyen_table',1),(33,'2024_10_11_224709_create_backup_schedules_table',2),(34,'2024_10_11_225319_create_backup_schedules_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhanvien`
--

DROP TABLE IF EXISTS `nhanvien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nhanvien` (
  `manhanvien` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hoten` varchar(255) DEFAULT 'Chưa có',
  `gioitinh` varchar(255) DEFAULT 'Chưa có',
  `ngaysinh` date DEFAULT NULL,
  `sodienthoai` varchar(255) DEFAULT 'Chưa có',
  `bangcap` varchar(255) DEFAULT 'Chưa có',
  `hinhdaidien` varchar(255) DEFAULT 'Chưa có',
  `ngayvaolam` date DEFAULT NULL,
  `tinhtrang` tinyint(1) DEFAULT NULL,
  `maphongban` int(10) unsigned DEFAULT 0,
  `mataikhoan` int(10) unsigned NOT NULL,
  PRIMARY KEY (`manhanvien`),
  KEY `nhanvien_maphongban_foreign` (`maphongban`),
  KEY `nhanvien_mataikhoan_foreign` (`mataikhoan`),
  CONSTRAINT `nhanvien_maphongban_foreign` FOREIGN KEY (`maphongban`) REFERENCES `phongban` (`maphongban`) ON DELETE CASCADE,
  CONSTRAINT `nhanvien_mataikhoan_foreign` FOREIGN KEY (`mataikhoan`) REFERENCES `users` (`mataikhoan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhanvien`
--

LOCK TABLES `nhanvien` WRITE;
/*!40000 ALTER TABLE `nhanvien` DISABLE KEYS */;
INSERT INTO `nhanvien` VALUES (2,'Võ Hoàn Kiên','Nam','2323-03-12','01256385526','Bằng cấp 3',NULL,'2024-11-06',1,1,27),(3,'Carolanne Smitham','Nữ','2000-06-15','(651) 658-8104','Chưa có','Null','2024-11-09',0,1,33),(4,'Ms. Odessa Lindgren','Nam','2000-06-15','+1.743.443.4058','Chưa có','Null','2024-11-09',0,1,34),(5,'Dr. Jamir Klein II','Nữ','2000-06-15','616.371.6564','Chưa có','Null','2024-11-09',0,1,35),(6,'Samara Ebert','Nữ','2000-06-15','+1-304-373-5167','Chưa có','Null','2024-11-09',0,1,36),(7,'Madelynn Kreiger','Nữ','2000-06-15','+1-806-808-5740','Chưa có','Null','2024-11-09',0,1,37),(8,'Laura Kling','Nam','2000-06-15','480-861-4371','Chưa có','Null','2024-11-09',0,1,38),(9,'Miss Jazmyn O\'Keefe','Nữ','2000-06-15','272-710-9834','Chưa có','Null','2024-11-09',0,1,39),(10,'Cordie Wyman','Nam','2000-06-15','+1.769.390.0890','Chưa có','Null','2024-11-09',0,1,40),(45,'Ramona Hoppe PhD','Nữ','2000-06-15','442.403.5220','Chưa có','Null','2024-11-09',0,1,75),(46,'Yasmin Jast','Nam','2000-06-15','+18569413008','Chưa có','Null','2024-11-09',1,5,76),(47,'Esta VonRueden','Nữ','2000-06-15','402.796.4367','Chưa có','Null','2024-11-09',0,1,77),(48,'Dr. Juwan Bauch','Nữ','2000-06-15','1-706-539-4860','Chưa có','Null','2024-11-09',0,1,78),(49,'Abelardo Gulgowski','Nam','2000-06-15','283-856-1868','Chưa có','Null','2024-11-09',0,1,79),(50,'Ethel Bradtke','Nam','2000-06-15','330-529-8998','Chưa có','Null','2024-11-09',0,1,80),(51,'Chloe Schultz','Nữ','2000-06-15','+1.669.361.8819','Chưa có','Null','2024-11-09',0,1,81),(52,'Antonio DuBuque','Nam','2000-06-15','531.588.8062','Chưa có','Null','2024-11-09',0,1,83);
/*!40000 ALTER TABLE `nhanvien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nhomquyen`
--

DROP TABLE IF EXISTS `nhomquyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nhomquyen` (
  `manhomquyen` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tennhomquyen` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`manhomquyen`),
  UNIQUE KEY `nhomquyen_tennhomquyen_unique` (`tennhomquyen`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nhomquyen`
--

LOCK TABLES `nhomquyen` WRITE;
/*!40000 ALTER TABLE `nhomquyen` DISABLE KEYS */;
INSERT INTO `nhomquyen` VALUES (1,'Admin',NULL,NULL),(2,'User',NULL,NULL),(3,'Thu Ngân',NULL,NULL);
/*!40000 ALTER TABLE `nhomquyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phancongchucvu`
--

DROP TABLE IF EXISTS `phancongchucvu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phancongchucvu` (
  `manhanvien` int(10) unsigned NOT NULL,
  `machucvu` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`manhanvien`,`machucvu`),
  KEY `phancongchucvu_machucvu_foreign` (`machucvu`),
  CONSTRAINT `phancongchucvu_machucvu_foreign` FOREIGN KEY (`machucvu`) REFERENCES `chucvu` (`machucvu`) ON DELETE CASCADE,
  CONSTRAINT `phancongchucvu_manhanvien_foreign` FOREIGN KEY (`manhanvien`) REFERENCES `nhanvien` (`manhanvien`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phancongchucvu`
--

LOCK TABLES `phancongchucvu` WRITE;
/*!40000 ALTER TABLE `phancongchucvu` DISABLE KEYS */;
INSERT INTO `phancongchucvu` VALUES (2,2,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(2,3,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(2,4,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(6,5,'2024-11-09 17:00:00','2024-11-09 17:00:00'),(46,5,'2024-11-09 17:00:00','2024-11-09 17:00:00'),(46,6,'2024-11-09 17:00:00','2024-11-09 17:00:00');
/*!40000 ALTER TABLE `phancongchucvu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phancongnhanvien`
--

DROP TABLE IF EXISTS `phancongnhanvien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phancongnhanvien` (
  `manhanvien` int(10) unsigned NOT NULL,
  `matour` int(10) unsigned NOT NULL,
  `nhiemvu` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`manhanvien`,`matour`),
  KEY `phancongnhanvien_matour_foreign` (`matour`),
  CONSTRAINT `phancongnhanvien_manhanvien_foreign` FOREIGN KEY (`manhanvien`) REFERENCES `nhanvien` (`manhanvien`) ON DELETE CASCADE,
  CONSTRAINT `phancongnhanvien_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phancongnhanvien`
--

LOCK TABLES `phancongnhanvien` WRITE;
/*!40000 ALTER TABLE `phancongnhanvien` DISABLE KEYS */;
INSERT INTO `phancongnhanvien` VALUES (2,40,'Thu ngân','2024-12-11 08:36:01','2024-12-11 08:36:01');
/*!40000 ALTER TABLE `phancongnhanvien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phieudattour`
--

DROP TABLE IF EXISTS `phieudattour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phieudattour` (
  `maphieudattour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `matour` int(10) unsigned NOT NULL,
  `ngaydattour` date NOT NULL,
  `ngaybatdau` date DEFAULT NULL,
  `tongtienphieudattour` double(8,2) unsigned NOT NULL,
  `trangthaidattour` varchar(255) NOT NULL,
  `tongsoluong` int(11) NOT NULL,
  `nguoidaidien` varchar(255) NOT NULL,
  PRIMARY KEY (`maphieudattour`),
  KEY `phieudattour_matour_foreign` (`matour`),
  CONSTRAINT `phieudattour_matour_foreign` FOREIGN KEY (`matour`) REFERENCES `tour` (`matour`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phieudattour`
--

LOCK TABLES `phieudattour` WRITE;
/*!40000 ALTER TABLE `phieudattour` DISABLE KEYS */;
INSERT INTO `phieudattour` VALUES (42,42,'2024-11-28',NULL,800000.00,'Đang chờ xác nhận đặt tour',1,'');
/*!40000 ALTER TABLE `phieudattour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phieuhuytour`
--

DROP TABLE IF EXISTS `phieuhuytour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phieuhuytour` (
  `maphieuhuytour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sotienhoan` bigint(20) unsigned NOT NULL,
  `lydohuy` varchar(255) NOT NULL,
  `ngayhuy` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`maphieuhuytour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phieuhuytour`
--

LOCK TABLES `phieuhuytour` WRITE;
/*!40000 ALTER TABLE `phieuhuytour` DISABLE KEYS */;
/*!40000 ALTER TABLE `phieuhuytour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phongban`
--

DROP TABLE IF EXISTS `phongban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phongban` (
  `maphongban` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenphongban` varchar(255) NOT NULL,
  `truongphong` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`maphongban`),
  UNIQUE KEY `phongban_tenphongban_unique` (`tenphongban`),
  KEY `fk_truongphong_nhanvien` (`truongphong`),
  CONSTRAINT `fk_truongphong_nhanvien` FOREIGN KEY (`truongphong`) REFERENCES `nhanvien` (`manhanvien`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phongban`
--

LOCK TABLES `phongban` WRITE;
/*!40000 ALTER TABLE `phongban` DISABLE KEYS */;
INSERT INTO `phongban` VALUES (1,'Kinh doanh',45,'2024-11-08 17:00:00','2024-11-27 15:08:52'),(5,'Nhân sự',3,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(6,'Marketing',4,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(8,'Kế hoạch tài chính',5,'2024-11-09 17:00:00','2024-12-10 17:00:00');
/*!40000 ALTER TABLE `phongban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phuongtien`
--

DROP TABLE IF EXISTS `phuongtien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phuongtien` (
  `maphuongtien` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenphuongtien` varchar(255) NOT NULL,
  `sochongoi` int(11) NOT NULL,
  `sodienthoai` varchar(255) NOT NULL,
  `giaphuongtien` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`maphuongtien`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phuongtien`
--

LOCK TABLES `phuongtien` WRITE;
/*!40000 ALTER TABLE `phuongtien` DISABLE KEYS */;
INSERT INTO `phuongtien` VALUES (2,'Xe hoi',7,'01256385526',12,'2024-11-05 06:36:23','2024-11-05 06:36:23'),(3,'Xe khách',32,'01254558451',201200,'2024-11-05 06:36:50','2024-11-05 06:36:50'),(4,'Xe giường nằm',28,'0903320909',70000,'2024-11-05 06:50:05','2024-11-05 06:50:05'),(5,'Máy bay',10,'09870544323',90000,'2024-11-05 06:50:37','2024-11-05 06:50:37');
/*!40000 ALTER TABLE `phuongtien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quyen`
--

DROP TABLE IF EXISTS `quyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quyen` (
  `maquyen` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tenquyen` varchar(255) NOT NULL,
  `mota` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`maquyen`),
  UNIQUE KEY `quyen_tenquyen_unique` (`tenquyen`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quyen`
--

LOCK TABLES `quyen` WRITE;
/*!40000 ALTER TABLE `quyen` DISABLE KEYS */;
INSERT INTO `quyen` VALUES (1,'Thêm','Thêm thông tin','2024-11-08 17:00:00','2024-11-08 17:00:00'),(2,'Xoá','Xoá thông tin các trường','2024-11-08 17:00:00','2024-11-08 17:00:00'),(3,'Sửa','Sửa thông tin các trường','2024-11-08 17:00:00','2024-11-08 17:00:00'),(4,'Xem','Xem thông tin','2024-11-08 17:00:00','2024-11-08 17:00:00');
/*!40000 ALTER TABLE `quyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quyen_nhomquyen`
--

DROP TABLE IF EXISTS `quyen_nhomquyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quyen_nhomquyen` (
  `maquyen` int(10) unsigned NOT NULL,
  `manhomquyen` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`maquyen`,`manhomquyen`),
  KEY `quyen_nhomquyen_manhomquyen_foreign` (`manhomquyen`),
  CONSTRAINT `quyen_nhomquyen_manhomquyen_foreign` FOREIGN KEY (`manhomquyen`) REFERENCES `nhomquyen` (`manhomquyen`) ON DELETE CASCADE,
  CONSTRAINT `quyen_nhomquyen_maquyen_foreign` FOREIGN KEY (`maquyen`) REFERENCES `quyen` (`maquyen`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quyen_nhomquyen`
--

LOCK TABLES `quyen_nhomquyen` WRITE;
/*!40000 ALTER TABLE `quyen_nhomquyen` DISABLE KEYS */;
INSERT INTO `quyen_nhomquyen` VALUES (1,1,'2024-12-10 17:00:00','2024-12-10 17:00:00'),(3,2,'2024-11-08 17:00:00','2024-11-08 17:00:00'),(4,2,'2024-11-08 17:00:00','2024-11-08 17:00:00');
/*!40000 ALTER TABLE `quyen_nhomquyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour`
--

DROP TABLE IF EXISTS `tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour` (
  `matour` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tentour` varchar(255) NOT NULL,
  `slug` text NOT NULL,
  `motatour` text DEFAULT NULL,
  `tinhtrang` tinyint(2) NOT NULL,
  `hinhdaidien` varchar(255) NOT NULL,
  `noikhoihanh` varchar(255) NOT NULL,
  `thoigiandi` varchar(225) DEFAULT NULL,
  `giatour` bigint(20) NOT NULL DEFAULT 0,
  `giatourgiam` double(20,2) DEFAULT 0.00,
  `maloaitour` int(10) unsigned NOT NULL,
  `makhuyenmai` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`matour`),
  KEY `tour_maloaitour_foreign` (`maloaitour`),
  KEY `tour_makhuyenmai_foreign` (`makhuyenmai`),
  CONSTRAINT `tour_makhuyenmai_foreign` FOREIGN KEY (`makhuyenmai`) REFERENCES `khuyenmai` (`makhuyenmai`) ON DELETE CASCADE,
  CONSTRAINT `tour_maloaitour_foreign` FOREIGN KEY (`maloaitour`) REFERENCES `loaitour` (`maloaitour`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour`
--

LOCK TABLES `tour` WRITE;
/*!40000 ALTER TABLE `tour` DISABLE KEYS */;
INSERT INTO `tour` VALUES (40,'Du lịch miền Bắc mùa Thu - Hà Nội - Tam Chúc - Ninh Bình - Trải Nghiệm Du Thuyền Vịnh Hạ Long từ Sài Gòn 2024','du-lich-mien-bac-mua-thu-ha-noi-tam-chuc-ninh-binh-trai-nghiem-du-thuyen-vinh-ha-long-tu-sai-gon-2024','Du lịch miền Bắc mùa Thu - Hà Nội - Tam Chúc - Ninh Bình - Trải Nghiệm Du Thuyền Vịnh Hạ Long từ Sài Gòn 2024. Mùa thu miền Bắc luôn là khoảng thời gian tuyệt vời để khám phá thiên nhiên tươi đẹp, văn hóa đặc sắc và những di tích lịch sử lâu đời. Trong hành trình du lịch mùa thu 2024 từ Sài Gòn, bạn sẽ có cơ hội trải nghiệm các điểm đến nổi bật như Hà Nội, Tam Chúc, Ninh Bình và Vịnh Hạ Long. Đây là chuyến đi hứa hẹn mang lại những kỷ niệm khó quên với phong cảnh thơ mộng và không khí trong lành của mùa thu Bắc Bộ.',1,'frontend/images/tour/media_67474e0fcece7.png','Hồ Chí Minh','4',7213120,0.00,7,NULL,'2024-11-26 17:00:00','2024-11-26 17:00:00'),(41,'Du lịch Tây Bắc Tết Dương lịch - Hà Nội - Sapa - Fansipan 3N2Đ từ Sài Gòn 2025','du-lich-tay-bac-tet-duong-lich-ha-noi-sapa-fansipan-3n2d-tu-sai-gon-2025','Du lịch Tây Bắc Tết Dương lịch - Hà Nội - Sapa - Fansipan 3N2Đ từ Sài Gòn 2025. Chào đón Tết Dương lịch 2025, hành trình khám phá Tây Bắc 3 ngày 2 đêm từ Sài Gòn đến Hà Nội - Sapa - Fansipan là lựa chọn lý tưởng cho những ai yêu thích sự kỳ vĩ của thiên nhiên và nét văn hóa đặc trưng vùng cao. Khởi đầu từ Hà Nội cổ kính, du khách sẽ đến với Sapa - thị trấn mờ sương đầy thơ mộng. Tại đây, bạn có thể trải nghiệm chinh phục đỉnh Fansipan, \"nóc nhà Đông Dương\", để tận hưởng cảm giác đứng giữa biển mây trắng bồng bềnh, nhìn ngắm khung cảnh Tây Bắc tuyệt đẹp khi mùa xuân sắp về. Hành trình không chỉ là chuyến du ngoạn mà còn là cơ hội khám phá văn hóa bản địa, thưởng thức những món đặc sản vùng cao đầy hấp dẫn.',1,'frontend/images/tour/media_67475151e8765.jpg','Hồ Chí Minh','3',7701200,0.00,9,NULL,'2024-11-27 17:00:00','2024-11-27 17:00:00'),(42,'Du lịch Tiền Giang mùa Xuân - Mỹ Tho - Bến Tre - Cù Lao Thới Sơn từ Sài Gòn 2025','du-lich-tien-giang-mua-xuan-my-tho-ben-tre-cu-lao-thoi-son-tu-sai-gon-2025','Du lịch Tiền Giang mùa Xuân - Mỹ Tho - Bến Tre - Cù Lao Thới Sơn từ Sài Gòn 2025 - Du lịch Miền Tây - Tiền Giang là một tỉnh có nhiều điểm du lịch sinh thái miệt vườn nổi tiếng ở vùng đồng bằng sông Cửu Long. Trong số đó, cù lao Thới Sơn là nơi mang đậm nét Miền Tây sông nước mà du khách không nên bỏ lỡ.  Cồn Thới Sơn là một điểm du lịch Tiền Giang thu hút nhiều khách đến tham quan. Nơi này gần Sài Gòn và mang đậm nét văn hóa miền sông nước miệt vườn. Du khách sẽ được tận hưởng những giây phút thư thái và dễ chịu tại nơi yên bình của xứ miệt vườn. Ngoài ra, Cồn Thới Sơn cũng có nhiều đặc sản ngon miệng đang chờ du khách đến khám phá. Hãy cùng Du Lịch Việt trải nghiệm một chuyến du lịch đầy ý nghĩa và thú vị bên gia đình tại Tiền Giang nhé.',1,'frontend/images/tour/media_6747526487e4d.jpg','Hồ Chí Minh','1',800000,0.00,9,NULL,'2024-11-27 17:00:00','2024-11-27 17:00:00'),(43,'Du lịch Long An mùa Xuân - Làng nổi Tân Lập từ Sài Gòn 2025','du-lich-long-an-mua-xuan-lang-noi-tan-lap-tu-sai-gon-2025',NULL,1,'frontend/images/tour/media_674753a3dd46e.jpg','Hồ Chí Minh','1',850000,0.00,8,NULL,'2024-11-27 17:00:00','2024-11-27 17:00:00'),(44,'Du lịch miền Tây - Mỹ Tho - KDL Mỹ Khánh - Cồn Phụng - Cần Thơ từ Sài Gòn 2024','du-lich-mien-tay-my-tho-kdl-my-khanh-con-phung-can-tho-tu-sai-gon-2024','Du lịch miền Tây khám phá Mỹ Tho - KDL Mỹ Khánh - Cồn Phụng - Cần Thơ từ Sài Gòn 2024 - Chuyến du lịch miền Tây từ Sài Gòn sẽ mang bạn vào hành trình khám phá nét đẹp mộc mạc, thanh bình và trù phú của vùng sông nước Nam Bộ. Bắt đầu tại Mỹ Tho, bạn sẽ được dạo quanh các cù lao xanh mát, thưởng thức đặc sản dân dã. Tiếp đó là Khu du lịch Mỹ Khánh, nơi du khách có thể trải nghiệm cuộc sống miền quê qua những hoạt động như làm nông, nghe đờn ca tài tử và thưởng thức trái cây tươi ngon. Chuyến đi còn đưa bạn đến Cồn Phụng nổi tiếng với khung cảnh nên thơ và các hoạt động thú vị như câu cá, chèo xuồng. Hành trình khép lại tại Cần Thơ, thành phố miền Tây sôi động với chợ nổi Cái Răng đầy sắc màu, những vườn cây trái bạt ngàn, và các món ăn đặc sản đậm đà. Cùng khám phá miền Tây 2024 để cảm nhận vẻ đẹp quyến rũ của sông nước, con người và văn hóa Nam Bộ.',1,'frontend/images/tour/media_6747b70b51928.jpg','Hồ Chí Minh','2',1500010,0.00,10,NULL,'2024-11-27 17:00:00','2024-11-27 17:00:00'),(45,'Du lịch miền Tây mùa Thu - Mỹ Tho - Cần Thơ - Châu Đốc - Bạc Liêu - Sóc Trăng từ Sài Gòn 2024','du-lich-mien-tay-mua-thu-my-tho-can-tho-chau-doc-bac-lieu-soc-trang-tu-sai-gon-2024','Du lịch Mỹ Tho - Xuôi về Miền Tây, Du Khách có dịp trải nghiệm thú vị khi hòa mình vào cuộc sống miệt vườn, thưởng thức những món ăn đặc sản đậm đà hương vị của vùng đồng bằng cây ngọt trái lành. Đến Cần Thơ, vùng đất mệnh danh là “Tây Đô”, lên thuyền du ngoại chợ nổi Cái Răng, trực tiếp trải nghiệm nét văn hóa độc đáo trên sông nước. Ghé Sóc Trăng, thăm Chùa Dơi hơn 400 năm tuổi, vừa chiêm ngưỡng lối kiến trúc Khơmer độc đáo vừa nghe kể về đàn dơi huyền bí trụ ngụ trong khuôn viên chùa. Đặt chân đến Đất Mũi, vùng đất cuối cùng của Tổ quốc, đứng trên đài quan sát, Du Khách sẽ thu vào tầm mắt khung cảnh rừng mắm, rừng đước xanh rì nối nhau, trải dài ngút ngàn, tiếp giáp với mây trời. Đến Bạc Liêu, khám phá miền quê hương của chàng Công Tử tiêu tiền như nước, nghe nhắc lại những giai thoại nức tiếng gần xa trong quá khứ về sự xa hoa. Ngoài ra, Du khách còn được tìm hiểu về điệu Dạ Cổ Hoài Lang, thăm những di tích lịch sử, điểm du lịch sinh thái và đặc biệt là những điểm du lịch tâm linh gắn liền với cảnh quan và các câu chuyện cổ xưa. Nhanh tay đặt tour Du lịch miền Tây mùa Thu - Mỹ Tho - Cần Thơ - Châu Đốc - Bạc Liêu - Sóc Trăng từ Sài Gòn 2024 tại Du Lịch Việt chúng tôi đi và cảm nhận nhé..',2,'frontend/images/tour/media_6747b8ab44a93.jpg','Hồ Chí Minh','4',0,0.00,10,NULL,'2024-11-27 17:00:00','2024-11-27 17:00:00');
/*!40000 ALTER TABLE `tour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `mataikhoan` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tentaikhoan` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `matkhau` varchar(255) NOT NULL,
  `trangthai` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `manhomquyen` int(10) unsigned NOT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mataikhoan`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_tentaikhoan_unique` (`tentaikhoan`),
  KEY `users_manhomquyen_foreign` (`manhomquyen`),
  CONSTRAINT `users_manhomquyen_foreign` FOREIGN KEY (`manhomquyen`) REFERENCES `nhomquyen` (`manhomquyen`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (27,'vohoankien','vohoankien@gmail.com',NULL,'$2y$12$O2UcK6OdaZWqK.AeD7Jyq.XC.cyUenwSvVFloah.GaQ2vtH.4fWdC','Hoạt động',NULL,1,NULL,'2024-11-06 11:29:20','2024-11-27 14:21:58'),(33,'csporer','lockman.mylene@example.net',NULL,'$2y$12$eFp9tS8YPY32qH/cR2QPaedvK5QCuGeTmHWqVACB8K7EIpnwr7s2e','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:42','2024-11-09 06:51:42'),(34,'mathias60','uokon@example.net',NULL,'$2y$12$w6td3ODoxv7V/1Gis1jo3uUiTcBLKeJ3zUrC4nB7FCLp.n3PWcWuW','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:43','2024-11-09 06:51:43'),(35,'gleason.fidel','sylvester18@example.com',NULL,'$2y$12$zY1nNO5OiFw.CxCF3b.mAOJeeOm7jjOha03NGutHy/qKmeej9v4Pm','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:43','2024-11-09 06:51:43'),(36,'estel.carroll','bprice@example.com',NULL,'$2y$12$.v5Ujz4EYN4uRhwx7NE5aeOl.RrgfilpxEJDEem.z/Er6WKIkFp0q','Hoạt động',NULL,1,NULL,'2024-11-09 06:51:43','2024-11-27 15:07:08'),(37,'obergstrom','wsmith@example.com',NULL,'$2y$12$ctRB/o9RTPLHTnjp..ZVZ.fAJ6CVF4CcOPZ1tMg.vcVaiUmReeHES','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:44','2024-11-09 06:51:44'),(38,'uohara','maximo31@example.com',NULL,'$2y$12$gyBG.tsthnAkRa0ieeuheOk8iRU/ivru4Q9AtFWsO31YRrYo8a1oC','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:44','2024-11-09 06:51:44'),(39,'farrell.andrew','ronaldo64@example.net',NULL,'$2y$12$4obiumwL37IP48yY5PvOoO0GV2zR23A89Qqii/c9gFwCB5odTinNm','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:44','2024-11-09 06:51:44'),(40,'lilla.hermann','daija.hodkiewicz@example.com',NULL,'$2y$12$HFmYrCnwOhSd/XgRRvjquubcgmj6ykQUySU6WNT0q9Yv7JX9XQmZS','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:45','2024-11-09 06:51:45'),(75,'kuhic.sincere','wilbert.lang@example.org',NULL,'$2y$12$JS7JBj1VA80lwN4JC80PD.ExkT2Gtqy/aQkeWPw8Nf0MwLB21dgOe','Hoạt động',NULL,1,NULL,'2024-11-09 06:51:57','2024-12-14 14:01:38'),(76,'javier.bashirian','laverna60@example.com',NULL,'$2y$12$Cw8/71uxPHt.kkSILkqUFebCXnIwOqj87wUnSo5tdOLkYnTZU6VRO','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:57','2024-11-09 06:51:57'),(77,'walsh.mackenzie','bella.tillman@example.org',NULL,'$2y$12$IUV6eqUyEv323cGpSB5p3OlENagd3HrxnyWWDTZ8YKZ1niM5e823W','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:57','2024-11-09 06:51:57'),(78,'khaley','marisa67@example.com',NULL,'$2y$12$SLmLCcdEdqeAnIX/X7doD.A3KBwjU/B6OHKa6QIIXSI.yZEOovE1i','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:58','2024-11-09 06:51:58'),(79,'valentina.mcdermott','roy19@example.org',NULL,'$2y$12$LZoZXJoa6XO0r88Irb2rQeMYqtCyfpbCSCMlpBypRAS87krBfGJUa','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:58','2024-11-09 06:51:58'),(80,'nova.abbott','psenger@example.net',NULL,'$2y$12$OerMKVU9Kspr./1z8IbDTuF9AIzUqnsWUT1V3OZxZxTGxjn7yXwMO','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:58','2024-11-09 06:51:58'),(81,'charlotte.lueilwitz','lemke.benjamin@example.com',NULL,'$2y$12$Z1TiQClEVwOnqUzJ4eUc7u53sOzGE1y/ZywWhpsbZNReDpipuJs0C','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:58','2024-11-09 06:51:58'),(82,'jovani.beahan','hjacobs@example.net',NULL,'$2y$12$uziFeWJTH12F0mJdRz8pPeVWW9uSdpVo8r4sobJD8mPhmU79bpS5a','Hoạt động',NULL,2,NULL,'2024-11-09 06:51:59','2024-11-09 06:51:59'),(83,'Trần Trọng Vương','vuongtran975@gmail.com',NULL,'$2y$12$g2UPoVlUdcSo8skBTfWa.evA.DFHVfuypc8XJSEM7COG7X70eFRuO','Hoạt động',NULL,2,NULL,'2024-11-11 06:19:32','2024-11-11 06:19:32'),(85,'vonhuthao','vonhuthao@gmail.com',NULL,'$2y$12$LHe9oK7f2DqQriBxRRp.DuVVnJRA5NyzxKlwpYPtni6R1p1TluhU2','Hoạt động',NULL,2,NULL,'2024-11-13 09:14:00','2024-11-13 09:14:00'),(124,'hoankien2k3@gmail.com','hoankien2k3@gmail.com',NULL,'$2y$12$YMl5p/SKNdj.aUBSIAtOGOZv8Np87NNJ.qoONaQ5pUDjhbZQruKb6','Hoạt động',NULL,2,'108960097695417606264','2024-11-26 07:39:53','2024-11-26 07:39:53'),(125,'vohoankien123','vohoankien123@gmail.com',NULL,'$2y$12$O2UcK6OdaZWqK.AeD7Jyq.XC.cyUenwSvVFloah.GaQ2vtH.4fWdC','Khóa',NULL,2,NULL,'2024-11-27 17:40:09','2024-12-11 08:52:37');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ql_tourdulich'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_create_NgayKetThuc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_create_NgayKetThuc`(`ID` INT, `madiemdulich` INT, `ngaybatdau` DATE) RETURNS date
BEGIN
    DECLARE thoigian INT;
    DECLARE ngayketthuc DATE;

    
    SELECT thoigiandi INTO thoigian
    FROM tour
    WHERE matour = ID;

    
    SET ngayketthuc = DATE_ADD(ngaybatdau, INTERVAL thoigian DAY);

    
    RETURN ngayketthuc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_giaTour` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_giaTour`(`ID` FLOAT) RETURNS float
BEGIN
DECLARE giacttour float;
DECLARE giapttour float;
DECLARE giakstour float;
DECLARE giatour float;

SELECT COALESCE(MAX(giachitiettour), 0) into giacttour
FROM chitiettour
WHERE matour = ID;



SELECT COALESCE(SUM(giaphuongtien), 0) INTO giapttour
FROM chitietphuongtientour ctpt LEFT JOIN phuongtien pt
ON ctpt.maphuongtien = pt.maphuongtien
WHERE matour = ID;



SELECT COALESCE(SUM(giakhachsan), 0)  INTO giakstour
FROM chitietkhachsantour ctks LEFT JOIN khachsan ks
ON ctks.makhachsan = ks.makhachsan
WHERE matour = ID;



SET giatour = giacttour + giapttour + giakstour ;
RETURN giatour;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_soPhieuHuy` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_soPhieuHuy`() RETURNS int(11)
BEGIN
DECLARE sophieuhuy INT ;
SELECT COUNT(*) INTO sophieuhuy
FROM phieuhuytour;
RETURN sophieuhuy;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_tongTienTrongNam` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_tongTienTrongNam`() RETURNS int(11)
BEGIN
  DECLARE tongtien FLOAT;
  SELECT SUM(tongsotien) INTO tongtien
  FROM hoadon
  WHERE YEAR(updated_at) = YEAR(CURRENT_DATE());
  RETURN tongtien;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_tongTienTrongNgay` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_tongTienTrongNgay`() RETURNS float
BEGIN
DECLARE tongtien FLOAT ;
SELECT SUM(tongsotien) INTO tongtien
FROM hoadon
WHERE DATE(updated_at) = CURRENT_DATE() ;
RETURN tongtien;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `func_tongtienTrongThang` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_tongtienTrongThang`() RETURNS float
BEGIN
  DECLARE tongtien FLOAT;
  SELECT SUM(tongsotien) INTO tongtien
  FROM hoadon
  WHERE MONTH(updated_at) = MONTH(CURRENT_DATE()) 
  AND YEAR(updated_at) = YEAR(CURRENT_DATE());
  RETURN tongtien;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_selectNhanVienTheoChucVu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_selectNhanVienTheoChucVu`(IN `tenChucVu` VARCHAR(50) CHARSET utf8mb4)
SELECT
nv.manhanvien, 
nv.hoten,nv.bangcap,nv.gioitinh,
cv.tenchucvu
FROM 
phancongchucvu pc 
JOIN chucvu cv ON pc.machucvu = cv.machucvu
join nhanvien nv on nv.manhanvien = pc.manhanvien
WHERE cv.tenchucvu COLLATE utf8mb4_unicode_ci = tenChucVu COLLATE utf8mb4_unicode_ci and nv.tinhtrang = 0 ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_selectNhanVienTheoTour` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_selectNhanVienTheoTour`(IN `matourPC` INT)
SELECT 
    nv.hoten,
    cv.tenchucvu
FROM 
    nhanvien nv
JOIN 
    phancongnhanvien pc ON nv.manhanvien = pc.manhanvien
JOIN 
    phancongchucvu pccv ON nv.manhanvien = pccv.manhanvien
JOIN 
    chucvu cv ON cv.machucvu = pccv.machucvu
WHERE 
    pc.matour = matourPC and cv.tenchucvu = pc.nhiemvu ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_selectTourAccept` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_selectTourAccept`()
BEGIN
SELECT
        t.matour, 
        t.tentour, 
        t.motatour, 
        t.noikhoihanh, 
        t.hinhdaidien, 
t.thoigiandi,
        l.tenloai
 FROM tour t inner join loaitour l  
 on t.maloaitour = l.maloaitour
 WHERE tinhtrang = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_statisticDoanhThu` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_statisticDoanhThu`()
BEGIN

SELECT tentour,sum(tongsoluong) as soluong
FROM tour t,phieudattour pdt
WHERE t.matour = pdt.matour
GROUP BY t.matour;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_statisticKhachHang` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_statisticKhachHang`()
SELECT 
    DATE(created_at) AS ngay_gia_nhap, 
    COUNT(*) AS so_luong_khach_hang
FROM 
    users 
GROUP BY 
    DATE(created_at)
ORDER BY 
    ngay_gia_nhap ASC ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_statisticKhachHangTheoTuoi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_statisticKhachHangTheoTuoi`()
SELECT 
    CASE 
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 0 AND 6 THEN '<7'
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 7 AND 18 THEN '7-18'
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 19 AND 25 THEN '18-25'
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 26 AND 35 THEN '26-35'
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 36 AND 45 THEN '36-45'
        WHEN TIMESTAMPDIFF(YEAR, ngaysinh, CURDATE()) BETWEEN 46 AND 60 THEN '46-60'
        ELSE '60+'
    END AS age_group,
    COUNT(*) AS total
FROM khachhang
GROUP BY age_group ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_updateTinhTrangNhanVien` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_updateTinhTrangNhanVien`(IN `manhanvienNV` INT, IN `tinhtrangNV` BOOLEAN)
Update nhanvien
set tinhtrang = tinhtrangNV
where manhanvien = manhanvienNV ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_updateTourStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_updateTourStatus`(IN `matour_param` INT)
BEGIN
    DECLARE count_chuongtrinhtour INT;

    
    SELECT COUNT(*) INTO count_chuongtrinhtour 
    FROM chuongtrinhtour 
    WHERE matour = matour_param ;

    IF count_chuongtrinhtour != (SELECT thoigiandi FROM tour WHERE matour = matour_param) THEN
        UPDATE tour 
        SET tinhtrang = 2 
        WHERE matour = matour_param;
 ELSE
        UPDATE tour 
        SET tinhtrang = 1 
        WHERE matour = matour_param;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_NgayKetThuc_ChiTietTour` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_NgayKetThuc_ChiTietTour`(IN `id` INT, IN `madiemdulich` INT, IN `ngaybatdau` DATE)
BEGIN
DECLARE thoigiandi int;
SELECT thoigiandi INTO thoigiandi
FROM tour
WHERE matour = id;
UPDATE chitiettour
SET ngayketthuc = DATE_ADD(ngaybatdau,INTERVAL thoigiandi DAY)
WHERE matour = id and madiemdulich = madiemdulich;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-14 22:07:16
